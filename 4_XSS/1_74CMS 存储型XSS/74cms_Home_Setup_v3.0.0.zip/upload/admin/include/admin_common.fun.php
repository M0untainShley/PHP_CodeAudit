<?php
 /*
 * 74cms �������Ĺ��ú���
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
 if(!defined('IN_QISHI'))
 {
 	die('Access Denied!');
 }
function admin_addslashes_deep($value)
{
    if (empty($value))
    {
        return $value;
    }
    else
    {
        return is_array($value) ? array_map('admin_addslashes_deep', $value) : addslashes($value);
    }
}
function deep_stripslashes($str)
 {
 	if(is_array($str)){
 		foreach($str as $key => $val){
 			$str[$key] = deep_stripslashes($val);
 		}
 	} else {
 		$str = stripslashes($str);
 	}
 	return $str;
 }
function adminmsg($msg_detail, $msg_type = 0, $links = array(), $auto_redirect = true,$seconds=3)
{
	global $smarty;
    if (count($links) == 0)
    {
        $links[0]['text'] = '������һҳ';
        $links[0]['href'] = 'javascript:history.go(-1)';
    }
   $smarty->assign('ur_here',     'ϵͳ��ʾ');
   $smarty->assign('msg_detail',  $msg_detail);
   $smarty->assign('msg_type',    $msg_type);
   $smarty->assign('links',       $links);
   $smarty->assign('default_url', $links[0]['href']);
   $smarty->assign('auto_redirect', $auto_redirect);
   $smarty->assign('seconds', $seconds);
   $smarty->display('sys/admin_showmsg.htm');
	exit();
}
function refresh_cache($cachename)
{
	global $db;
	$config_arr = array();
	$cache_file_path =QISHI_ROOT_PATH. "data/cache_".$cachename.".php";
	$sql = "SELECT * FROM ".table($cachename);
	$arr = $db->getall($sql);
		foreach($arr as $key=> $val)
		{
		$config_arr[$val['name']] = $val['value'];
		}
	write_static_cache($cache_file_path,$config_arr);
}
function refresh_page_cache()
{
	global $db;
	$cache_file_path =QISHI_ROOT_PATH. "data/cache_page.php";
		$sql = "SELECT * FROM ".table('page');
		$arr = $db->getall($sql);
			foreach($arr as $key=> $val)
			{
			$config_arr[$val['alias']] =array("file"=>$val['file'],"tpl"=>$val['tpl'],"rewrite"=>$val['rewrite'],"html"=>$val['html'],"url"=>$val['url'],"caching"=>$val['caching'],"tag"=>$val['tag'],"alias"=>$val['alias']);
			}
		write_static_cache($cache_file_path,$config_arr);
}
function refresh_category_cache()
{
	global $db;
	$cache_file_path =QISHI_ROOT_PATH. "data/cache_category.php";
	$sql = "SELECT * FROM ".table('category')."  ORDER BY c_order DESC,c_id ASC";
	$result = $db->query($sql);
		while($row = $db->fetch_array($result))
		{
			$catarr[$row['c_alias']][] =array("id"=>$row['c_id'],"parentid"=>$row['c_parentid'],"categoryname"=>$row['c_name']);
		}
		write_static_cache($cache_file_path,$catarr);
}
function refresh_nav_cache()
{
	global $db;
	$cache_file_path =QISHI_ROOT_PATH. "data/cache_nav.php";
		$sql = "SELECT * FROM ".table('navigation')." WHERE display=1   ORDER BY navigationorder DESC";
		$result = $db->query($sql);
			while($row = $db->fetch_array($result))
			{
				$row['color']?$row['title']="<span style=\"color:".$row['color']."\">".$row['title']."</span>":'';
				if ($row['urltype']=="0")
				{
				$row['url']=url_rewrite($row['pagealias'],array('id0'=>$row['list_id']));
				}
			$catarr[$row['alias']][] =array("title"=>$row['title'],"url"=>$row['url'],"target"=>$row['target'],"tag"=>$row['tag']);
			}
		write_static_cache($cache_file_path,$catarr);
}
function write_static_cache($cache_file_path, $config_arr)
{
	$content = "<?php\r\n";
	$content .= "\$data = " . var_export($config_arr, true) . ";\r\n";
	$content .= "?>";
	file_put_contents($cache_file_path, $content, LOCK_EX);
}
function write_log($str, $user,$log_type=1)
{
 	global $db, $timestamp,$online_ip;
 	$sql = "INSERT INTO ".table('admin_log')." (log_id, admin_name, add_time, log_value,log_ip,log_type) VALUES ('', '$user', '$timestamp', '$str','$online_ip','".intval($log_type)."')"; 
	return $db->query($sql);
 }
function check_admin($name,$pwd)
{
 	global $db;
	$admin=get_admin_one($name);
	$md5_pwd=md5($pwd.$admin['pwd_hash']);
 	$row = $db->getone("SELECT COUNT(*) AS num FROM ".table('admin')." WHERE admin_name='$name' and pwd ='".$md5_pwd."' ");
 	if($row['num'] > 0){
 		return true;
 	}else{
 		return false;
 	}
}
function update_admin_info($admin_name,$refresh = true)
{
 	global $timestamp, $online_ip, $db;
	$admin = $db->getone("SELECT admin_id, admin_name, purview FROM ".table('admin')." WHERE admin_name = '$admin_name'");
 	$_SESSION['admin_id'] = $admin['admin_id'];
 	$_SESSION['admin_name'] = $admin['admin_name'];
 	$_SESSION['admin_purview'] = $admin['purview'];
	if ($refresh == true)
	{
		$last_login_time = $timestamp;
		$last_login_ip = $online_ip;
		$sql = "UPDATE ".table('admin')." SET last_login_time = '$last_login_time', last_login_ip = '$last_login_ip' WHERE admin_id='$_SESSION[admin_id]'";
		$db->query($sql);
		del_log($admin['admin_name'],30);//ɾ��30���ڵ���־
	}
 }
function check_cookie($user_name, $pwd)
 {
 	global $db;
 	$sql = "SELECT * FROM ".table('admin')." WHERE admin_name='".$user_name."' ";
 	$user = $db->getone($sql);
 	if(md5($user['admin_name'].$user['pwd'].$user['pwd_hash']) == $pwd)
	{
	return true;
	}
	return false;
 }
function get_admin_one($username){
	global $db;
	$sql = "select * from ".table('admin')." where admin_name = '".$username."' LIMIT 1";
	return $db->getone($sql);
}

function del_log($admin_name,$settr=30)
{
global $db;
$settr_val=strtotime("-".$settr." day");
if (!$db->query("Delete from ".table('admin_log')." WHERE admin_name='".$admin_name."' AND  add_time<".$settr_val." ")) return false;
return true;
}
function check_permissions($purview,$str)
{
	 if ($purview=="all")
	 {
	 return true;
	 }
	 else
	 {
	 $purview_arr=explode(',',$purview);
	 }
	 	if (in_array($str,$purview_arr))
		{
		return true;
		}
		else
		{
		permissions_insufficient();
		}
}
function permissions_insufficient()
{
	global $smarty;
    $smarty->display('sys/admin_sotp.htm');
	exit();
}
function html2text($str){
	$str = preg_replace("/<sty(.*)\\/style>|<scr(.*)\\/script>|<!--(.*)-->/isU","",$str);
	$alltext = "";
	$start = 1;
	for($i=0;$i<strlen($str);$i++)
	{
		if($start==0 && $str[$i]==">")
		{
			$start = 1;
		}
		else if($start==1)
		{
			if($str[$i]=="<")
			{
				$start = 0;
				$alltext .= " ";
			}
			else if(ord($str[$i])>31)
			{
				$alltext .= $str[$i];
			}
		}
	}
	$alltext = str_replace("��"," ",$alltext);
	$alltext = preg_replace("/&([^;&]*)(;|&)/","",$alltext);
	$alltext = preg_replace("/[ ]+/s"," ",$alltext);
	return $alltext;
}
?>