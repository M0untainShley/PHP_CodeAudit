<?php
 /*
 * 74cms �������� ���÷��� ���ݵ��ú���
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
 if(!defined('IN_QISHI'))
 {
 	die('Access Denied!');
 }
function get_category_group()
{
	global $db;
	$sql = "select * from ".table('category_group');
	return $db->getall($sql);
}
function get_category_group_one($alias)
{
	global $db;
	$sql = "select * from ".table('category_group')." WHERE g_alias='".$alias."'";
	return $db->getone($sql);
}
function del_group($alias)
{
	global $db;
	if(!is_array($alias)) $alias=array($alias);
	$return=0;
	foreach($alias as $a)
	{
			if (!$db->query("Delete from ".table('category_group')." WHERE g_alias ='".trim($a)."' AND g_sys<>1")) return false;
			$return=$return+$db->affected_rows();
			if (!$db->query("Delete from ".table('category')." WHERE c_alias ='".trim($a)."' ")) return false;
			$return=$return+$db->affected_rows();
	}
	return $return;
}
function get_category($alias)
{
	global $db;
	$sql = "select * from ".table('category')." WHERE c_alias='".$alias."'  ORDER BY c_order DESC,c_id ASC";
	return $db->getall($sql);
}
function get_category_one($id)
{
	global $db;
	$sql = "select * from ".table('category')." WHERE c_id=".intval($id)." LIMIT 1";
	return $db->getone($sql);
}
function del_category($id)
{
	global $db;
	if(!is_array($id)) $id=array($id);
	$return=0;
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("Delete from ".table('category')." WHERE c_id IN (".$sqlin.") ")) return false;
		$return=$return+$db->affected_rows();
	}
	return $return;
}
//��������------------------------------------
function get_category_district()
{
	global $db;
	$sql = "select * from ".table('category_district')." where parentid=0  order BY category_order desc,id asc";
	$result = $db->query($sql);
	while($row = $db->fetch_array($result))
	{		
		$sql = "select * from ".table('category_district')." where parentid=".$row['id']."  order BY category_order desc,id asc";
		$sub=$db->getall($sql);
		$row['sub']=$sub;
		$category[]=$row;
	}
	return $category;
}
function get_category_district_one($id)
{
	global $db;
	$sql = "select * from ".table('category_district')." WHERE id=".intval($id)." LIMIT 1";
	return $db->getone($sql);
}
function del_district($id)
{
	global $db;
	if(!is_array($id)) $id=array($id);
	$return=0;
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("Delete from ".table('category_district')." WHERE id IN (".$sqlin.") ")) return false;
		$return=$return+$db->affected_rows();
	}
	return $return;
}
//-----------ְλ
function get_category_jobs()
{
	global $db;
	$sql = "select * from ".table('category_jobs')." where parentid=0  order BY category_order desc,id asc";
	$result = $db->query($sql);
	while($row = $db->fetch_array($result))
	{		
		$sql = "select * from ".table('category_jobs')." where parentid=".$row['id']."  order BY category_order desc,id asc";
		$sub=$db->getall($sql);
		$row['sub']=$sub;
		$category[]=$row;
	}
	return $category;
}
function get_category_jobs_one($id)
{
	global $db;
	$sql = "select * from ".table('category_jobs')." WHERE id=".intval($id)." LIMIT 1";
	return $db->getone($sql);
}
function del_jobs_category($id)
{
	global $db;
	if(!is_array($id)) $id=array($id);
	$return=0;
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("Delete from ".table('category_jobs')." WHERE id IN (".$sqlin.") ")) return false;
		$return=$return+$db->affected_rows();
	}
	return $return;
}
function makejs_classify()
{
global $db;
	$content = "// JavaScript Document \n\n";
	$sql = "select * from ".table('category_district')." where parentid=0 ";
	$list=$db->getall($sql);
	//���ɵ�����������
	foreach($list as $parent)
	{
	$parentarr[]=$parent['id'].",".$parent['categoryname'];
	}
	$content .= "var QS_city_parent=\"".implode('|',$parentarr)."\" \n\n";	
	//���ɵ���С������
	$content .= "var QS_city=new Array() \n\n";
	foreach($list as $val)
	{
		$sql1 = "select * from ".table('category_district')." where parentid=".$val['id']."  order BY category_order desc,id asc";
		$list1=$db->getall($sql1);
		if (is_array($list1))
		{	
			foreach($list1 as $val1)
			{
			$sarr[]=$val1['id'].",".$val1['categoryname'];
			}
		$content .= "QS_city[".$val['id']."]=\"".implode('|',$sarr)."\" \n\n";	
		unset($sarr);
		}
	}
	//����ְλ����
	$content .= "var QS_jobs=new Array() \n\n";
	$sql = "select * from ".table('category_jobs')." where parentid=0 ";
	$list=$db->getall($sql);	
	foreach($list as $val)
	{
		$sql1 = "select * from ".table('category_jobs')." where parentid=".$val['id']."  order BY category_order desc,id asc";
		$list1=$db->getall($sql1);
		if (is_array($list1))
		{	
			foreach($list1 as $val1)
			{
			$sarr[]=$val1['id'].",".$val1['categoryname'];
			}
		$content .= "QS_jobs[".$val['id']."]=\"".implode('|',$sarr)."\" \n\n";	
		unset($sarr);
		}
	}
	$fp = @fopen(QISHI_ROOT_PATH . 'data/QS_classify.js', 'wb+');
	if (!$fp){
			exit('����JS�ļ�ʧ��');
		}
	 if (!@fwrite($fp, trim($content))){
			exit('д��JS�ļ�ʧ��');
		}
	@fclose($fp);
}
?>