<?php
 /*
 * 74cms �������� ��ҵ�û���غ���
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
 if(!defined('IN_QISHI'))
 {
die('Access Denied!');
 }
 //******************************ְλ����**********************************
//��ȡְλ��Ϣ�б�
function get_jobs($offset,$perpage,$get_sql= '')
{
	global $db,$timestamp;
	$row_arr = array();
	$limit=" LIMIT ".$offset.','.$perpage;
	$result = $db->query("SELECT * FROM ".table('jobs')." ".$get_sql.$limit);
	while($row = $db->fetch_array($result))
	{
	$row['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['company_id'],'addtime'=>$row['company_addtime']));
	$row['jobs_url']=url_rewrite('QS_jobsshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
	$row_arr[] = $row;
	}
	return $row_arr;
}
//��ȡ����ְλ
function get_jobs_one($id)
{
	global $db;
	$id=intval($id);
	$sql = "select * from ".table('jobs')." where id=".$id." LIMIT 1";
	$val=$db->getone($sql);
	$val['company_url']=url_rewrite('QS_companyshow',array('id0'=>$val['company_id'],'addtime'=>$val['company_addtime']));
	$val['user']=get_user($val['uid']);
	$val['contact']=get_jobs_contact($id);
	return $val;
}
//��ȡְλ��ϵ��ʽ
function get_jobs_contact($id)
{
	global $db;
	$id=intval($id);
	$sql = "select * from ".table('jobs_contact')." where pid=".$id." LIMIT 1";
	$val=$db->getone($sql);
	return $val;
}
//ɾ��ְλ
function del_jobs($id)
{
	global $db;
	if (!is_array($id))$id=array($id);
	$sqlin=implode(",",$id);
	$return=0;
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("Delete from ".table('jobs')." WHERE id IN (".$sqlin.")")) return false;
		$return=$return+$db->affected_rows();
		if (!$db->query("Delete from ".table('jobs_contact')." WHERE pid IN (".$sqlin.") ")) return false;
		return $return;
	}
	else
	{
	return false;
	}
}
//�޸�ְλ���״̬
function edit_jobs_audit($id,$audit)
{
	global $db,$_CFG;
	$audit=intval($audit);
	if (!is_array($id))$id=array($id);
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("update  ".table('jobs')." SET audit=".$audit."  WHERE id IN (".$sqlin.")")) return false;
			//�����ʼ�
			$mailconfig=get_cache('mailconfig');//��ȡ�ʼ�����
			if ($audit=="1" && $mailconfig['set_jobsallow']=="1")//���ͨ��
			{
				$result = $db->query("SELECT * FROM ".table('jobs')." WHERE id IN (".$sqlin.")  GROUP BY uid ");
				require_once('../phpmailer/class.phpmailer.php');
					while($list = $db->fetch_array($result))
					{					
					asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_jobsallow");
					}
			}
			if ($audit=="3" && $mailconfig['set_jobsnotallow']=="1")//���δͨ��
			{
				$result = $db->query("SELECT * FROM ".table('jobs')." WHERE id IN (".$sqlin.")  GROUP BY uid ");
					while($list = $db->fetch_array($result))
					{
					require_once('../phpmailer/class.phpmailer.php');
					asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_jobsnotallow");
					}
			}
		//�����ʼ�
		return true;
	}
	else
	{
	return false;
	}
}
function edit_jobs_emergency($id,$emergency)
{
	global $db;
	if (!is_array($id))$id=array($id);
	$sqlin=implode(",",$id);	
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("update  ".table('jobs')." SET emergency='".intval($emergency)."'  WHERE id IN (".$sqlin.")")) return false;
		return true;
	}
	return false;
}
function edit_jobs_recommend($id,$recommend)
{
	global $db;
	if (!is_array($id))$id=array($id);
	$sqlin=implode(",",$id);	
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("update ".table('jobs')." SET recommend=".intval($recommend)."  WHERE id IN (".$sqlin.")")) return false;
		return true;
	}
	return false;
}
function get_user($uid)
{
	global $db;
	$sql = "select * from ".table('members')." where uid=".intval($uid)." LIMIT 1";
	$val=$db->getone($sql);
	return $val;
}
//******************************��ҵ����**********************************
 //��ȡ��ҵ�б�
function get_company_profile($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	$limit=" LIMIT ".$offset.','.$perpage;
	$result = $db->query("SELECT * FROM ".table('company_profile')." AS c ".$get_sql.$limit);
	while($row = $db->fetch_array($result))
	{
	$row['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
	$row_arr[] = $row;
	}
	return $row_arr;
}
//��ȡ������ҵ����
function get_company_profile_one($id=0)
{
	global $db;
	if (intval($id)!= $id) return false;
	$sql = "select * from ".table('company_profile')." where id=".$id;
	$val=$db->getone($sql);
	$val['user']=get_user($val['uid']);
	return $val;
}
//������ҵ��֤״̬
function edit_company_audit($uid,$audit)
{
	global $db,$_CFG;	
	$audit=intval($audit);
	if (!is_array($uid)) $uid=array($uid);
	$sqlin=implode(",",$uid);	
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("update  ".table('company_profile')." SET audit=".$audit."  WHERE uid IN (".$sqlin.")")) return false;
		if ($audit=="1"){
			$points_rule=get_cache('members_points_rule');
			if ($points_rule['company_auth']>0) {//�����������֤���ͻ���
				if (!gift_points($sqlin,$points_rule['company_auth'])) return false;//����
			}
		}
		//�����ʼ�
		$mailconfig=get_cache('mailconfig');//��ȡ�ʼ�����
		if ($audit=="1" && $mailconfig['set_licenseallow']=="1")//��֤ͨ��
		{
			$result = $db->query("SELECT * FROM ".table('company_profile')." WHERE uid IN (".$sqlin.")");
				while($list = $db->fetch_array($result))
				{
				require_once('../phpmailer/class.phpmailer.php');
				asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_licenseallow");
				}
		}
		if ($audit=="3" && $mailconfig['set_licensenotallow']=="1")//��֤δͨ��
		{
			$result = $db->query("SELECT * FROM ".table('company_profile')." WHERE uid IN (".$sqlin.")");
				while($list = $db->fetch_array($result))
				{
				require_once('../phpmailer/class.phpmailer.php');
				asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_licensenotallow");
				}
		}
	//�����ʼ�
	return true;
	}
	return false;
}
//������ҵ�Ƽ�״̬
function edit_company_recommend($uid,$recommend)
{
	global $db;
	if (!is_array($uid))$uid=array($uid);
	$sqlin=implode(",",$uid);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
	if (!$db->query("update  ".table('company_profile')." SET recommend=".intval($recommend)."  WHERE uid IN (".$sqlin.")")) return false;
	if (!$db->query("update  ".table('jobs')." SET recommend=".intval($recommend)."  WHERE uid IN (".$sqlin.")")) return false;
	return true;
	}
	return false;
}
//��ҵ��֤ͨ�������ͻ���
function gift_points($uid,$points)
{
	global $db;
	if (!is_array($uid))$uid=array($uid);
	$sqlin=implode(",",$uid);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		$result = $db->query("SELECT uid FROM ".table('company_profile')." WHERE uid IN (".$sqlin.") AND audit=1 AND awards_points= 1");
		while($row = $db->fetch_array($result))
		{
		if (!report_deal($row['uid'],1,$points,"<span style=\"color:#33CC00\">��Ϊ����֤��ҵϵͳ���ͣ�</span>")) return false;
		$sql = "UPDATE ".table('company_profile')." SET awards_points= 2 WHERE uid=".$row['uid']."";//��Ϊ�Ѿ����͹�
		if (!$db->query($sql)) return false;
		}
	return true;
	}
	return false;
}
//ɾ����ҵ���ϣ�uid=array
function del_company($uid)
{
	global $db,$certificate_dir;
	if (!is_array($uid))$uid=array($uid);
	$sqlin=implode(",",$uid);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		$result = $db->query("SELECT certificate_img FROM ".table('company_profile')." WHERE uid IN (".$sqlin.")");
		while($row = $db->fetch_array($result))
		{
		@unlink($certificate_dir.$row['certificate_img']);
		}
		if (!$db->query("Delete from ".table('company_profile')." WHERE uid IN (".$sqlin.")")) return false;
	return true;
	}
	return false;
}
function del_company_alljobs($uid)
{
	global $db;
	if (!is_array($uid))$uid=array($uid);
	$sqlin=implode(",",$uid);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		$result = $db->query("SELECT id FROM ".table('jobs')." WHERE uid IN (".$sqlin.")");
		while($row = $db->fetch_array($result))
		{
		if (!$db->query("Delete from ".table('jobs_contact')." WHERE pid IN (".$row['id'].")")) return false;	
		}
		if (!$db->query("Delete from ".table('jobs')." WHERE uid IN (".$sqlin.")")) return false;		
		return true;
	}
	return false;
}
//******************************��������**********************************
//�����б�
function get_order_list($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	$limit=" LIMIT ".$offset.','.$perpage;
	$result = $db->query("SELECT o.*,m.username,m.email,c.companyname FROM ".table('order')." as o ".$get_sql.$limit);
	while($row = $db->fetch_array($result))
	{
	$row['payment_name']=get_payment_info($row['payment_name'],true);
	$row_arr[] = $row;
	}
	return $row_arr;
}
//��ȡ����
function get_order_one($id=0)
{
	global $db;
	$sql = "select * from ".table('order')." where id=".intval($id)." LIMIT 1";
	$val=$db->getone($sql);
	$val['payment_name']=get_payment_info($val['payment_name'],true);
	$val['payment_username']=get_user($val['uid']);
	return $val;
}
//ȡ������
function del_order($id)
{
	global $db;
	if (!is_array($id))$id=array($id);
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("Delete from ".table('order')." WHERE id IN (".$sqlin.")  AND is_paid=1 ")) return false;		
		return true;
	}
	return false;
}
//��ȡ��ֵ֧����ʽ����
function get_payment_info($typename,$name=false)
{
	global $db;
	$sql = "select * from ".table('payment')." where typename ='".$typename."'";
	$val=$db->getone($sql);
	if ($name)
	{
	return $val['byname'];
	}
	else
	{
	return $val;
	}
}
//******************************��ҵ��Ա����**********************************
//��ҵ��Ա�б�
function get_member_list($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	$limit=" LIMIT ".$offset.','.$perpage;
	$result = $db->query("SELECT m.*,c.companyname,c.id,c.addtime FROM ".table('members_type')." as t ".$get_sql.$limit);
	while($row = $db->fetch_array($result))
	{
	$row['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
	$row_arr[] = $row;
	}
	return $row_arr;
}
//ɾ����ҵ��Ա
function delete_company_user($uid)
{
	global $db;
	if (!is_array($uid))$uid=array($uid);
	$sqlin=implode(",",$uid);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if(defined('UC_API'))
		{
			include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
			foreach($uid as $tuid)
			{
			$userinfo=get_user($tuid);
			$uc_user=uc_get_user($userinfo['username']);
			$uc_uid_arr[]=$uc_user[0];
			}
			uc_user_delete($uc_uid_arr);
		}
		if (!$db->query("Delete from ".table('members')." WHERE uid IN (".$sqlin.")")) return false;
		if (!$db->query("Delete from ".table('members_type')." WHERE uid IN (".$sqlin.")")) return false;
		if (!$db->query("Delete from ".table('members_info')." WHERE uid IN (".$sqlin.")")) return false;
		if (!$db->query("Delete from ".table('members_points')." WHERE uid IN (".$sqlin.")")) return false;
		if (!$db->query("Delete from ".table('members_points_report')." WHERE uid IN (".$sqlin.")")) return false;
		if (!$db->query("Delete from ".table('order')." WHERE uid IN (".$sqlin.")")) return false;
		if (!$db->query("Delete from ".table('members_setmeal')." WHERE uid IN (".$sqlin.")")) return false; 
		return true;		
	}
	return false;
}
//******************************����**********************************
//��ȡ��Ա��Ϣ�������û����������Ϣ
function get_user_points($uid)
{
	global $db;
	$sql = "select * from ".table('members_points')." where uid = ".intval($uid)."  LIMIT 1 ";
	$points=$db->getone($sql);
	return $points['points'];
}
//��ȡ���ֹ���
function get_points_rule()
{
	global $db;
	$sql = "select * from ".table('members_points_rule')."  order BY id asc";
	$list=$db->getall($sql);
	return $list;
}
//-------------------------------------------------------
//�����ͨ
function order_paid($v_oid)
{
	global $db,$timestamp,$_CFG;
	$list=$db->getone("select * from ".table('order')." WHERE oid ='$v_oid' AND is_paid=1 LIMIT 1 ");
		if ($list)
		{
			$sql = "UPDATE ".table('order')." SET is_paid= '2',payment_time='".$timestamp."' WHERE oid='$v_oid' LIMIT 1 ";
			if (!$db->query($sql)) return false;
				if ($_CFG['operation_mode']=="1")
				{
					$notes=date('Y-m-d H:i',time())."ͨ����".get_payment_info($list['payment_name'],true)." �ɹ���ֵ ".$list['amount']."Ԫ";
					if (!report_deal($list['uid'],1,$list['points'],$notes)) return false;
				}
				if ($_CFG['operation_mode']=="2")
				{
					if (!set_members_setmeal($list['uid'],$list['setmeal'])) return false;
				}
			//�����ʼ�
			$mailconfig=get_cache('mailconfig');
			if ($mailconfig['set_payment']=="1")
			{
			require_once(QISHI_ROOT_PATH.'include/fun_user.php');
			asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_payment");
			}
			//�����ʼ����
			return true;
		}
	return true;
}
function report_deal($uid,$i_type=1,$points=0,$notes)
{
	global $db,$timestamp;
	$points_val=get_user_points($uid);
		if ($i_type==1)
		{
		$points_val=$points_val+$points;
		}
		if ($i_type==2)
		{
		$points_val=$points_val-$points;
		$points_val=$points_val<0?0:$points_val;
		}
		$sql = "INSERT INTO ".table('members_points_report')." (uid,i_type,points,remain_points,addtime,notes) VALUES ('$uid','$i_type','$points','$points_val', '$timestamp', '$notes')";
		!$db->query($sql)?adminmsg('δ֪����',0):'';
		$sql = "UPDATE ".table('members_points')." SET points= '$points_val' WHERE uid='$uid'  LIMIT 1 ";
		!$db->query($sql)?adminmsg('δ֪����',0):'';
		return true;
}
function get_setmeal($apply=true)
{
	global $db;
	if ($apply==true)
	{
	$where="";
	}
	else
	{
	$where=" WHERE display=1 ";
	} 
	$sql = "select * from ".table('setmeal').$where."  order BY display desc,show_order desc,id asc";
	return $db->getall($sql);
}
function get_setmeal_one($id)
{
	global $db;
	$sql = "select * from ".table('setmeal')."  WHERE id=".intval($id)."";
	return $db->getone($sql);
}
function get_user_setmeal($uid)
{
	global $db;
	$sql = "select * from ".table('members_setmeal')."  WHERE uid=".intval($uid)." AND  effective=1 LIMIT 1";
	return $db->getone($sql);
}
function del_setmeal_one($id)
{
	global $db;
	if (!$db->query("Delete from ".table('setmeal')." WHERE id=".intval($id)." ")) return false;
	return true;
}
function set_members_setmeal($uid,$setmealid)
{
	global $db,$timestamp;
	$setmeal=$db->getone("select * from ".table('setmeal')." WHERE id = ".intval($setmealid)." AND display=1 LIMIT 1");
	if (empty($setmeal)) return false;
	$setsqlarr['effective']=1;
	$setsqlarr['setmeal_id']=$setmeal['id'];
	$setsqlarr['setmeal_name']=$setmeal['setmeal_name'];
	$setsqlarr['days']=$setmeal['days'];
	$setsqlarr['starttime']=$timestamp;
		if ($setmeal['days']>0)
		{
		$setsqlarr['endtime']=strtotime("".$setmeal['days']." days");
		}
		else
		{
		$setsqlarr['endtime']="0";	
		}
	$setsqlarr['expense']=$setmeal['expense'];
	$setsqlarr['jobs_ordinary']=$setmeal['jobs_ordinary'];
	$setsqlarr['jobs_emergency']=$setmeal['jobs_emergency'];
	$setsqlarr['jobs_headhunting']=$setmeal['jobs_headhunting'];
	$setsqlarr['download_resume_ordinary']=$setmeal['download_resume_ordinary'];
	$setsqlarr['download_resume_senior']=$setmeal['download_resume_senior'];
	$setsqlarr['interview_ordinary']=$setmeal['interview_ordinary'];
	$setsqlarr['interview_senior']=$setmeal['interview_senior'];
	$setsqlarr['talent_pool']=$setmeal['talent_pool'];
	$setsqlarr['recommended']=$setmeal['recommended'];
	$setsqlarr['map']=$setmeal['map'];
	$setsqlarr['added']=$setmeal['added'];
	if (!updatetable(table('members_setmeal'),$setsqlarr," uid=".$uid."")) return false;
		$setsqlarrmap['map_open']=$setsqlarr['map'];
		if (!updatetable(table('company_profile'),$setsqlarrmap," uid=".$uid."")) return false;
		$recommendedarr['recommend']=$setsqlarr['recommended'];
		if (!updatetable(table('company_profile'),$recommendedarr," uid=".$uid."")) return false;
	$setmeal_deadline['setmeal_deadline']=$setsqlarr['endtime'];
	if (!updatetable(table('jobs'),$setmeal_deadline," uid=".$uid."")) return false;
	if (!updatetable(table('company_profile'),$setmeal_deadline," uid=".$uid."")) return false;
	return true;
}
?>