<?php
 /*
 * 74cms �������� �����û���غ���
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
 if(!defined('IN_QISHI'))
 {
 	die('Access Denied!');
 }
 //******************************��������**********************************
//��ȡ������Ϣ�б�
function get_resume_list($offset,$perpage,$get_sql= '')
{
	global $db;
	$limit=" LIMIT ".$offset.','.$perpage;
	$result = $db->query("SELECT r.*,m.username FROM ".table('resume')." AS r ".$get_sql.$limit);
	while($row = $db->fetch_array($result))
	{
	$row['resume_url']=url_rewrite('QS_resumeshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
	$row_arr[] = $row;
	}
	return $row_arr;
}
//ɾ������(id)
function del_resume($id)
{
	global $db;
	if (!is_array($id)) $id=array($id);
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
	if (!$db->query("Delete from ".table('resume')." WHERE id IN (".$sqlin.")")) return false;
	if (!$db->query("Delete from ".table('resume_jobs')." WHERE pid IN (".$sqlin.") ")) return false;
	if (!$db->query("Delete from ".table('resume_education')." WHERE pid IN (".$sqlin.") ")) return false;
	if (!$db->query("Delete from ".table('resume_training')." WHERE pid IN (".$sqlin.") ")) return false;
	if (!$db->query("Delete from ".table('resume_work')." WHERE pid IN (".$sqlin.") ")) return false;
	return true;
	}
	return false;
}
//�޸ļ������״̬
function edit_resume_audit($id,$audit)
{
	global $db,$_CFG;
	$audit=intval($audit);
	if (!is_array($id))  $id=array($id);
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("update  ".table('resume')." SET audit=".$audit."  WHERE id IN (".$sqlin.") ")) return false;
			//�����ʼ�
				$mailconfig=get_cache('mailconfig');//��ȡ�ʼ�����
				if ($audit=="1" && $mailconfig['set_resumeallow']=="1")//���ͨ��
				{
					$result = $db->query("SELECT * FROM ".table('resume')." WHERE id IN (".$sqlin.")  ");
						while($list = $db->fetch_array($result))
						{
						require_once('../phpmailer/class.phpmailer.php');
						asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_resumeallow");
						}
				}
				if ($audit=="3" && $mailconfig['set_resumenotallow']=="1")//���δͨ��
				{
					$result = $db->query("SELECT * FROM ".table('resume')." WHERE id IN (".$sqlin.") ");
						while($list = $db->fetch_array($result))
						{
						require_once('../phpmailer/class.phpmailer.php');
						asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_resumenotallow");
						}
				}
			//�����ʼ�
	return true;
	}
	return false;
}
//�޸���Ƭ���״̬
function edit_resume_photoaudit($id,$audit)
{
	global $db;
	$audit=intval($audit);
	if (!is_array($id)) $id=array($id); 
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
		if (!$db->query("update  ".table('resume')." SET photo_audit=".$audit." WHERE id IN (".$sqlin.") ")) return false;
		return true;
	}
	return false;
}
//�޸��˲ŵȼ�
function edit_resume_talent($id,$talent)
{
	global $db;
	$talent=intval($talent);
	if (!is_array($id)) $id=array($id);
	$sqlin=implode(",",$id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
	if (!$db->query("update  ".table('resume')." SET talent=".$talent."  WHERE id IN (".$sqlin.")")) return false;
	return true;
	}
	return false;
}
//��UID��ȡ���м���
function get_resume_basic($uid)
{
	global $db;
	$result = $db->query("select * FROM ".table('resume')." where uid=".intval($uid)."");
	while($row = $db->fetch_array($result))
	{ 
	$row['resume_url']=url_rewrite('QS_resumeshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
	$row_arr[] = $row;
	}
	return $row_arr;	
}
//**************************���˻�Ա�б�
function get_member_list($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	$limit=" LIMIT ".$offset.','.$perpage;	
	$result = $db->query("SELECT m.* FROM ".table('members_type')." as t ".$get_sql.$limit);
		while($row = $db->fetch_array($result))
		{
		$row_arr[] = $row;
		}
	return $row_arr;
}
//ɾ����Ա
function delete_member($uid)
{
	global $db;
	if (!is_array($uid)) $uid=array($uid);
	$sqlin=implode(",",$uid);
		if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
		{
					if(defined('UC_API'))
					{
						include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
						foreach($uid as $tuid)
						{
						$userinfo=get_user($tuid);
						$uc_user=uc_get_user($userinfo['username']);
						$uc_uid_arr[]=$uc_user[0];
						}
						uc_user_delete($uc_uid_arr);
					} 
		if (!$db->query("Delete from ".table('members')." WHERE uid IN (".$sqlin.")")) return false;
		if (!$db->query("Delete from ".table('members_type')." WHERE uid IN (".$sqlin.")")) return false;
		return true;
		}
	return false;
}
//��ȡ���˻�Ա����
function get_member_one($memberuid)
{
	global $db;
	$sql = "select * from ".table('members')." where uid=".intval($memberuid)." LIMIT 1";
	$val=$db->getone($sql);
	return $val;
}
//��ȡ��Ա��Ϣ�������û����������Ϣ
function get_user($uid)
{
	global $db;
	$sql = "select * from ".table('members')." where uid = '".$uid."' LIMIT 1";
	return $db->getone($sql);
}
?>