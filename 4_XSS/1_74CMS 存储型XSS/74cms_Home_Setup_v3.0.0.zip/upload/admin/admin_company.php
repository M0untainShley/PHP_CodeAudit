<?php
 /*
 * 74cms ��ҵ�û����
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
define('IN_QISHI', true);
require_once(dirname(__FILE__).'/../data/config.php');
require_once(dirname(__FILE__).'/include/admin_common.inc.php');
require_once(ADMIN_ROOT_PATH.'include/admin_company_fun.php');
$act = !empty($_GET['act']) ? trim($_GET['act']) : 'jobs';
if($act == 'jobs')
{
	check_permissions($_SESSION['admin_purview'],"jobs_show");
	require_once(QISHI_ROOT_PATH.'include/page.class.php');
	$oederbysql=" order BY id DESC ";
	$key=isset($_GET['key'])?trim($_GET['key']):"";
	$key_type=isset($_GET['key_type'])?intval($_GET['key_type']):"";
	if ($key && $key_type>0)
	{
		
		if     ($key_type===1)$wheresql=" WHERE jobs_name like '%{$key}%'";
		elseif ($key_type===2)$wheresql=" WHERE companyname like '%{$key}%'";
		elseif ($key_type===3)$wheresql=" WHERE id =".intval($key);
		elseif ($key_type===4)$wheresql=" WHERE company_id =".intval($key);
		elseif ($key_type===5)$wheresql=" WHERE uid =".intval($key);
		$oederbysql="";
	}
	!empty($_GET['audit'])? $wheresqlarr['audit']=intval($_GET['audit']):'';
	!empty($_GET['emergency'])? $wheresqlarr['emergency']=intval($_GET['emergency']):'';
	$_GET['recommend']<>""? $wheresqlarr['recommend']=intval($_GET['recommend']):'';
	$_GET['level']<>""? $wheresqlarr['level']=intval($_GET['level']):'';
	if (is_array($wheresqlarr)) $wheresql=wheresql($wheresqlarr);
	if (!empty($_GET['settr']))
	{
		$settr=strtotime("-".intval($_GET['settr'])." day");
		$wheresql=empty($wheresql)?" WHERE refreshtime> ".$settr:$wheresql." AND refreshtime> ".$settr;
		$oederbysql=" order BY refreshtime DESC ";
	}
	$total_sql="SELECT COUNT(*) AS num FROM ".table('jobs').$wheresql;
	$total_val=get_total($total_sql);
	$page = new page(array('total'=>$total_val, 'perpage'=>$perpage));
	$currenpage=$page->nowindex;
	$offset=($currenpage-1)*$perpage;
	$jobs = get_jobs($offset,$perpage,$wheresql.$oederbysql);
	$smarty->assign('pageheader',"74CMS �������� - ��Ƹ��Ϣ");
	$smarty->assign('jobs',$jobs);
	$smarty->assign('now',time());
	if ($total_val>$perpage)$smarty->assign('page',$page->show(3));
	$smarty->display('company/admin_company_jobs.htm');
}
elseif($act == 'jobs_perform')
{
		$yid =!empty($_REQUEST['y_id'])?$_REQUEST['y_id']:adminmsg("��û��ѡ��ְλ��",1);
		if (!empty($_REQUEST['delete']))
		{
			check_permissions($_SESSION['admin_purview'],"jobs_del");
			$num=del_jobs($yid);
			if ($num>0)
			{
			adminmsg("ɾ���ɹ�����ɾ��".$num."��",2);
			}
			else
			{
			adminmsg("ɾ��ʧ�ܣ�",0);
			}
		}
		elseif (!empty($_POST['set_audit']))
		{
		check_permissions($_SESSION['admin_purview'],"jobs_audit");
		$audit=$_POST['audit'];
		!edit_jobs_audit($yid,intval($audit))?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2,$link);
		}
		elseif (!empty($_POST['set_emergency']))
		{
		check_permissions($_SESSION['admin_purview'],"jobs_emergency");
		$emergency=$_POST['emergency'];
		!edit_jobs_emergency($yid,intval($emergency))?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2,$link);
		}
		elseif (!empty($_POST['set_recommend']))
		{
		check_permissions($_SESSION['admin_purview'],"jobs_recommend");
		$recommend=$_POST['recommend'];
		!edit_jobs_recommend($yid,intval($recommend))?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2,$link);
		}
}
elseif($act == 'edit_jobs')
{
	check_permissions($_SESSION['admin_purview'],"jobs_edit");
	$id =!empty($_REQUEST['id'])?intval($_REQUEST['id']):adminmsg("��û��ѡ��ְλ��",1);
	$smarty->assign('pageheader',"74CMS �������� - ��Ƹ��Ϣ - �޸���Ƹ��Ϣ");
	$jobs=get_jobs_one($id);
	$smarty->assign('url',$_SERVER["HTTP_REFERER"]);
	$smarty->assign('jobs',$jobs);
	$smarty->display('company/admin_company_jobs_edit.htm');
}
elseif ($act=='editjobs_save')
{
	check_permissions($_SESSION['admin_purview'],"jobs_edit");
	$id=intval($_POST['id']);
	$setsqlarr['display']=intval($_POST['display']);
	$setsqlarr['audit']=intval($_POST['audit']);
	$setsqlarr['emergency']=intval($_POST['emergency']);
	$setsqlarr['sex']=intval($_POST['sex']);
	$setsqlarr['sex_cn']=trim($_POST['sex_cn']);
	$setsqlarr['nature']=intval($_POST['nature']);
	$setsqlarr['nature_cn']=trim($_POST['nature_cn']);	
	$setsqlarr['jobs_name']=trim($_POST['jobs_name'])?trim($_POST['jobs_name']):adminmsg('��û����дְλ���ƣ�',1);
	$setsqlarr['contents']=trim($_POST['contents'])?trim($_POST['contents']):adminmsg('��û����дְλ������',1);	
	$setsqlarr['amount']=trim($_POST['amount'])?trim($_POST['amount']):adminmsg('��û����д��Ƹ������',1);
	$setsqlarr['category']=intval($_POST['category']);
	$setsqlarr['subclass']=intval($_POST['subclass']);
	$setsqlarr['category_cn']=trim($_POST['category_cn']);
	$setsqlarr['district']=intval($_POST['district']);
	$setsqlarr['sdistrict']=intval($_POST['sdistrict']);
	$setsqlarr['district_cn']=trim($_POST['district_cn']);
	$setsqlarr['education']=intval($_POST['education']);
	$setsqlarr['education_cn']=trim($_POST['education_cn']);
	$setsqlarr['experience']=intval($_POST['experience']);
	$setsqlarr['experience_cn']=trim($_POST['experience_cn']);
	$setsqlarr['wage']=intval($_POST['wage']);
	$setsqlarr['wage_cn']=trim($_POST['wage_cn']);
	$days=intval($_POST['days']);
	if ($days>0 && (intval($_POST['olddeadline'])-time())>0) $setsqlarr['deadline']=intval($_POST['olddeadline'])+($days*(60*60*24));
	if ($days>0 && (intval($_POST['olddeadline'])-time())<0) $setsqlarr['deadline']=strtotime("".$days." day");
	$setsqlarr_contact['contact']=trim($_POST['contact']);
	$setsqlarr_contact['qq']=trim($_POST['qq']);
	$setsqlarr_contact['telephone']=trim($_POST['telephone']);
	$setsqlarr_contact['address']=trim($_POST['address']);
	$setsqlarr_contact['email']=trim($_POST['email']);
	$setsqlarr_contact['notify']=trim($_POST['notify']);
	$wheresql=" id='".$id."' ";
	if (!updatetable(table('jobs'),$setsqlarr,$wheresql)) adminmsg("����ʧ�ܣ�",0);
	$wheresql=" pid=".$id;
	if (!updatetable(table('jobs_contact'),$setsqlarr_contact,$wheresql)) adminmsg("����ʧ�ܣ�",0);
	unset($setsqlarr_contact,$setsqlarr);
	$link[0]['text'] = "����ְλ�б�";
	$link[0]['href'] = $_POST['url'];
	adminmsg("�޸ĳɹ���",2,$link);
}
elseif($act == 'jobs_batch')
{
	$smarty->assign('pageheader',"74CMS �������� - ��������ְλ");
	$smarty->display('company/admin_company_jobs_batch.htm');
}
elseif($act == 'jobs_batch_executive')
{
	check_permissions($_SESSION['admin_purview'],"jobs_batch");	
	set_time_limit (0);
	$addtime_min=$_POST['addtime_min']?convert_datefm($_POST['addtime_min'],2):"";
	$addtime_min=intval($addtime_min);
	$addtime_max=$_POST['addtime_max']?convert_datefm ($_POST['addtime_max'],2):"";
	$addtime_max=intval($addtime_max);
	$refreshtime_min=$_POST['refreshtime_min']?convert_datefm ($_POST['refreshtime_min'],2):"";
	$refreshtime_min=intval($refreshtime_min);
	$refreshtime_max=$_POST['refreshtime_max']?convert_datefm ($_POST['refreshtime_max'],2):"";
	$refreshtime_max=intval($refreshtime_max);
	$expired_days=intval($_POST['expired_days']);
	$jobs_name=trim($_POST['jobs_name']);
	$companyname=trim($_POST['companyname']);
	$_POST['robot']<>""? $wheresqlarr['robot']=intval($_POST['robot']):'';
	$_POST['emergency']<>""? $wheresqlarr['emergency']=intval($_POST['emergency']):'';
	$_POST['level']<>""? $wheresqlarr['level']=intval($_POST['level']):'';
	$_POST['recommend']<>""? $wheresqlarr['recommend']=intval($_POST['recommend']):'';
	$_POST['audit']<>""? $wheresqlarr['audit']=intval($_POST['audit']):'';
	$_POST['display']<>""? $wheresqlarr['display']=intval($_POST['display']):'';
	if (is_array($wheresqlarr)) $wheresql=wheresql($wheresqlarr);
	if ($addtime_min>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " addtime>".$addtime_min;
	}
	if ($addtime_max>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " addtime<".$addtime_max;
	}
	if ($refreshtime_min>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " refreshtime>".$refreshtime_min;
	}
	if ($refreshtime_max>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " refreshtime<".$refreshtime_max;
	}
	if ($expired_days>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " deadline<".strtotime("-".$expired_days." day");
	}
	if (!empty($jobs_name))
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " jobs_name  like '%{".$jobs_name."}%'";
	}
	if (!empty($companyname))
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " companyname  like '%{".$companyname."}%'";
	}
	if (empty($wheresql))
	{
	adminmsg("����ʧ�ܣ���û��ѡ���κ�ɸѡ������",0);
	exit();
	}
	$row_count_max=$_POST['row_count_max'];
	$limit=$row_count_max==""?"":intval($row_count_max);
	if ($limit=="0")
	{
	adminmsg("�����Ӧ������д����",0);
	exit();
	}
	$limit=$limit?" limit ".$limit:'';
	$set_type=$_POST['set_type'];
	$set_type_id=intval($_POST['set_type_id']);
	if ($set_type=="set_del")
	{
		if ($db->query("Delete from ".table('jobs').$wheresql.$limit))
		{
		adminmsg("ɾ���ɹ����ܼ�ɾ��".$db->affected_rows()."��",2);
		}
	}
	elseif ($set_type=="set_audit")
	{
		if ($db->query("update ".table('jobs')." SET audit=".intval($set_type_id).$wheresql.$limit))
		{
		adminmsg("�����ɹ�����Ӧ����Ϊ��".$db->affected_rows()."��",2);
		}
	}
	elseif ($set_type=="set_emergency")
	{
		if ($db->query("update ".table('jobs')." SET emergency=".intval($set_type_id).$wheresql.$limit))
		{
		adminmsg("�����ɹ�����Ӧ����Ϊ��".$db->affected_rows()."��",2);
		}
	}
	elseif ($set_type=="set_recommend")
	{
		if ($db->query("update ".table('jobs')." SET recommend=".intval($set_type_id).$wheresql.$limit))
		{
		adminmsg("�����ɹ�����Ӧ����Ϊ��".$db->affected_rows()."��",2);
		}
	}
	elseif ($set_type=="set_display")
	{
		if ($db->query("update ".table('jobs')." SET display=".intval($set_type_id).$wheresql.$limit))
		{
		adminmsg("�����ɹ�����Ӧ����Ϊ��".$db->affected_rows()."��",2);
		}
	}	
}
elseif($act == 'company_list')
{
	check_permissions($_SESSION['admin_purview'],"com_show");
	require_once(QISHI_ROOT_PATH.'include/page.class.php');
	$oederbysql=" order BY c.id DESC ";
	$key=isset($_GET['key'])?trim($_GET['key']):"";
	$key_type=isset($_GET['key_type'])?intval($_GET['key_type']):"";
	if ($key && $key_type>0)
	{
		
		if     ($key_type===1)$wheresql=" WHERE c.companyname like '%{$key}%'";
		elseif ($key_type===2)$wheresql=" WHERE m.username like '{$key}%'";
		elseif ($key_type===3)$wheresql=" WHERE c.address  like '%{$key}%'";
		elseif ($key_type===4)$wheresql=" WHERE c.telephone  like '{$key}%'";		
		$oederbysql="";
	}
	$_GET['audit']<>""? $wheresqlarr['c.audit']=intval($_GET['audit']):'';
	$_GET['recommend']<>""? $wheresqlarr['c.recommend']=intval($_GET['recommend']):'';
	if (is_array($wheresqlarr)) $wheresql=wheresql($wheresqlarr);
	if (!empty($_GET['settr']))
	{
		$settr=strtotime("-".intval($_GET['settr'])." day");
		$wheresql=empty($wheresql)?" WHERE addtime> ".$settr:$wheresql." AND addtime> ".$settr;
	}
	$joinsql=" LEFT JOIN ".table('members')." AS m ON c.uid=m.uid  ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('company_profile')." AS c".$joinsql.$wheresql;
	$total_val=get_total($total_sql);
	$page = new page(array('total'=>$total_val, 'perpage'=>$perpage));
	$currenpage=$page->nowindex;
	$offset=($currenpage-1)*$perpage;
	$clist = get_company_profile($offset,$perpage,$joinsql.$wheresql.$oederbysql);
	$smarty->assign('pageheader',"74CMS �������� - ��ҵ�б�");
	$smarty->assign('clist',$clist);
	$smarty->assign('certificate_dir',$certificate_dir);
	if ($total_val>$perpage) $smarty->assign('page',$page->show(3));
	$smarty->display('company/admin_company_list.htm');
}
elseif($act == 'company_perform')
{
	$u_id =!empty($_POST['y_id'])?$_POST['y_id']:adminmsg("��û��ѡ����ҵ��",1);
	if ($_POST['delete'])
	{
		check_permissions($_SESSION['admin_purview'],"com_del");
		if ($_POST['delete_company']=='yes')
		{
		!del_company($u_id)?adminmsg("ɾ����ҵ����ʧ�ܣ�",0):"";
		}
		if ($_POST['delete_jobs']=='yes')
		{
		!del_company_alljobs($u_id)?adminmsg("ɾ��ְλʧ�ܣ�",0):"";
		}
		if ($_POST['delete_jobs']<>'yes' && $_POST['delete_company']<>'yes')
		{
		adminmsg("δѡ��ɾ�����ͣ�",1);
		}
		adminmsg("ɾ���ɹ���",2);
	}
	if (trim($_POST['set_audit']))
	{
	check_permissions($_SESSION['admin_purview'],"com_audit");
	$audit=$_POST['audit'];
	!edit_company_audit($u_id,intval($audit))?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2);
	}
	if (trim($_POST['set_recommend']))
	{
	check_permissions($_SESSION['admin_purview'],"com_recommend");
	$recommend=$_POST['recommend'];
	!edit_company_recommend($u_id,intval($recommend))?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2);
	}
}
elseif($act == 'edit_company_profile')
{
	check_permissions($_SESSION['admin_purview'],"com_edit");
	$yid =!empty($_REQUEST['id'])?intval($_REQUEST['id']):adminmsg("��û��ѡ����ҵ��",1);
	$smarty->assign('pageheader',"74CMS �������� - ��ҵ�б� - �޸���ҵ��Ϣ");
	$company_profile=get_company_profile_one($yid);
	$smarty->assign('url',$_SERVER["HTTP_REFERER"]);
	$smarty->assign('company_profile',$company_profile);
	$smarty->assign('certificate_dir',$certificate_dir);//Ӫҵִ��·��
	$smarty->display('company/admin_company_profile_edit.htm');
}
elseif ($act=='company_profile_save')
{
	check_permissions($_SESSION['admin_purview'],"com_edit");
	$setsqlarr=array();
	$contents=array();
	$id=intval($_POST['id']);
	$setsqlarr['audit']=intval($_POST['audit']);
	$setsqlarr['recommend']=intval($_POST['recommend']);
	$setsqlarr['companyname']=trim($_POST['companyname'])?trim($_POST['companyname']):adminmsg('��û��������ҵ���ƣ�',1);
	$setsqlarr['nature']=trim($_POST['nature'])?trim($_POST['nature']):adminmsg('��ѡ����ҵ���ʣ�',1);
	$setsqlarr['nature_cn']=trim($_POST['nature_cn'])?trim($_POST['nature_cn']):adminmsg('��ѡ����ҵ���ʣ�',1);
	$setsqlarr['trade']=trim($_POST['trade'])?trim($_POST['trade']):adminmsg('��ѡ��������ҵ��',1);
	$setsqlarr['trade_cn']=trim($_POST['trade_cn'])?trim($_POST['trade_cn']):adminmsg('��ѡ��������ҵ��',1);
	$setsqlarr['district_cn']=trim($_POST['district_cn'])?trim($_POST['district_cn']):adminmsg('��ѡ������������',1);
	$setsqlarr['district']=intval($_POST['district']);
	$setsqlarr['sdistrict']=intval($_POST['sdistrict']);
	$setsqlarr['scale']=trim($_POST['scale'])?trim($_POST['scale']):adminmsg('��ѡ��˾��ģ��',1);
	$setsqlarr['scale_cn']=trim($_POST['scale_cn'])?trim($_POST['scale_cn']):adminmsg('��ѡ��˾��ģ��',1);	
	$setsqlarr['registered']=trim($_POST['registered']);
	$setsqlarr['currency']=trim($_POST['currency']);
	$setsqlarr['address']=trim($_POST['address']);
	$setsqlarr['contact']=trim($_POST['contact']);
	$setsqlarr['telephone']=trim($_POST['telephone']);
	$setsqlarr['email']=trim($_POST['email']);
	$setsqlarr['website']=trim($_POST['website']);
	$setsqlarr['contents']=trim($_POST['contents'])?trim($_POST['contents']):adminmsg('����д��˾��飡',1);
	$wheresql=" id='".$id."' ";
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = $_POST['url'];
		if (updatetable(table('company_profile'),$setsqlarr,$wheresql))
		{
				$jobarr['companyname']=$setsqlarr['companyname'];
				$jobarr['trade']=$setsqlarr['trade'];
				$jobarr['trade_cn']=$setsqlarr['trade_cn'];
				if (!updatetable(table('jobs'),$jobarr," uid=".intval($_POST['cuid'])."")) adminmsg('�޸�ְλ���ֳ�����',0);
		unset($setsqlarr);
		adminmsg("����ɹ���",2,$link);
		}
		else
		{
		unset($setsqlarr);
		adminmsg("����ʧ�ܣ�",0);
		}
}
elseif($act == 'order_list')
{	
	check_permissions($_SESSION['admin_purview'],"ord_show");
		require_once(QISHI_ROOT_PATH.'include/page.class.php');
		require_once(ADMIN_ROOT_PATH.'include/admin_pay_fun.php');
	$wheresql="";
	$oederbysql=" order BY o.addtime DESC ";
	$key=isset($_GET['key'])?trim($_GET['key']):"";
	$key_type=isset($_GET['key_type'])?intval($_GET['key_type']):"";
	if ($key && $key_type>0)
	{
		if     ($key_type===1)$wheresql=" WHERE c.companyname like '%{$key}%'";
		elseif ($key_type===2)$wheresql=" WHERE m.username = '{$key}'";
		elseif ($key_type===3)$wheresql=" WHERE o.oid ='".trim($key)."'";
		$oederbysql="";
	}
	else
	{	
		!empty($_GET['is_paid'])? $wheresqlarr['o.is_paid']=intval($_GET['is_paid']):'';
		!empty($_GET['typename'])?$wheresqlarr['o.payment_name']=trim($_GET['typename']):'';
		if (is_array($wheresqlarr)) $wheresql=wheresql($wheresqlarr);
		
		if (!empty($_GET['settr']))
		{
			$settr=strtotime("-".intval($_GET['settr'])." day");
			$wheresql.=empty($wheresql)?" WHERE ": " AND ";
			$wheresql.="o.addtime> ".$settr;
		}
	}
	$joinsql=" left JOIN ".table('members')." as m ON o.uid=m.uid LEFT JOIN  ".table('company_profile')." as c ON o.uid=c.uid ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('order')." as o ".$joinsql.$wheresql;
	$total_val=get_total($total_sql);
	$page = new page(array('total'=>$total_val, 'perpage'=>$perpage));
	$currenpage=$page->nowindex;
	$offset=($currenpage-1)*$perpage;
	$orderlist = get_order_list($offset,$perpage,$joinsql.$wheresql.$oederbysql);
	$smarty->assign('pageheader',"74CMS �������� - ��������");
	$smarty->assign('payment_list',get_payment(2));
	$smarty->assign('orderlist',$orderlist);
		if ($total_val>$perpage)$smarty->assign('page',$page->show(3));
	$smarty->display('company/admin_order_list.htm');
}
elseif($act == 'show_order')
{
	check_permissions($_SESSION['admin_purview'],"ord_show");
	$smarty->assign('pageheader',"74CMS �������� - ��ֵ��¼ - �鿴");
	$smarty->assign('url',$_SERVER["HTTP_REFERER"]);
	$smarty->assign('payment',get_order_one($_GET['id']));
	$smarty->display('company/admin_order_show.htm');
}
elseif($act == 'order_notes_save')
{
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = $_POST['url'];
	!$db->query("UPDATE ".table('order')." SET  notes='".$_POST['notes']."' WHERE id='".intval($_GET['id'])."'")?adminmsg('����ʧ��',1):adminmsg("�����ɹ���",2,$link);
}
//���ó�ֵ��¼���տͨ��
elseif($act == 'order_set')
{
	check_permissions($_SESSION['admin_purview'],"ord_set");
	$smarty->assign('pageheader',"74CMS �������� - ��ֵ��¼ - ����");
	$smarty->assign('url',$_SERVER["HTTP_REFERER"]);
	$smarty->assign('payment',get_order_one($_GET['id']));
	$smarty->display('company/admin_order_set.htm');
}
elseif($act == 'order_set_save')
{
	check_permissions($_SESSION['admin_purview'],"ord_set");
		if (order_paid(trim($_POST['oid'])))
		{
		$link[0]['text'] = "�����б�";
		$link[0]['href'] = $_POST['url'];
		!$db->query("UPDATE ".table('order')." SET notes='".$_POST['notes']."' WHERE id=".intval($_GET['id'])."  LIMIT 1 ")?adminmsg('����ʧ��',1):adminmsg("�����ɹ���",2,$link);
		}
		else
		{
		adminmsg('����ʧ��',1);
		}
}
//ȡ����Ա��ֵ����
elseif($act == 'order_del')
{
	check_permissions($_SESSION['admin_purview'],"ord_del");
	$id =!empty($_REQUEST['id'])?$_REQUEST['id']:adminmsg("��û��ѡ����Ŀ��",1);
	if (del_order($id))
	{
	adminmsg("ȡ���ɹ���",2,$link);
	}
	else
	{
	adminmsg("ȡ��ʧ�ܣ�",1);
	}
}
elseif($act == 'members_list')
{
	check_permissions($_SESSION['admin_purview'],"com_user_show");
		require_once(QISHI_ROOT_PATH.'include/page.class.php');
	$wheresql="";
	$oederbysql=" order BY m.uid DESC ";
	$key=isset($_GET['key'])?trim($_GET['key']):"";
	$key_type=isset($_GET['key_type'])?intval($_GET['key_type']):"";
	if ($key && $key_type>0)
	{
		if     ($key_type===1)$wheresql.=" WHERE m.username = '{$key}'";
		elseif ($key_type===2)$wheresql.=" WHERE m.email = '{$key}'";
		elseif ($key_type===3)$wheresql.=" WHERE c.companyname like '%{$key}%'";
		$oederbysql="";
	}
	else
	{	
		if (!empty($_GET['settr']))
		{
			$settr=strtotime("-".intval($_GET['settr'])." day");
			$wheresql.=" WHERE m.reg_time> ".$settr;
		}
	}
	$joinsql=" INNER JOIN  ".table('members')." as m ON t.utype=1 and  t.uid=m.uid LEFT JOIN ".table('company_profile')." as c ON t.uid=c.uid   ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('members_type')." as t ".$joinsql.$wheresql;
	$total_val=get_total($total_sql);
	$page = new page(array('total'=>$total_val, 'perpage'=>$perpage));
	$currenpage=$page->nowindex;
	$offset=($currenpage-1)*$perpage;
	$member = get_member_list($offset,$perpage,$joinsql.$wheresql.$oederbysql);
	$smarty->assign('pageheader',"74CMS �������� - ��ҵ��Ա�б�");
	$smarty->assign('member',$member);
		if ($total_val>$perpage)$smarty->assign('page',$page->show(3));
	$smarty->display('company/admin_company_user_list.htm');
}
elseif($act == 'delete_user')
{	
	check_permissions($_SESSION['admin_purview'],"com_user_del");
	$tuid =!empty($_REQUEST['tuid'])?$_REQUEST['tuid']:adminmsg("��û��ѡ���Ա��",1);
	if ($_POST['delete'])
	{
		if (!empty($_POST['delete_user']))
		{
		!delete_company_user($tuid)?adminmsg("ɾ����Աʧ�ܣ�",0):"";
		}
		if (!empty($_POST['delete_company']))
		{
		!del_company($tuid)?adminmsg("ɾ����ҵ����ʧ�ܣ�",0):"";
		}
		if (!empty($_POST['delete_jobs']))
		{
		!del_company_alljobs($tuid)?adminmsg("ɾ��ְλʧ�ܣ�",0):"";
		}
	adminmsg("ɾ���ɹ���",2);
	}
}
elseif($act == 'members_add')
{
	check_permissions($_SESSION['admin_purview'],"com_user_add");
	$smarty->assign('pageheader',"74CMS �������� - ��ҵ��Ա - ������ҵ��Ա");
	$smarty->assign('givesetmeal',get_setmeal(false));
	$smarty->assign('points',get_cache('members_points_rule'));
	$smarty->display('company/admin_company_user_add.htm');
}
elseif($act == 'members_add_save')
{
	check_permissions($_SESSION['admin_purview'],"com_user_add");
	require_once(ADMIN_ROOT_PATH.'include/admin_user_fun.php');
	$add_username = !empty($_POST['username']) ? trim($_POST['username']):adminmsg('����д�û�����',1);
	$add_password = !empty($_POST['password']) ? trim($_POST['password']):adminmsg('����д���룡',1);
	if (strlen(trim($_POST['username']))<3) adminmsg('�û�������Ϊ3λ���ϣ�',1);
	if (strlen(trim($_POST['password']))<6) adminmsg('�������Ϊ6λ���ϣ�',1);
	($add_password<>trim($_POST['password1']))? adminmsg('������������벻��ͬ��',1):'';
	$add_member_type = !empty($_POST['member_type']) ? trim($_POST['member_type']):adminmsg('��û��ѡ��ע�����ͣ�',1);
	$add_email = !empty($_POST['email']) ? trim($_POST['email']):adminmsg('����д�������䣡',1);
	if (empty($add_email) || !ereg("^[-a-zA-Z0-9_\.]+\@([0-9A-Za-z][0-9A-Za-z-]+\.)+[A-Za-z]{2,5}$",$add_email))adminmsg('���������ʽ����',1);
	$add_member_type=intval($add_member_type);
	$ck_user=get_company_user($add_username);
	$ck_user?adminmsg('���û����Ѿ���ʹ�ã�',1):'';
	$ck_email=get_company_user($add_email);
	$ck_email?adminmsg('�� Email �Ѿ���ע�ᣡ',1):'';
		if (!$ck_user && !$ck_email)
		{
				if(defined('UC_API'))
				{
					include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
					if (uc_user_checkname($add_username)<>"1")
					{
					adminmsg('���û����Ѿ���ʹ�û����û����Ƿ���',1);
					exit();
					}
					elseif (uc_user_checkemail($add_email)<>"1")
					{
					adminmsg('�� Email�Ѿ���ʹ�û��߷Ƿ���',1);
					exit();
					}
					else
					{
					uc_user_register($add_username, $add_password , $add_email);
					}
				}
		$pwd_hash=randstr();
		$password_hash=md5(md5($add_password).$pwd_hash);
		$sql = "INSERT INTO ".table('members')." (username,password,pwd_hash,email,reg_time,reg_ip) VALUES ('$add_username','$password_hash','$pwd_hash', '$add_email', '$timestamp','$online_ip')";
		$db->query($sql);
		$insert_id=$db->insert_id();
		$sql1 = "INSERT INTO ".table('members_type')." (uid,utype) VALUES ('$insert_id','$add_member_type')";
		$db->query($sql1);
			if($add_member_type=="1")
			{
			$db->query("INSERT INTO ".table('members_points')." (uid) VALUES ('".$insert_id."')");
			$db->query("INSERT INTO ".table('members_setmeal')." (uid) VALUES ('".$insert_id."')");
				$regpoints_num=intval($_POST['regpoints_num']);
				if ($_POST['regpoints']=="y")
				{
				$regpoints_num>0?report_deal($insert_id,1,$regpoints_num,'<span style=color:#FF6600>ע���Աϵͳ�Զ�����!</span>'):'';
				}
				$reg_service=intval($_POST['reg_service']);
				if ($reg_service>0)
				{
				set_members_setmeal($insert_id,$reg_service);
				}			
			}
		}
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = "?act=members_list";
	$link[1]['text'] = "��������";
	$link[1]['href'] = "?act=members_add";
	adminmsg('���ӳɹ���',2,$link);
}
elseif($act == 'user_edit')
{
	check_permissions($_SESSION['admin_purview'],"com_user_edit");
	$company_user=get_user($_GET['tuid']);
	$smarty->assign('pageheader',"74CMS �������� - ��ҵ��Ա - �޸�");
	$smarty->assign('company_user',$company_user);
	$smarty->assign('userpoints',get_user_points($company_user['uid']));
	$smarty->assign('setmeal',get_user_setmeal($company_user['uid']));
	$smarty->assign('givesetmeal',get_setmeal(false));
	$smarty->assign('url',$_SERVER["HTTP_REFERER"]);
	$smarty->display('company/admin_company_user_edit.htm');
}
elseif($act == 'userpoints_edit')
{
	check_permissions($_SESSION['admin_purview'],"com_user_edit");
	if (intval($_POST['points'])<1) adminmsg('��������֣�',1);
	if (trim($_POST['points_notes'])=='') adminmsg('����д���ֲ���˵����',1);
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = $_POST['url'];
	report_deal(intval($_POST['company_uid']),intval($_POST['points_type']),intval($_POST['points']),trim($_POST['points_notes']))?adminmsg('�����ɹ���',2,$link):adminmsg('����ʧ�ܣ�',1);
}
elseif($act == 'set_setmeal_save')
{
	check_permissions($_SESSION['admin_purview'],"com_user_edit");
    if (intval($_POST['reg_service'])>0)
	{
		if (set_members_setmeal($_POST['company_uid'],$_POST['reg_service']))
		{
		$link[0]['text'] = "�����б�";
		$link[0]['href'] = $_POST['url'];
		adminmsg('�����ɹ���',2,$link);
		}
		else
		{
		adminmsg('����ʧ�ܣ�',1);
		}
	}
	else
	{
	adminmsg('��ѡ������ײͣ�',1);
	}	
}
elseif($act == 'edit_setmeal_save')
{
    check_permissions($_SESSION['admin_purview'],"com_user_edit");
	$setsqlarr['jobs_ordinary']=$_POST['jobs_ordinary'];
	$setsqlarr['jobs_emergency']=$_POST['jobs_emergency'];
	$setsqlarr['jobs_headhunting']=$_POST['jobs_headhunting'];
	$setsqlarr['download_resume_ordinary']=$_POST['download_resume_ordinary'];
	$setsqlarr['download_resume_senior']=$_POST['download_resume_senior'];
	$setsqlarr['interview_ordinary']=$_POST['interview_ordinary'];
	$setsqlarr['interview_senior']=$_POST['interview_senior'];
	$setsqlarr['talent_pool']=$_POST['talent_pool'];
	$setsqlarr['recommended']=$_POST['recommended'];
	$setsqlarr['map']=$_POST['map'];
	$setsqlarr['added']=$_POST['added'];
	if ($_POST['days']<>"")
	{
			if (intval($_POST['days'])>0)
			{
				$setsqlarr['endtime']=strtotime("".intval($_POST['days'])." days",intval($_POST['starttime']));
			}
			if (intval($_POST['days'])=="0")
			{
				$setsqlarr['endtime']=0;
			}
	}
	$company_uid=intval($_POST['company_uid']);
	if ($company_uid)
	{
			if (!updatetable(table('members_setmeal'),$setsqlarr," uid=".$company_uid."")) adminmsg('�޸ĳ�����',0);
			$setsqlarrmap['map_open']=$setsqlarr['map'];
			if (!updatetable(table('company_profile'),$setsqlarrmap," uid=".$company_uid."")) adminmsg('�޸ĳ�����',0);
			$recommendedarr['recommend']=$setsqlarr['recommended'];
			if (!updatetable(table('company_profile'),$recommendedarr," uid=".$company_uid."")) adminmsg('�޸ĳ�����',0);
			if ($setsqlarr['endtime']<>"")
			{
				$setmeal_deadline['setmeal_deadline']=$setsqlarr['endtime'];
				if (!updatetable(table('jobs'),$setmeal_deadline," uid=".$company_uid.""))adminmsg('�޸ĳ�����',0);
				if (!updatetable(table('company_profile'),$setmeal_deadline," uid=".$company_uid."")) adminmsg('�޸ĳ�����',0);
			}
	}
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = $_POST['url'];
	adminmsg('�����ɹ���',2,$link);
}
elseif($act == 'userpass_edit')
{
	check_permissions($_SESSION['admin_purview'],"com_user_edit");
	if (strlen(trim($_POST['password']))<6) adminmsg('���������Ϊ6λ���ϣ�',1);
	require_once(ADMIN_ROOT_PATH.'include/admin_user_fun.php');
	$user_info=get_user_inusername($_POST['username']);
	$pwd_hash=$user_info['pwd_hash'];
	$md5password=md5(md5(trim($_POST['password'])).$pwd_hash);	
	if ($db->query( "UPDATE ".table('members')." SET password = '$md5password'  WHERE uid='".$user_info['uid']."'"))
	{
			if(defined('UC_API'))
			{
			include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
			uc_user_edit($user_info['username'],trim($_POST['password']),trim($_POST['password']),"",1);
			}
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = $_POST['url'];
	adminmsg('�����ɹ���',2,$link);
	}
	else
	{
	adminmsg('����ʧ�ܣ�',1);
	}
}
elseif($act == 'userstatus_edit')
{
	check_permissions($_SESSION['admin_purview'],"com_user_edit");
	if ($db->query( "UPDATE ".table('members')." SET status = '".intval($_POST['status'])."'  WHERE uid='".intval($_POST['userstatus_uid'])."'"))
	{
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = $_POST['url'];
	adminmsg('�����ɹ���',2,$link);
	}
	else
	{
	adminmsg('����ʧ�ܣ�',1);
	}
}
?>