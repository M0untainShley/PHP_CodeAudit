<?php
 /*
 * 74cms ��ҵ�û����
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
define('IN_QISHI', true);
require_once(dirname(__FILE__).'/../data/config.php');
require_once(dirname(__FILE__).'/include/admin_common.inc.php');
require_once(ADMIN_ROOT_PATH.'include/admin_personal_fun.php');
!empty($_POST['perpage'])?(setcookie('perpage',intval($_POST['perpage']))).($perpage=intval($_POST['perpage'])):($perpage= !empty($_COOKIE['perpage'])? $_COOKIE['perpage'] :'10');
$act = !empty($_GET['act']) ? trim($_GET['act']) : 'list';
if($act == 'list')
{
	check_permissions($_SESSION['admin_purview'],"resume_show");
	require_once(QISHI_ROOT_PATH.'include/page.class.php');
	$oederbysql=" order BY r.id DESC ";
	$key=isset($_GET['key'])?trim($_GET['key']):"";
	$key_type=isset($_GET['key_type'])?intval($_GET['key_type']):"";
	if ($key && $key_type>0)
	{
		
		if     ($key_type===1)$wheresql=" WHERE r.fullname like '%{$key}%'";
		elseif ($key_type===2)$wheresql=" WHERE m.username like '{$key}%'";	
		elseif ($key_type===3)$wheresql=" WHERE m.telephone like '{$key}%'";		
		$oederbysql="";
	}
	!empty($_GET['audit'])? $wheresqlarr['r.audit']=intval($_GET['audit']):'';
	!empty($_GET['talent'])? $wheresqlarr['r.talent']=intval($_GET['talent']):'';
	!empty($_GET['photo_audit'])? $wheresqlarr['r.photo_audit']=intval($_GET['photo_audit']):'';	
	if (intval($_GET['photoresume'])=="1")
	{
		$wheresqlarr['r.photo']='';
	}
	if (intval($_GET['photoresume'])=="2")
	{
		$wheresqlarr['r.photo!']='';
	}
	if (is_array($wheresqlarr)) $wheresql=wheresql($wheresqlarr);	
	if (!empty($_GET['settr']))
	{
		$settr=strtotime("-".intval($_GET['settr'])." day");
		$wheresql=empty($wheresql)?" WHERE r.addtime> ".$settr:$wheresql." AND r.addtime> ".$settr;
	}
	$joinsql=" LEFT JOIN ".table('members')." AS m ON r.uid=m.uid  ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('resume')." AS r ".$joinsql.$wheresql;
	$total_val=get_total($total_sql);
	$page = new page(array('total'=>$total_val, 'perpage'=>$perpage));
	$currenpage=$page->nowindex;
	$offset=($currenpage-1)*$perpage;
	$resumelist = get_resume_list($offset,$perpage,$joinsql.$wheresql.$oederbysql);
	$smarty->assign('pageheader',"74CMS �������� - �����б�");
	$smarty->assign('resumelist',$resumelist);
	if ($total_val>$perpage)$smarty->assign('page',$page->show(3));
	$smarty->display('personal/admin_personal_resume.htm');
}
elseif($act == 'perform')
{
		$id =!empty($_REQUEST['id'])?$_REQUEST['id']:adminmsg("��û��ѡ�������",1);
		if (!empty($_REQUEST['delete']))
		{
		check_permissions($_SESSION['admin_purview'],"resume_del");
		!del_resume($id)?adminmsg("ɾ��ʧ�ܣ�",0,$link):adminmsg("ɾ���ɹ���",2,$link);
		}
		if (!empty($_POST['set_audit']))
		{
		check_permissions($_SESSION['admin_purview'],"resume_audit");
		$audit=$_POST['audit'];
		!edit_resume_audit($id,$audit)?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2,$link);
		}
		if (!empty($_POST['set_talent']))
		{
		check_permissions($_SESSION['admin_purview'],"resume_talent");
		$talent=$_POST['talent'];
		!edit_resume_talent($id,$talent)?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2,$link);
		}
		if (!empty($_POST['set_photoaudit']))
		{
		check_permissions($_SESSION['admin_purview'],"resume_photo_audit");
		$photoaudit=$_POST['photoaudit'];
		!edit_resume_photoaudit($id,$photoaudit)?adminmsg("����ʧ�ܣ�",0):adminmsg("���óɹ���",2,$link);
		}
}
elseif($act == 'resume_batch')
{
	$smarty->assign('pageheader',"74CMS �������� - ������������");
	$smarty->display('personal/admin_personal_resume_batch.htm');
}
elseif($act == 'resume_batch_executive')
{
	check_permissions($_SESSION['admin_purview'],"resume_batch");	
	set_time_limit (0);
	$addtime_min=$_POST['addtime_min']?convert_datefm($_POST['addtime_min'],2):"";
	$addtime_min=intval($addtime_min);
	$addtime_max=$_POST['addtime_max']?convert_datefm ($_POST['addtime_max'],2):"";
	$addtime_max=intval($addtime_max);
	$refreshtime_min=$_POST['refreshtime_min']?convert_datefm ($_POST['refreshtime_min'],2):"";
	$refreshtime_min=intval($refreshtime_min);
	$refreshtime_max=$_POST['refreshtime_max']?convert_datefm ($_POST['refreshtime_max'],2):"";
	$refreshtime_max=intval($refreshtime_max);
	$expired_days=intval($_POST['expired_days']);
	$fullname=trim($_POST['fullname']);
	$_POST['audit']<>""? $wheresqlarr['audit']=intval($_POST['audit']):'';
	$_POST['talent']<>""? $wheresqlarr['talent']=intval($_POST['talent']):'';
	$_POST['display']<>""? $wheresqlarr['display']=intval($_POST['display']):'';
	$_POST['photo_audit']<>""? $wheresqlarr['photo_audit']=intval($_POST['photo_audit']):'';
	if (is_array($wheresqlarr)) $wheresql=wheresql($wheresqlarr);
	if ($addtime_min>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " addtime>".$addtime_min;
	}
	if ($addtime_max>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " addtime<".$addtime_max;
	}
	if ($refreshtime_min>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " refreshtime>".$refreshtime_min;
	}
	if ($refreshtime_max>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " refreshtime<".$refreshtime_max;
	}
	if ($expired_days>0)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " deadline<".strtotime("-".$expired_days." day");
	}
	if (!empty($fullname))
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " fullname  like '%{".$fullname."}%'";
	}
	if (intval($_POST['photo'])==1)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " photo='' ";
	}
	elseif (intval($_POST['photo'])==2)
	{
	 	$wheresql.=$wheresql?" AND ":" WHERE ";
		$wheresql.= " photo<>'' ";
	} 
	if (empty($wheresql))
	{
	adminmsg("����ʧ�ܣ���û��ѡ���κ�ɸѡ������",0);
	exit();
	}
	$row_count_max=$_POST['row_count_max'];
	$limit=$row_count_max==""?"":intval($row_count_max);
	if ($limit=="0")
	{
	adminmsg("�����Ӧ������д����",0);
	exit();
	}
	$limit=$limit?" limit ".$limit:'';
	$set_type=$_POST['set_type'];
	$set_type_id=intval($_POST['set_type_id']);
	if ($set_type=="set_del")
	{
		if ($db->query("Delete from ".table('resume').$wheresql.$limit))
		{
		adminmsg("ɾ���ɹ����ܼ�ɾ��".$db->affected_rows()."��",2);
		}
	}
	elseif ($set_type=="set_audit")
	{
		if ($db->query("update ".table('resume')." SET audit=".intval($set_type_id).$wheresql.$limit))
		{
		adminmsg("�����ɹ�����Ӧ����Ϊ��".$db->affected_rows()."��",2);
		}
	}
	elseif ($set_type=="set_talent")
	{
		if ($db->query("update ".table('resume')." SET talent=".intval($set_type_id).$wheresql.$limit))
		{
		adminmsg("�����ɹ�����Ӧ����Ϊ��".$db->affected_rows()."��",2);
		}
	}
	elseif ($set_type=="set_photo_audit")
	{
		if ($db->query("update ".table('resume')." SET photo_audit=".intval($set_type_id).$wheresql.$limit))
		{
		adminmsg("�����ɹ�����Ӧ����Ϊ��".$db->affected_rows()."��",2);
		}
	}
}
elseif($act == 'members_list')
{
	check_permissions($_SESSION['admin_purview'],"per_user_show");
		require_once(QISHI_ROOT_PATH.'include/page.class.php');
	$wheresql="";
	$oederbysql=" order BY m.uid DESC ";
	$key=isset($_GET['key'])?trim($_GET['key']):"";
	$key_type=isset($_GET['key_type'])?intval($_GET['key_type']):"";
	if ($key && $key_type>0)
	{
		if     ($key_type===1)$wheresql.=" WHERE m.username = '{$key}'";
		elseif ($key_type===2)$wheresql.=" WHERE m.email = '{$key}'";
		$oederbysql="";
	}
	else
	{	
		if (!empty($_GET['settr']))
		{
			$settr=strtotime("-".intval($_GET['settr'])." day");
			$wheresql.=" WHERE m.reg_time> ".$settr;
		}
	}
	$joinsql=" INNER JOIN  ".table('members')." as m ON t.utype=2 and  t.uid=m.uid ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('members_type')." as t ".$joinsql.$wheresql;
	$total_val=get_total($total_sql);
	$page = new page(array('total'=>$total_val, 'perpage'=>$perpage));
	$currenpage=$page->nowindex;
	$offset=($currenpage-1)*$perpage;
	$member = get_member_list($offset,$perpage,$joinsql.$wheresql.$oederbysql);
	$smarty->assign('pageheader',"74CMS �������� - ���˻�Ա�б�");
	$smarty->assign('member',$member);
		if ($total_val>$perpage)$smarty->assign('page',$page->show(3));
	$smarty->display('personal/admin_personal_user_list.htm');
}
elseif($act == 'delete_user')
{
	check_permissions($_SESSION['admin_purview'],"per_user_del");
	$tuid =!empty($_POST['tuid'])?$_POST['tuid']:adminmsg("��û��ѡ���Ա��",1);
	if ($_POST['delete'])
	{
	trim($_POST['delete_user'])==='yes'?(!delete_member($tuid)?adminmsg("ɾ����Աʧ�ܣ�",0).(exit()):""):'';
	trim($_POST['delete_resume'])==='yes'?(!del_resume($tuid)?adminmsg("ɾ��ʧ�ܣ�",0).(exit()):""):'';
	adminmsg("ɾ���ɹ���",2);
	}
}
elseif($act == 'user_edit')
{	
	check_permissions($_SESSION['admin_purview'],"per_user_edit");
	$smarty->assign('pageheader',"74CMS �������� - ���˻�Ա - �޸�");
	$smarty->assign('user',get_member_one($_GET['tuid']));
	$smarty->assign('resume',get_resume_basic($_GET['tuid']));
	$smarty->assign('url',$_SERVER["HTTP_REFERER"]);
	$smarty->display('personal/admin_personal_user_edit.htm');
}
elseif($act == 'userpass_edit')
{
	check_permissions($_SESSION['admin_purview'],"per_user_edit");
	if (strlen(trim($_POST['password']))<6) adminmsg('���������Ϊ6λ���ϣ�',1);
	$user_info=get_member_one($_POST['memberuid']);
	$pwd_hash=$user_info['pwd_hash'];
	$md5password=md5(md5(trim($_POST['password'])).$pwd_hash);	
		if ($db->query( "UPDATE ".table('members')." SET password = '$md5password'  WHERE uid='".$user_info['uid']."' LIMIT 1"))
		{
				if(defined('UC_API'))
				{
				include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
				uc_user_edit($user_info['username'],trim($_POST['password']),trim($_POST['password']),"",1);
				}
		$link[0]['text'] = "�����б�";
		$link[0]['href'] = $_POST['url'];
		adminmsg('�����ɹ���',2,$link);
		}
		else
		{
		adminmsg('����ʧ�ܣ�',1);
		}
}
elseif($act == 'members_add')
{
	check_permissions($_SESSION['admin_purview'],"per_user_add");
	$smarty->assign('pageheader',"74CMS �������� - ���˻�Ա - ���Ӹ��˻�Ա");
	$smarty->display('personal/admin_personal_user_add.htm');
}
elseif($act == 'members_add_save')
{
	check_permissions($_SESSION['admin_purview'],"per_user_add");
	require_once(ADMIN_ROOT_PATH.'include/admin_user_fun.php');
	$add_username = !empty($_POST['username']) ? trim($_POST['username']):adminmsg('����д�û�����',1);
	$add_password = !empty($_POST['password']) ? trim($_POST['password']):adminmsg('����д���룡',1);
	if (strlen(trim($_POST['username']))<3) adminmsg('�û�������Ϊ3λ���ϣ�',1);
	if (strlen(trim($_POST['password']))<6) adminmsg('�������Ϊ6λ���ϣ�',1);
	($add_password<>trim($_POST['password1']))? adminmsg('������������벻��ͬ��',1):'';
	$add_member_type = !empty($_POST['member_type']) ? trim($_POST['member_type']):adminmsg('��û��ѡ��ע�����ͣ�',1);
	$add_email = !empty($_POST['email']) ? trim($_POST['email']):adminmsg('����д�������䣡',1);
	if (empty($add_email) || !ereg("^[-a-zA-Z0-9_\.]+\@([0-9A-Za-z][0-9A-Za-z-]+\.)+[A-Za-z]{2,5}$",$add_email))adminmsg('���������ʽ����',1);
	(!is_numeric($add_member_type)||$add_member_type+0==0)?adminmsg('ע�������',0):'';
	$ck_user=get_company_user($add_username);
	$ck_user?adminmsg('���û����Ѿ���ʹ�ã�',1):'';
	$ck_email=get_company_user($add_email);
	$ck_email?adminmsg('�� Email �Ѿ���ע�ᣡ',1):'';
	if (!$ck_user && !$ck_email)
	{
			if(defined('UC_API'))
			{
				include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
				if (uc_user_checkname($add_username)<>"1")
				{
				adminmsg('���û����Ѿ���ʹ�û����û����Ƿ���',1);
				exit();
				}
				elseif (uc_user_checkemail($add_email)<>"1")
				{
				adminmsg('�� Email�Ѿ���ʹ�û��߷Ƿ���',1);
				exit();
				}
				else
				{
				uc_user_register($add_username, $add_password , $add_email);
				}
			}
	$pwd_hash=randstr();
	$password_hash=md5(md5($add_password).$pwd_hash);
	$sql = "INSERT INTO ".table('members')." (username,password,pwd_hash,email,reg_time,reg_ip) VALUES ('$add_username','$password_hash','$pwd_hash', '$add_email', '$timestamp','$online_ip')";
	$db->query($sql);
	$insert_id=$db->insert_id();
	$sql1 = "INSERT INTO ".table('members_type')." (uid,utype) VALUES ('$insert_id','$add_member_type')";
	$db->query($sql1);
	}
	$link[0]['text'] = "�����б�";
	$link[0]['href'] = "?act=members_list";
	adminmsg('���ӳɹ���',2,$link);
}
?>