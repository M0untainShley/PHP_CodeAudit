<?php
 /*
 * 74cms WAP
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
define('IN_QISHI', true);
require_once(dirname(__FILE__).'/../include/common.inc.php');
require_once(QISHI_ROOT_PATH.'include/fun_wap.php');
require_once(QISHI_ROOT_PATH.'include/mysql.class.php');
$smarty->caching = false;
$db = new mysql($dbhost,$dbuser,$dbpass,$dbname);
$page = empty($_GET['page'])?1:intval($_GET['page']);
$sdistrict = empty($_GET['sdistrict'])?"":intval($_GET['sdistrict']);
$subclass = empty($_GET['subclass'])?"":intval($_GET['subclass']);
$key = empty($_GET['key'])?"":$_GET['key'];
$wheresql=" WHERE audit=1 AND display=1  AND user_status=1 ";
if ($_CFG['outdated_jobs']=="1")
{
	$wheresql.=" AND deadline>".time()." ";
}
if ($sdistrict)
{
	$wheresql.=" AND sdistrict=".$sdistrict." ";
}
if ($subclass)
{
	$wheresql.=" AND subclass=".$subclass." ";
}
$wheresql.=" AND (setmeal_deadline=0 OR setmeal_deadline>".time().")";
$orderbysql=" ORDER BY refreshtime desc";
if ($key)
{
	$wheresql.=" AND  MATCH (`key`) AGAINST ('".'"'.cutgbkstring($key).'"'."') ";
	$orderbysql="";
}
	$perpage = 5;
	$count  = 0;
	$page = empty($_GET['page'])?1:intval($_GET['page']);
	if($page<1) $page = 1;
	$theurl = "wap-jobs-list.php?sdistrict=".$sdistrict."&amp;subclass=".$subclass."&amp;key=".$key;
	$start = ($page-1)*$perpage;
	$total_sql="SELECT COUNT(*) AS num FROM ".table('jobs').$wheresql;
	$count=get_total($total_sql);
	$limit=" LIMIT ".$start.",".$perpage;
	$sql="SELECT * FROM ".table('jobs')." ".$wheresql.$orderbysql.$limit;
	//echo $sql;
	$smarty->assign('jobs',$db->getall($sql));
	$smarty->assign('pagehtml',wapmulti($count, $perpage, $page, $theurl));
	$smarty->display("wap/wap-jobs-list.htm");
?>