<?php
 /*
 * 74cms ajax�����ʼ�
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
ignore_user_abort(true);
$uid=intval($_GET['uid']);
$key=trim($_GET['key']);
if (empty($uid) || empty($key)) exit("error");
define('IN_QISHI', true);
require_once(dirname(__FILE__).'/../include/common.inc.php');
require_once(QISHI_ROOT_PATH.'include/mysql.class.php');
require_once(QISHI_ROOT_PATH.'include/fun_user.php');
require_once(QISHI_ROOT_PATH.'phpmailer/class.phpmailer.php'); 
$db = new mysql($dbhost,$dbuser,$dbpass,$dbname);
$act = !empty($_GET['act']) ? trim($_GET['act']) : '';
$asyn_userkey=asyn_userkey($uid);
if ($asyn_userkey<>$key)exit("error");
$mailconfig=get_cache('mailconfig');
$mail_templates=get_cache('mail_templates');
//����ע���ʼ�
if($act == 'reg'){
	if ($_GET['sendemail'] && $_GET['sendusername'] && $_GET['sendpassword'] && $mailconfig['set_reg']=="1")
	{
	$userinfo=get_user_inid($uid);
			if ($userinfo['username']==$_GET['sendusername'] && $userinfo['email']==$_GET['sendemail'])
			{ 
			$templates=$mail_templates['set_reg'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates=str_replace('{$username}',$_GET['sendusername'],$templates);
			$templates=str_replace('{$password}',$_GET['sendpassword'],$templates);	
			$templates_title=$mail_templates['set_reg_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$templates_title=str_replace('{$username}',$_GET['sendusername'],$templates_title);
			$templates_title=str_replace('{$password}',$_GET['sendpassword'],$templates_title);	
			smtp_mail($_GET['sendemail'],$templates_title,$templates);
			}
	}
}
//����ְλ�����ʼ�
elseif($act == 'jobs_apply')
{   
	$templates=$mail_templates['set_applyjobs'];
	$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
	$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
	$templates=str_replace('{$personalfullname}',$_GET['personal_fullname'],$templates);
	$templates=str_replace('{$jobsname}',$_GET['jobs_name'],$templates);
	$templates_title=$mail_templates['set_applyjobs_title'];
	$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
	$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
	$templates_title=str_replace('{$personalfullname}',$_GET['personal_fullname'],$templates_title);
	$templates_title=str_replace('{$jobsname}',$_GET['jobs_name'],$templates_title);
	smtp_mail($_GET['email'],$templates_title,$templates);
}
//�������Է����ʼ�
elseif($act == 'set_invite'){
	if ($mailconfig['set_invite']=="1")
	{
			$templates=$mail_templates['set_invite'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates=str_replace('{$companyname}',$_GET['companyname'],$templates);
			$templates_title=$mail_templates['set_invite_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$templates_title=str_replace('{$companyname}',$_GET['companyname'],$templates_title);
			smtp_mail($_GET['email'],$templates_title,$templates);
	}
}
//�����ֵ�������ʼ�
elseif($act == 'set_order'){
			$templates=$mail_templates['set_order'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates=str_replace('{$paymenttpye}',$_GET['paymenttpye'],$templates);
			$templates=str_replace('{$amount}',$_GET['amount'],$templates);
			$templates_title=$mail_templates['set_order_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$templates_title=str_replace('{$paymenttpye}',$_GET['paymenttpye'],$templates_title);
			$templates_title=str_replace('{$amount}',$_GET['amount'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//��ֵ�ɹ��������ʼ�
elseif($act == 'set_payment'){
			$templates=$mail_templates['set_payment'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_payment_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//�޸����룬�����ʼ�
elseif($act == 'set_editpwd'){
			$templates=$mail_templates['set_editpwd'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates=str_replace('{$password}',$_GET['password'],$templates);
			$templates_title=$mail_templates['set_editpwd_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$templates_title=str_replace('{$password}',$_GET['password'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//ְλ���ͨ���������ʼ�
elseif($act == 'set_jobsallow'){
			$templates=$mail_templates['set_jobsallow'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_jobsallow_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//ְλδ���ͨ���������ʼ�
elseif($act == 'set_jobsnotallow'){
			$templates=$mail_templates['set_jobsnotallow'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_jobsnotallow_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//��ҵ��֤ͨ���������ʼ�
elseif($act == 'set_licenseallow'){
			$templates=$mail_templates['set_licenseallow'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_licenseallow_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//��ҵ��֤δͨ���������ʼ�
elseif($act == 'set_licensenotallow'){
			$templates=$mail_templates['set_licensenotallow'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_licensenotallow_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//��ҵ�����ر��Ƽ��������ʼ�
elseif($act == 'set_addrecommend'){
			$templates=$mail_templates['set_addrecommend'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_addrecommend_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//��ҵ�����ر��Ƽ��������ʼ�
elseif($act == 'set_addmap'){
			$templates=$mail_templates['set_addmap'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_addmap_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//����ͨ����ˣ������ʼ�
elseif($act == 'set_resumeallow'){
			$templates=$mail_templates['set_resumeallow'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_resumeallow_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
//����δͨ����ˣ������ʼ�
elseif($act == 'set_resumenotallow'){
			$templates=$mail_templates['set_resumenotallow'];
			$templates=str_replace('{$sitename}',$_CFG['site_name'],$templates);
			$templates=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates);
			$templates_title=$mail_templates['set_resumenotallow_title'];
			$templates_title=str_replace('{$sitename}',$_CFG['site_name'],$templates_title);
			$templates_title=str_replace('{$sitedomain}',$_CFG['site_domain'].$_CFG['site_dir'],$templates_title);
			$useremail=get_user_inid($uid);
			smtp_mail($useremail['email'],$templates_title,$templates);
}
?>