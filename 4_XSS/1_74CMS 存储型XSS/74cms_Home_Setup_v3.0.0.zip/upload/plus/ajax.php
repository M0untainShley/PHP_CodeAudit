<?php
 /*
 * 74cms ajax����
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
define('IN_QISHI', true);
require_once(dirname(__FILE__).'/../include/plus.common.inc.php');
require_once(QISHI_ROOT_PATH.'include/mysql.class.php');
$db = new mysql($dbhost,$dbuser,$dbpass,$dbname);
$act = !empty($_REQUEST['act']) ? trim($_REQUEST['act']) : '';
//��¼
if($act =='do_login')
{
	$username=isset($_POST['username'])?trim($_POST['username']):"";
	$password=isset($_POST['password'])?trim($_POST['password']):"";
	$expire=isset($_POST['expire'])?intval($_POST['expire']):"";
	$url=isset($_POST['url'])?$_POST['url']:"";
	if (strcasecmp(QISHI_DBCHARSET,"utf8")!=0)
	{
	$username=iconv("utf-8",QISHI_DBCHARSET,$username);
	$password=iconv("utf-8",QISHI_DBCHARSET,$password);
	}
	require_once(QISHI_ROOT_PATH.'include/fun_user.php');
	if ($username && $password)
	{
		$login_js=user_login(trim($username),trim($password),true,$expire);
		$ucjs=$login_js['uc_login'];
		$url=$url?$url:$login_js['qs_login'];	
		$qsjs="<script language=\"javascript\" type=\"text/javascript\">window.location.href=\"".$url."\";</script>";
		if ($ucjs || $login_js['qs_login'])
		{
		exit($ucjs.$qsjs);
		}
		else
		{
		exit("err");
		}
	}
	exit("err");
}
//ע��
elseif ($act=='do_reg')
{
	require_once(QISHI_ROOT_PATH.'include/fun_user.php');
	$username = isset($_POST['username'])?trim($_POST['username']):"";
	$password = isset($_POST['password'])?trim($_POST['password']):"";
	$member_type = isset($_POST['member_type'])?intval($_POST['member_type']):0;
	$email = isset($_POST['email'])?trim($_POST['email']):"";
	if (strcasecmp(QISHI_DBCHARSET,"utf8")!=0)
	{
	$username=iconv("utf-8",QISHI_DBCHARSET,$username);
	$password=iconv("utf-8",QISHI_DBCHARSET,$password);
	}
	if (empty($username)|| empty($password) || empty($email) || $member_type==0)exit("err");
 
	if (user_register($username,$password,$member_type,$email))
	{	
		$login_js=user_login($username,$password);
		$mailconfig=get_cache('mailconfig');
		if ($mailconfig['set_reg']=="1")
		{
		asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$_SESSION['uid']."&key=".asyn_userkey($_SESSION['uid'])."&sendemail=".$email."&sendusername=".$username."&sendpassword=".$password."&act=reg");
		}		
		$ucjs=$login_js['uc_login'];
		$qsurl=$login_js['qs_login'];
		$qsjs="<script language=\"javascript\" type=\"text/javascript\">window.location.href=\"".$qsurl."\";</script>";
		 if ($ucjs || $qsurl)
			{
			exit($ucjs.$qsjs);
			}
			else
			{
			exit("err");
			}
	}
	else
	{
	exit("err");
	}
}
//����û���
elseif($act =='check_usname')
{
	require_once(QISHI_ROOT_PATH.'include/fun_user.php');
	$usname=trim($_POST['usname']);
	if (strcasecmp(QISHI_DBCHARSET,"utf8")!=0)
	{
	$usname=iconv("utf-8",QISHI_DBCHARSET,$usname);
	}
	if (defined('UC_API'))
	{  
		exit("false");
	}
	else
	{
		if (get_user($usname)=='')
		{
		exit("true");
		}
		else
		{
		exit("false");
		}
	}
}
//���email
elseif($act == 'check_email')
{
	require_once(QISHI_ROOT_PATH.'include/fun_user.php');
	$email=trim($_POST['email']);
	if (strcasecmp(QISHI_DBCHARSET,"utf8")!=0)
	{
	$email=iconv("utf-8",QISHI_DBCHARSET,$email);
	}
	if (defined('UC_API'))
	{
		include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
		if (uc_user_checkemail($email)===1 && get_user($email)=="")
		{
		exit("true");
		}
		else
		{
		exit("false");
		}
	}
	else
	{
		if (get_user($email))
		{
		exit("false");
		}
		else
		{
		exit("true");
		}
	}
}
//ְλ����
elseif($act == 'edit_apply')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
	$setsqlarr['personal_look']=2;
	updatetable(table('personal_jobs_apply'),$setsqlarr," did='".$id."' LIMIT 1");
	exit("ok");
	}
}
//��������
elseif($act == 'edit_interview')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
	$setsqlarr['personal_look']=2;
	if (updatetable(table('company_interview'),$setsqlarr," did='".$id."' LIMIT 1"))exit("ok");
	}
}
//��Ѷ�������
elseif($act == 'news_click')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
		$sql="update ".table('article')." set click=click+1 WHERE id=".$id."  LIMIT 1";
		$db->query($sql);
		$sql = "select click from ".table('article')." where id=".$id."  LIMIT 1";
		$val=$db->getone($sql);
		exit($val['click']);
	}
}
elseif($act == 'notice_click')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
		$sql="update ".table('notice')." set click=click+1 WHERE id=".$id."  LIMIT 1";
		$db->query($sql);
		$sql = "select click from ".table('notice')." where id=".$id."  LIMIT 1";
		$val=$db->getone($sql);
		exit($val['click']);
	}
}
elseif($act == 'jobs_click')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
		$sql="update ".table('jobs')." set click=click+1 WHERE id=".$id."  LIMIT 1";
		$db->query($sql);
		$sql = "select click from ".table('jobs')." where id=".$id."  LIMIT 1";
		$val=$db->getone($sql);
		exit($val['click']);
	}
}
elseif($act == 'resume_click')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
		$sql="update ".table('resume')." set click=click+1 WHERE id=".$id."  LIMIT 1";
		$db->query($sql);
		$sql = "select click from ".table('resume')." where id=".$id."  LIMIT 1";
		$val=$db->getone($sql);
		exit($val['click']);
	}
}
elseif($act == 'jobs_contact')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
		if($_CFG['visitor_jobs']=='1' || ($_SESSION['uid'] && $_SESSION['username'] && $_SESSION['utype']=='2'))
		{
		$sql = "select * from ".table('jobs_contact')." where pid=".intval($id)." LIMIT 1";
		$val=$db->getone($sql);
		$html="<ul>";
		$html.="<li>�� ϵ �ˣ�".$val['contact']."</li>";
		$html.="<li>��ϵ�绰��".$val['telephone']."</li>";
		$html.="<li>��ϵ���䣺".$val['email']."</li>";
		$html.="<li>��ϵ��ַ��".$val['address']."</li>";
		$html.="<li>��ϵ Q Q��".$val['qq']."</li>";		
		$html.="</ul>";
		$html.="<div class=\"clear\"></div>";
		exit($html);
		}
		else
		{
		$html="<div class=\"contact link_lan\">���˻�Ա�� <a href=\"".url_rewrite('QS_login')."\">��¼</a>  �鿴��ϵ��ʽ����������Ǹ��˻�Ա������ <a href=\"".$_CFG['site_dir']."user/reg.php\">���ע��</a> ��Ϊ���˻�Ա��</div>";
		exit($html);
		}
	}
}
elseif($act == 'company_contact')
{
	$id=intval($_GET['id']);
	if ($id>0)
	{
		if($_CFG['visitor_jobs']=='1' || ($_SESSION['uid'] && $_SESSION['username'] && $_SESSION['utype']=='2'))
		{
		$sql = "select contact,telephone,email,address,website FROM ".table('company_profile')." where id=".intval($id)." LIMIT 1";
		$val=$db->getone($sql);
		$html="<ul>";
		$html.="<li>�� ϵ �ˣ�".$val['contact']."</li>";
		$html.="<li>��ϵ�绰��".$val['telephone']."</li>";
		$html.="<li>��ϵ���䣺".$val['email']."</li>";
		$html.="<li>��ϵ��ַ��".$val['address']."</li>";
		$html.="<li>��˾��ַ��".$val['website']."</li>";		
		$html.="</ul>";
		$html.="<div class=\"clear\"></div>";
		exit($html);
		}
		else
		{
		$html="<div class=\"contact link_lan\">���˻�Ա�� <a href=\"".url_rewrite('QS_login')."\">��¼</a>  �鿴��ϵ��ʽ����������Ǹ��˻�Ա������ <a href=\"".$_CFG['site_dir']."user/reg.php\">���ע��</a> ��Ϊ���˻�Ա��</div>";
		exit($html);
		}
	}
}
//������ϵ��ʽ
elseif($act == 'resume_contact')
{
	$id=intval($_GET['id']);
	if($_CFG['visitor_resume']=="1")
	{
		$sql = "select telephone,email,qq,address,website from ".table('resume')." WHERE  id=".intval($id)."  LIMIT 1";
		$val=$db->getone($sql);
		$html="<ul>";
		$html.="<li>��ϵ�绰��".$val['telephone']."</li>";
		$html.="<li>��ϵ���䣺".$val['email']."</li>";
		$html.="<li>��ϵ Q Q��".$val['qq']."</li>";
		$html.="<li>��ϵ��ַ��".$val['address']."</li>";
		$html.="<li>������ҳ/���ͣ�".$val['website']."</li>";
		$html.="</ul>";
		$html.="<div class=\"clear\"></div>";
		exit($html);
	}
	elseif ($_SESSION['uid'] && $_SESSION['username'] && $_SESSION['utype']=='1')
	{
		$sql = "select did from ".table('company_down_resume')." WHERE company_uid = ".$_SESSION['uid']." AND resume_id=".$id." LIMIT 1";
		$info=$db->getone($sql);
		if ($info)
		{
			$sql = "select telephone,email,qq,address,website from ".table('resume')." WHERE  id=".intval($id)."  LIMIT 1";
			$val=$db->getone($sql);
			$html="<ul>";
			$html.="<li>��ϵ�绰��".$val['telephone']."</li>";
			$html.="<li>��ϵ���䣺".$val['email']."</li>";
			$html.="<li>��ϵ Q Q��".$val['qq']."</li>";
			$html.="<li>��ϵ��ַ��".$val['address']."</li>";
			$html.="<li>������ҳ/���ͣ�".$val['website']."</li>";
			$html.="</ul>";
			$html.="<div class=\"clear\"></div>";
			$html.="<div align=\"center\"><br/><img src=\"".$_CFG['site_template']."images/64.gif\"  border=\"0\" id=\"invited\"/></div>";
			$html.="<div align=\"center\"><span class=\"add_resume_pool\">[���ӵ��˲ſ�]</span><br/><br/></div>";
			exit($html);
		}
		else
		{
			$html="<div align=\"center\"><img src=\"".$_CFG['site_template']."images/44.gif\"  border=\"0\" id=\"download\"/></div>";
			exit($html);
		}
	}
	else
	{
	$html="<div align=\"center\"><img src=\"".$_CFG['site_template']."images/44.gif\" border=\"0\" id=\"download\"/></div>";
	exit($html);
	}
}
elseif ($act=="countinfo")
{
	$total="SELECT COUNT(*) AS num FROM ".table("company_profile");
	$total_company=get_total($total);
	$total="SELECT COUNT(*) AS num FROM ".table("jobs");
	$total_jobs=get_total($total);
	$total="SELECT COUNT(*) AS num FROM ".table("resume");
	$total_resume=get_total($total);
	$total="SELECT COUNT(*) AS num FROM ".table("members");
	$total_members=get_total($total);
		$tpl='../templates/'.$_CFG['template_dir']."plus/count.htm";
		$contents=file_get_contents($tpl);
		$contents=str_replace('{#$total_company#}',$total_company,$contents);
		$contents=str_replace('{#$total_jobs#}',$total_jobs,$contents);
		$contents=str_replace('{#$total_resume#}',$total_resume,$contents);
		$contents=str_replace('{#$total_members#}',$total_members,$contents);
		$contents=str_replace('{#$site_name#}',$_CFG['site_name'],$contents);
		$contents=str_replace('{#$user_url#}',url_rewrite('QS_login'),$contents);
		$contents=str_replace('{#$site_template#}',$_CFG['site_template'],$contents);
		$contents = ereg_replace("\t","",$contents); 
		$contents = ereg_replace("\r\n","",$contents); 
		$contents = ereg_replace("\r","",$contents); 
		$contents = ereg_replace("\n","",$contents);
		exit($contents);
}
elseif ($act=="dynamic")
{
		$result = $db->query("SELECT id,jobs_name,addtime,companyname,company_id,company_addtime FROM ".table('jobs')."  WHERE audit=1 AND display=1   AND (setmeal_deadline=0 OR setmeal_deadline>".time().") AND  user_status=1 ORDER BY id DESC LIMIT 3");
		while($row = $db->fetch_array($result))
		{
		$html[]="<li><a href=".url_rewrite('QS_companyshow',array('id0'=>$row['company_id'],'addtime'=>$row['company_addtime']))." target=\"_blank\">".cut_str($row['companyname'],5,0,"...")."</a> ������ְλ:<a href=".url_rewrite('QS_jobsshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']))." target=\"_blank\">".$row['jobs_name']."</a></li>";
		}
		$result= $db->query("SELECT id,display_name,fullname,addtime FROM ".table('resume')."  WHERE audit=1 AND display=1 AND complete=1 AND  user_status=1 ORDER BY id DESC LIMIT 3");
		while($row = $db->fetch_array($result))
		{
		if ($val['display_name']=="2")$val['fullname']="N".str_pad($val['id'],7,"0",STR_PAD_LEFT);
		$html[]="<li><a href=".url_rewrite('QS_resumeshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']))." target=\"_blank\">".$row['fullname']." </a> �����˼���</li>";
		}
		if (is_array($html) && shuffle($html))
		{
 		exit("<ul>".implode("",$html)."</ul>");
		}		
}
elseif ($act=="top_loginform")
{
	$contents='';
	if ($_COOKIE['QS']['username'] && $_COOKIE['QS']['password'])
	{
		$tpl='../templates/'.$_CFG['template_dir']."plus/top_login_success.htm";
	}
	elseif ($_SESSION['activate_username'] && defined('UC_API'))
	{
		$tpl='../templates/'.$_CFG['template_dir']."plus/top_login_activate.htm";
	}
	else
	{	
		$tpl='../templates/'.$_CFG['template_dir']."plus/top_login_form.htm";
	}
		$contents=file_get_contents($tpl);
		$contents=str_replace('{#$activate_username#}',$_SESSION['activate_username'],$contents);
		$contents=str_replace('{#$site_name#}',$_CFG['site_name'],$contents);
		$contents=str_replace('{#$username#}',$_COOKIE['QS']['username'],$contents);
		$contents=str_replace('{#$site_template#}',$_CFG['site_template'],$contents);
		$contents=str_replace('{#$user_url#}',url_rewrite('QS_login'),$contents);
		$contents=str_replace('{#$reg_url#}',$_CFG['site_dir']."user/reg.php",$contents);
		$contents=str_replace('{#$activate_url#}',$_CFG['site_dir']."user/reg.php?act=activate",$contents);
		exit($contents);
}
elseif ($act=="loginform")
{
	$contents='';
	if ($_COOKIE['QS']['username'] && $_COOKIE['QS']['password'])
	{
		$tpl='../templates/'.$_CFG['template_dir']."plus/login_success.htm";
	}
	elseif ($_SESSION['activate_username'] && defined('UC_API'))
	{
		$tpl='../templates/'.$_CFG['template_dir']."plus/login_activate.htm";
	}
	else
	{
		$tpl='../templates/'.$_CFG['template_dir']."plus/login_form.htm";
	}
		$contents=file_get_contents($tpl);
		$contents=str_replace('{#$activate_username#}',$_SESSION['activate_username'],$contents);
		$contents=str_replace('{#$site_name#}',$_CFG['site_name'],$contents);
		$contents=str_replace('{#$username#}',$_COOKIE['QS']['username'],$contents);
		$contents=str_replace('{#$site_template#}',$_CFG['site_template'],$contents);
		$contents=str_replace('{#$user_url#}',url_rewrite('QS_login'),$contents);
		$contents=str_replace('{#$reg_url#}',$_CFG['site_dir']."user/reg.php",$contents);
		$contents=str_replace('{#$activate_url#}',$_CFG['site_dir']."user/reg.php?act=activate",$contents);
		exit($contents);
}
?>