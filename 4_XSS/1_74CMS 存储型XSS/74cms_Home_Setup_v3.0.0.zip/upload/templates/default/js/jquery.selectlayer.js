//ְλ������ѡ�񵯳��㺯��
function OpenCategoryLayer(objid,showid,input_cn,input,smid,QSarr,strlen)
{
	$(objid).click(function()
	{
			$(this).blur();
			$(this).parent("div").before("<div class=\"menu_bg_layer\"></div>");
			$(".menu_bg_layer").height($(document).height());
			$(".menu_bg_layer").css({ width: $(document).width(), position: "absolute",left:"0", top:"0","z-index":"0","background-color":"#000000"});
			$(".menu_bg_layer").css("filter","alpha(opacity=30)");
			$(".menu_bg_layer").css("opacity","0.3");
			//���ɱ�������
			$(showid).css({"left":($(document).width()-$(showid).width())/2,"top":"150"});
			$(showid).show();
			$(showid+" .c1 label,"+showid+" .sm label").hover(function()	{$(this).css("background-color","#E3F0FF");},function(){	$(this).css("background-color","");});
				$(showid+" .c1 label").click(function()
				{
					$(showid+" .c1").hide();
					$(showid+" .sm").hide();
					var Sid=$(this).attr("id");
					$(showid+" "+smid+Sid).show();
					var strclass=QSarr[$(this).attr("id")];
					var	go_back="<div class=\"go_back\"><strong>"+$(this).attr("title")+"</strong> <span class=\"go_back\">[�����ϲ����]</span></div>";
						if (strclass)
						{
							if ($(showid+" "+smid+Sid).html()=="")
							{
							$(showid+" "+smid+Sid).html(go_back+MakeLi(strclass));//����LI
							}
						}
						else
						{
						$(showid+" "+smid+Sid).html(go_back+"û�з�����");//����LI
						}
						//hoverЧ��
						$(showid+" .c1 label,"+showid+" .sm label").hover(function()	{$(this).css("background-color","#E3F0FF");},function(){	$(this).css("background-color","");});
						//�����ϼ�
						$(showid+" .go_back span").click(function()
						{
						$(showid+" .c1").show();
						$(showid+" .sm").hide();
						});
						//ѡ��С��
						SetsmCheck(showid);
				});
		
	});
	//�ر�
	$(showid+" .pcloss").click(function()
	{
		$(".menu_bg_layer").hide();
		$(showid).hide();
	});
	//ȷ��ѡ��
	$(showid+" .Set").click(function()
	{
			SetInput(showid,input_cn,input,strlen);
			$(".menu_bg_layer").hide();
			$(showid).hide();
	});
	
}
function SetsmCheck(showid){
		//����·���ѡ��Ȼ�󿽱�
		$(showid+" .sm :checkbox").click(function(){
			if ($(showid+" .sm :checkbox[checked]").length>5)
			{
				alert("���ܳ���5��ѡ��");
				$(this).attr("checked",false);
			}
			else
			{
				CopyItem(showid);								
			}
			$(showid+" .sm :checkbox").parent().css("color","");
			$(showid+" .sm :checkbox[checked]").parent().css("color","#FF0000");	
		});
}
function SetInput(showid,input_cn,input,strlen)
{
		var a_cn=new Array();
		var a_id=new Array();
		$(showid+" .is_slt :checkbox[checked]").each(function(index){
		a_cn[index]=$(this).attr("title");
		a_id[index]=$(this).attr("value");
		});
		$(input_cn).val(limit(a_cn.join("+"),strlen));
		if ($(input_cn).val()=="")$(input_cn).val("��ѡ��");
		$(input).val(a_id.join("-"));
}		
function CopyItem(showid)
{
				var htmlstr='';
				$(showid+" .sm :checkbox[checked]").each(function(index){
				htmlstr+="<label><input name=\"\" type=\"checkbox\" value=\""+$(this).attr("value")+"\" title=\""+$(this).attr("title")+"\" checked/>"+$(this).attr("title")+"</label>";
				})
				htmlstr+="<div class=\"clear\"></div>";
				$(showid+" .is_slt").html(htmlstr);	
	//��ѡ��Ŀ��click
	$(showid+" .is_slt :checkbox").click(function()
	{
		var selval=$(this).val();
		//alert(selval);
		//ȡ���·���Ӧ�ĸ�ѡ
			$(showid+" .sm :checkbox[checked]").each(function()
			{
				if ($(this).val()==selval)
				{
					$(this).attr("checked",false)
					//���¿�¡
					CopyItem(showid);
					$(showid+" .sm :checkbox").parent().css("color","");
					$(showid+" .sm :checkbox[checked]").parent().css("color","#FF0000");
				}	
			})
	});
}
function MakeLi(val)
		{
		if (val=="")return false;
		arr=val.split("|");
		var htmlstr='';
			for (x in arr)
			{
			 var v=arr[x].split(",");
			htmlstr+="<label><input name=\"\" type=\"checkbox\" value=\""+v[0]+"\" title=\""+v[1]+"\"/>"+v[1]+"</label>";
			}
		return htmlstr; 
}
//��ȡ�ַ�
function limit(objString,num)
{
	var objLength =objString.length;
	if(objLength > num){ 
	return objString.substring(0,num) + "...";
	} 
	return objString;
}
//ģ��select
function showmenu(menuID,showID,inputname)
{
	$(menuID).click(function(){
		$(menuID).blur();
		$(menuID).parent("div").css("position","relative");
		$(showID).slideToggle("fast");
		//���ɱ���
		$(menuID).parent("div").before("<div class=\"menu_bg_layer\"></div>");
		$(".menu_bg_layer").height($(document).height());
		$(".menu_bg_layer").css({ width: $(document).width(), position: "absolute", left: "0", top: "0" , "z-index": "0", "background-color": "#ffffff"});
		$(".menu_bg_layer").css("opacity","0");
		//���ɱ�������
		$(showID+" li").click(function(){
			$(menuID).val($(this).attr("title"));
			$(inputname).val($(this).attr("id"));
			$(".menu_bg_layer").hide();
			$(showID).hide();
			$(menuID).parent("div").css("position","");	
			$(this).css("background-color","");			
		});

				$(".menu_bg_layer").click(function(){
					$(".menu_bg_layer").hide();
					$(showID).hide();
					$(menuID).parent("div").css("position","");
				});
		$(showID+" li").hover(
		function()
		{
		$(this).css("background-color","#DAECF5");
		},
		function()
		{
		$(this).css("background-color","");

		}
		);
	});
}
//����ҵ
function OpenTradeLayer(input_cn,input,showid)
{
	$(input_cn).click(function()
	{
			$(this).blur();
			$(this).parent("div").before("<div class=\"menu_bg_layer\"></div>");
			$(".menu_bg_layer").height($(document).height());
			$(".menu_bg_layer").css({ width: $(document).width(), position: "absolute",left:"0", top:"0","z-index":"0","background-color":"#000000"});
			$(".menu_bg_layer").css("filter","alpha(opacity=30)");
			$(".menu_bg_layer").css("opacity","0.3");
			//���ɱ�������
			$(showid).css({"left":($(document).width()-$(showid).width())/2,"top":"150"});
			$(showid).show();
			$(showid+" .tradetxt label").hover(function()	{$(this).css("background-color","#E3F0FF");},function(){	$(this).css("background-color","");});
				$(showid+" .tradetxt label").click(function(){
						if ($(showid+" .tradetxt :checkbox[checked]").length>8)
						{
							alert("���ܳ���8��ѡ��");
							$(this).attr("checked",false);
							return false;
						}
						else
						{
						$(showid+"  :checkbox").parent().css("color","");
						$(showid+"  :checkbox[checked]").parent().css("color","#FF0000");
						}
						
				});
		
	});
	//�ر�
	$(showid+" .pcloss").click(function()
	{
		$(".menu_bg_layer").hide();
		$(showid).hide();
	});
	//ȷ��ѡ��
	$(showid+" .Set").click(function()
	{
			var a_cn=new Array();
			var a_id=new Array();
			$(showid+" :checkbox[checked]").each(function(index){
			a_cn[index]=$(this).attr("title");
			a_id[index]=$(this).attr("value");
			});
			$(input_cn).val(limit(a_cn.join("+"),21));
			if ($(input_cn).val()=="")$(input_cn).val("��ѡ��");
			$(input).val(a_id.join("-"));
			$(".menu_bg_layer").hide();
			$(showid).hide();
	});
	
}