<?php
 /*
 * 74cms ��ҵ��Ա���ĺ���
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
 if(!defined('IN_QISHI'))
 {
 	die('Access Denied!');
 }
 //��ȡְλ�б�
function get_jobs($offset,$perpage,$get_sql= '')
{
	global $db,$timestamp;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage))
	{
	$limit=" LIMIT ".$offset.','.$perpage;
	}
	$result = $db->query("SELECT * FROM ".table('jobs')." ".$get_sql." ORDER BY id DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
	$row['jobs_name']=cut_str($row['jobs_name'],15,0,"...");
	$row['jobs_url']=url_rewrite('QS_jobsshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']),false);
	$row['deadline']=($row['deadline']-$timestamp)>0?$row['deadline']:0;
	$row_arr[] = $row;
	}
	return $row_arr;
}
//��ȡ����ְλ
function get_jobs_one($id,$uid='')
{
	global $db,$timestamp;
	if (!empty($uid)) $wheresql=" AND uid=".intval($uid);
	$sql = "select * from ".table('jobs')." where id=".intval($id).$wheresql." LIMIT 1";
	$val=$db->getone($sql);
	if (empty($val)) return false;
	$val['contact']=get_jobs_contact($id);
	$val['deadline_days']=($val['deadline']-$timestamp)>0?"�ൽ��ʱ�仹��<strong style=\"color:#FF0000\">".sub_day($val['deadline'],$timestamp)."</strong>":"<span style=\"color:#FF6600\">Ŀǰ�ѹ���</span>";
	return $val;
}
//��ȡְλ��ϵ��ʽ
function get_jobs_contact($id)
{
	global $db;
	$sql = "select * from ".table('jobs_contact')." where pid=".intval($id)." LIMIT 1 ";
	return $db->getone($sql);
}
//ɾ��ְλ
function del_jobs($del_id,$uid)
{
	global $db;
	$uidsql=" AND uid=".intval($uid)."";
	if (!is_array($del_id)) $del_id=array($del_id);
	$sqlin=implode(",",$del_id);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
	if (!$db->query("Delete from ".table('jobs')." WHERE id IN (".$sqlin.") ".$uidsql."")) return false;
	if (!$db->query("Delete from ".table('jobs_contact')." WHERE pid IN (".$sqlin.") ")) return false;
	return true;
	}
	return false;
}
//���������ְͣλ
function activate_jobs($idarr,$display,$uid)
{
	global $db;
	$uidsql=" AND uid=".intval($uid)."";
	if (!is_array($idarr)) $idarr=array($idarr);
	$sqlin=implode(",",$idarr);
	if (preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin))
	{
	if (!$db->query("update ".table('jobs')."  SET display=".intval($display)." WHERE id IN (".$sqlin.") ".$uidsql."")) return false;
	return true;
	}
	return false;
}
//ˢ����ҵ
function refresh_company($uid)
{
	global $db;
	$wheresql=" WHERE uid=".intval($uid)." ";
	if (!$db->query("update  ".table('company_profile')."  SET refreshtime=".time()."  ".$wheresql." LIMIT 1 ")) return false;
	if (!$db->query("update  ".table('jobs')."  SET refreshtime=".time()."  ".$wheresql." ")) return false;
	return true;
}
 //��ȡ��ҵ����
function get_company_profile($uid)
{
	global $db;
	$sql = "select * from ".table('company_profile')." where uid=".intval($uid)." LIMIT 1 ";
	return $db->getone($sql);
}
//--------------����ģʽ
//��ȡ���ֹ���
function get_points_rule()
{
	global $db;
	$sql = "select * from ".table('members_points_rule')."  ORDER BY id asc";
	$list=$db->getall($sql);
	return $list;
}
//��ȡ��Ա��������
function get_user_points($uid){
	global $db;
	$sql = "select * from ".table('members_points')." where uid =".intval($uid)." LIMIT 1";
	$points=$db->getone($sql);
	return $points['points'];
}
//************************************************��������
//��ȡ�û��˻���ϸ
function get_user_points_report($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage))
	{
	$limit=" LIMIT ".$offset.','.$perpage;
	}
	$result = $db->query("SELECT * FROM ".table('members_points_report')." ".$get_sql." ORDER BY id DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
	$row['i_type_li']=$row['i_type']=="1"?"+":'-';
	$row_arr[] = $row;
	}
	return $row_arr;
}
//֧����ʽ�б�
function get_payment()
{
	global $db;
	$sql = "select * from ".table('payment')." where p_install='2' ORDER BY listorder desc";
	$list=$db->getall($sql);
	return $list;
}
//��ȡ֧����ʽ����
function get_payment_info($typename,$name=false)
{
	global $db;
	$sql = "select * from ".table('payment')." where typename ='".$typename."' AND p_install='2' LIMIT 1";
	$val=$db->getone($sql);
	if ($name)
	{
	return $val['byname'];
	}
	else
	{
	return $val;
	}
}
//���Ӷ���
function add_order($uid,$oid,$amount,$payment_name,$description,$addtime,$points='',$setmeal='')
{
	global $db;
	$setsqlarr['uid']=intval($uid);
	$setsqlarr['oid']=$oid;
	$setsqlarr['amount']=$amount;
	$setsqlarr['payment_name']=$payment_name;
	$setsqlarr['description']=$description;
	$setsqlarr['addtime']=$addtime;
	$setsqlarr['points']=$points;
	$setsqlarr['setmeal']=$setmeal;
	return inserttable(table('order'),$setsqlarr,true);
}
//ȡ������
function del_order($uid,$id)
{
	global $db;
	return $db->query("Delete from ".table('order')." WHERE id='".intval($id)."' AND uid=".intval($uid)." AND is_paid=1  LIMIT 1 ");
}
//��ȡ��ֵ��¼�б�
function get_order_all($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage))
	{
	$limit=" LIMIT ".$offset.','.$perpage;
	}
	$result = $db->query("SELECT * FROM ".table('order')." ".$get_sql." ORDER BY id DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
	$row['payment_name']=get_payment_info($row['payment_name'],true);
	$row_arr[] = $row;
	}
	return $row_arr;
}
//��ȡָ���Ա����
function get_user_order($uid,$is_paid)
{
	global $db;
	$sql = "select * from ".table('order')." WHERE uid=".intval($uid)." AND  is_paid='".intval($is_paid)."' ORDER BY id desc";
	return $db->getall($sql);
}
//��ȡ��������
function get_order_one($uid,$id)
{
	global $db;
	$sql = "select * from ".table('order')." where id =".intval($id)." AND uid = ".intval($uid)."  AND is_paid =1  LIMIT 1 ";
	return $db->getone($sql);
}
//�����ͨ
function order_paid($v_oid)
{
global $db,$timestamp,$_CFG;
$list=$db->getone("select * from ".table('order')." WHERE oid ='$v_oid' AND is_paid= '1' LIMIT 1 ");
	if ($list)
	{
		$sql = "UPDATE ".table('order')." SET is_paid= '2',payment_time='".$timestamp."' WHERE oid='$v_oid' LIMIT 1 ";
		if (!$db->query($sql)) return false;
			if ($_CFG['operation_mode']=="1")
			{
				$notes=date('Y-m-d H:i',time())."ͨ����".get_payment_info($list['payment_name'],true)." �ɹ���ֵ ".$list['amount']."Ԫ";
				if (!report_deal($list['uid'],1,$list['points'],$notes)) return false;
			}
			if ($_CFG['operation_mode']=="2")
			{
				if (!set_members_setmeal($list['uid'],$list['setmeal'])) return false;
			}
		//�����ʼ�
		$mailconfig=get_cache('mailconfig');
		if ($mailconfig['set_payment']=="1")
		{
		asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$list['uid']."&key=".asyn_userkey($list['uid'])."&act=set_payment");
		}
		//�����ʼ����
		return true;
	}
return true;
}
/////*****************************��Ƹ��������
//��ȡUID���������ְλ
function get_user_audit_jobs($uid)
{
	global $db;
	$sql = "select * from ".table('jobs')." WHERE uid='".intval($uid)."'   AND  audit=1 AND  display=1 ORDER BY id desc";
	return $db->getall($sql);
}
//�Ѽ������ӵ���������
function add_down_resume($resume_id,$company_uid,$resume_uid)
{
	global $db,$timestamp;
	$sql = "INSERT INTO ".table('company_down_resume')." (resume_id,resume_uid,company_uid,down_addtime) VALUES ('".intval($resume_id)."','".intval($resume_uid)."','".intval($company_uid)."','".$timestamp."')";
	return $db->query($sql);
}
//�����صļ����б�
function get_down_resume($offset,$perpage,$get_sql= '')
{
	global $db;
	$limit=" LIMIT ".intval($offset).','.intval($perpage);
	$selectstr=" d.*,r.sex_cn,r.fullname,r.display_name,r.experience_cn,r.district_cn,r.education_cn,r.intention_jobs,r.talent,r.addtime ";
	$result = $db->query("SELECT ".$selectstr." FROM ".table('company_down_resume')." as d ".$get_sql." ORDER BY d.did DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
	$row['resume_url']=url_rewrite('QS_resumeshow',array('id0'=>$row['resume_id'],'addtime'=>$row['addtime']));
	$row['intention_jobs']=cut_str($row['intention_jobs'],20,0,"...");
	if ($row['display_name']=="2")$row['fullname']="N".str_pad($row['resume_id'],7,"0",STR_PAD_LEFT);
	$row_arr[] = $row;
	}
	return $row_arr;
}
function del_down_resume($del_id,$uid)
{
	global $db;
	$wheresql=" AND company_uid=".$uid."";
	if (!is_array($del_id)) $del_id=array($del_id);
	$sqlin=implode(",",$del_id);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	return $db->query("Delete from ".table('company_down_resume')." WHERE did IN (".$sqlin.") ".$wheresql."");
}
//���ؼ���ת�Ƶ��˲ſ�
function down_to_favorites($did,$company_uid)
{
	global $db;
	if (!is_array($did)) $did=array($did);
	$sqlin=implode(",",$did);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	$sql = "select resume_id from ".table('company_down_resume')." WHERE did IN (".$sqlin.") ";
	$resumeid=$db->getall($sql);
	if ($resumeid)
	{
		foreach($resumeid as $rid)
		{
		$arrid[]=$rid['resume_id'];
		}
		return add_favorites($arrid,$company_uid);
	}
}
//���ӵ��˲ſ�
function add_favorites($id_arr,$company_uid)
{
	global $db,$timestamp,$_CFG;
	$setmeal=get_user_setmeal($company_uid);
	if  (!is_array($id_arr)) $id_arr=array($id_arr);
	$i=0;
		foreach ($id_arr as $id) 
		{
			if ($_CFG['operation_mode']=="2")
			{
				 	if (count_favorites($company_uid)>=$setmeal['talent_pool'])
					{			
					return "full";
					}
			}
			if (!check_favorites($id,$company_uid) && $id>0 )
			{
				$sql = "INSERT INTO ".table('company_favorites')." (resume_id,company_uid,favoritesa_ddtime) VALUES ('".intval($id)."','".intval($company_uid)."','$timestamp')";
				$db->query($sql);
				$i++;
			}
		}
		return $i;
}
//����˲ſ����Ƿ��Ѿ�����
function check_favorites($resume_id,$company_uid)
{
	global $db;
	$sql = "select * from ".table('company_favorites')." WHERE company_uid = ".intval($company_uid)." AND resume_id=".intval($resume_id)."  LIMIT 1";
	$info=$db->getone($sql);
	if ($info) return true;
	else return false;
}
//��ȡ��ҵ�˲ſ�
function get_favorites($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage)) $limit=" LIMIT ".$offset.','.$perpage;
	$selectstr="f.*,r.fullname,r.display_name,r.sex_cn,r.education_cn,r.experience_cn,r.intention_jobs,r.district_cn,r.addtime";
	$result = $db->query("SELECT ".$selectstr."  FROM ".table('company_favorites')." AS f ".$get_sql." ORDER BY f.did DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
		$row['intention_jobs_']=$row['intention_jobs'];
		$row['intention_jobs']=cut_str($row['intention_jobs'],18,0,"...");
		$row['resume_url']=url_rewrite('QS_resumeshow',array('id0'=>$row['resume_id'],'addtime'=>$row['addtime']),false);
		if ($row['display_name']=="2") $row['fullname']="N".str_pad($row['resume_id'],7,"0",STR_PAD_LEFT);
		$row_arr[] = $row;
	}
	return $row_arr;
}
//ɾ�� -�˲ſ��еļ���
function del_favorites($del_id,$uid)
{
	global $db;
	$uidsql=" AND company_uid=".intval($uid)."";
	if (!is_array($del_id)) $del_id=array($del_id);
	$sqlin=implode(",",$del_id);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	if (!$db->query("Delete from ".table('company_favorites')." WHERE did IN (".$sqlin.") ".$uidsql."")) return false;
	return true;
}
//�������Ƿ��Ѿ����ع�
function check_down_resumeid($resume_id,$company_uid)
{
	global $db;
	$sql = "select did from ".table('company_down_resume')." WHERE company_uid = ".intval($company_uid)." AND resume_id=".intval($resume_id)." LIMIT 1";
	$info=$db->getone($sql);
	if ($info) return true;
	else return false;
}
//�������Ƿ������
function check_interview($resume_id,$jobs_id,$company_uid)
{
	global $db;
	if ($resume_id==0 || $jobs_id==0 || $company_uid==0) return false;
	$sql = "select * from ".table('company_interview')." WHERE company_uid =".intval($company_uid)." AND resume_id=".intval($resume_id)." AND jobs_id=".intval($jobs_id)." LIMIT 1";
	$info=$db->getone($sql);
	return $info;
}
//ɾ�� -�����¼
function del_interview($del_id,$uid)
{
	global $db;
	$uidsql=" AND company_uid=".intval($uid)."";
	if (!is_array($del_id)) $del_id=array($del_id);
	$sqlin=implode(",",$del_id);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	if (!$db->query("Delete from ".table('company_interview')." WHERE did IN (".$sqlin.") ".$uidsql."")) return false;
	return true;
}
//�����¼�б�
function get_interview($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage)) $limit=" LIMIT ".$offset.','.$perpage;
	$selectstr="i.*,r.fullname,r.display_name,r.sex_cn,r.education_cn,r.experience_cn,r.intention_jobs,r.district_cn,r.addtime,j.jobs_name";
	$result = $db->query("SELECT  ".$selectstr."  FROM ".table('company_interview')." as i ".$get_sql." ORDER BY  i.did DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
		$row['resume_url']=url_rewrite('QS_resumeshow',array('id0'=>$row['resume_id'],'addtime'=>$row['addtime']));
		$row['intention_jobs']=cut_str($row['intention_jobs'],18,0,"...");
		if ($row['display_name']=="2") $row['fullname']="N".str_pad($row['resume_id'],7,"0",STR_PAD_LEFT);
		$row_arr[] = $row;
	}
	return $row_arr;
}
//��ȡ����ְλ
function get_apply_jobs($offset,$perpage,$get_sql= '')
{
	global $db;
	if(isset($offset)&&!empty($perpage)) $limit=" LIMIT ".$offset.','.$perpage;
	$selectstr=" a.*,r.fullname,r.display_name,r.sex_cn,r.experience_cn,r.district_cn,r.education_cn,r.intention_jobs,r.addtime,r.specialty,j.jobs_name ";
	$result = $db->query("SELECT ".$selectstr." FROM ".table('personal_jobs_apply')." as a ".$get_sql." ORDER BY a.did DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
		$row['specialty_']=$row['specialty'];
		$row['specialty']=cut_str($row['specialty'],16,0,"...");
		if ($row['display_name']=="2") $row['fullname']="N".str_pad($row['resume_id'],7,"0",STR_PAD_LEFT);
		$row['resume_url']=url_rewrite('QS_resumeshow',array('id0'=>$row['resume_id'],'addtime'=>$row['addtime']));
		$row_arr[] = $row;
	}
	return $row_arr;
}
function set_apply($id,$uid,$setlook)
{
	global $db;
	if (!is_array($id)) $id=array($id);
	$sqlin=implode(",",$id);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	$setsqlarr['personal_look']=intval($setlook);
	$wheresql=" did IN (".$sqlin.") AND company_uid=".intval($uid)."";
	return updatetable(table('personal_jobs_apply'),$setsqlarr,$wheresql);
}
//�ѷ���ְλ����
function count_jobs($uid,$emergency='',$level='')
{
	$wheresql=" WHERE uid='".intval($uid)."' ";
	if ($emergency) $wheresql.=" AND emergency=".intval($emergency)." ";
	if ($level) $wheresql.=" AND level=".intval($level)." ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('jobs').$wheresql;
	return get_total($total_sql);
}
//�����ؼ�������
function count_down_resume($uid)
{
	$wheresql=" INNER JOIN  ".table('resume')." as r ON d.company_uid=".intval($uid)." AND d.resume_id=r.id ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('company_down_resume')." as d ".$wheresql;
	return get_total($total_sql);
}
//�յ���ְλ��������
function count_jobs_apply($uid,$look='')
{
	$wheresql=" , ".table('resume')." AS r,  ".table('jobs')." AS j WHERE a.company_uid='".$_SESSION['uid']."' AND a.resume_id=r.id AND a.jobs_id=j.id";
	if(intval($look)>0)$wheresql.=" AND a.personal_look=".intval($look);
	$total_sql="SELECT COUNT(*) AS num FROM ".table('personal_jobs_apply')." AS a".$wheresql;
	return get_total($total_sql);
}
//���������Ҫ������
function count_interview($uid)
{
	$wheresql=" WHERE company_uid=".intval($uid)." ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('company_interview').$wheresql;
	return get_total($total_sql);
}
//�˲ſ�����
function count_favorites($uid)
{
	$wheresql=" INNER JOIN  ".table('resume')." AS r ON f.company_uid=".intval($uid)." AND f.resume_id=r.id ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('company_favorites')." AS f ".$wheresql;
	return get_total($total_sql);
}
//��ȡ��Ա״̬
function get_user_info($uid)
{
	global $db;
	$sql = "select uid,username,email,reg_time,reg_ip,last_login_time,last_login_ip,status,robot from ".table('members')." where uid = ".intval($uid)." LIMIT 1";
	return $db->getone($sql);
}
 //��ȡ��Ա��Ϣ-��������-ͷ��
function get_userprofile($uid)
{
	global $db;
	$sql = "select * from ".table('members_info')." where uid = ".intval($uid)." LIMIT 1";
	return $db->getone($sql);
}
//�޸Ļ�Ա״̬
function set_user_status($status,$uid)
{
	global $db;
	if (!$db->query("UPDATE ".table('members')." SET status= ".intval($status)." WHERE uid=".intval($uid)." LIMIT 1")) return false;
	if (!$db->query("UPDATE ".table('company_profile')." SET user_status= ".intval($status)." WHERE uid=".intval($uid)." ")) return false;
	if (!$db->query("UPDATE ".table('jobs')." SET user_status= ".intval($status)." WHERE uid=".intval($uid)." ")) return false;
	return true;
}
//�û������б�
function get_feedback($uid)
{
	global $db;
	$sql = "select * from ".table('feedback')." where uid=".intval($uid)." ORDER BY id desc";
	$list=$db->getall($sql);
	return $list;
}
//ɾ���û�����
function del_feedback($del_id,$uid)
{
	global $db;
	if (!$db->query("Delete from ".table('feedback')." WHERE id='".intval($del_id)."' AND uid='".intval($uid)."'  ")) return false;
	return true;
}
//���ֲ��� 
function report_deal($uid,$i_type=1,$points=0,$notes)
{
	global $db,$timestamp;
	if ($points==0) return true;
	$points_val=get_user_points($uid);
	if ($i_type==1)
	{
	$points_val=$points_val+$points;
	}
	if ($i_type==2)
	{
	$points_val=$points_val-$points;
	$points_val=$points_val<0?0:$points_val;
	}
	$sql = "INSERT INTO ".table('members_points_report')." (uid,i_type,points,remain_points,addtime,notes) VALUES ('$uid','$i_type','$points','$points_val', '$timestamp', '$notes')";
	if (!$db->query($sql))return false;
	$sql = "UPDATE ".table('members_points')." SET points= '$points_val' WHERE uid=".$uid;
	if (!$db->query($sql))return false;
	return true;
}
//++++++++++++++++++++++++++++�ײ�ģʽ
function set_members_setmeal($uid,$setmealid)
{
	global $db,$timestamp;
	$setmeal=$db->getone("select * from ".table('setmeal')." WHERE id = ".intval($setmealid)." AND display=1 LIMIT 1");
	if (empty($setmeal)) return false;
	$setsqlarr['effective']=1;
	$setsqlarr['setmeal_id']=$setmeal['id'];
	$setsqlarr['setmeal_name']=$setmeal['setmeal_name'];
	$setsqlarr['days']=$setmeal['days'];
	$setsqlarr['starttime']=$timestamp;
		if ($setmeal['days']>0)
		{
		$setsqlarr['endtime']=strtotime("".$setmeal['days']." days");
		}
		else
		{
		$setsqlarr['endtime']="0";	
		}
	$setsqlarr['expense']=$setmeal['expense'];
	$setsqlarr['jobs_ordinary']=$setmeal['jobs_ordinary'];
	$setsqlarr['jobs_emergency']=$setmeal['jobs_emergency'];
	$setsqlarr['jobs_headhunting']=$setmeal['jobs_headhunting'];
	$setsqlarr['download_resume_ordinary']=$setmeal['download_resume_ordinary'];
	$setsqlarr['download_resume_senior']=$setmeal['download_resume_senior'];
	$setsqlarr['interview_ordinary']=$setmeal['interview_ordinary'];
	$setsqlarr['interview_senior']=$setmeal['interview_senior'];
	$setsqlarr['talent_pool']=$setmeal['talent_pool'];
	$setsqlarr['recommended']=$setmeal['recommended'];
	$setsqlarr['map']=$setmeal['map'];
	$setsqlarr['added']=$setmeal['added'];
	if (!updatetable(table('members_setmeal'),$setsqlarr," uid=".$uid."")) return false;
		$setsqlarrmap['map_open']=$setsqlarr['map'];
		if (!updatetable(table('company_profile'),$setsqlarrmap," uid=".$uid."")) return false;
		$recommendedarr['recommend']=$setsqlarr['recommended'];
		if (!updatetable(table('company_profile'),$recommendedarr," uid=".$uid."")) return false;
	$setmeal_deadline['setmeal_deadline']=$setsqlarr['endtime'];
	if (!updatetable(table('jobs'),$setmeal_deadline," uid=".$uid."")) return false;
	if (!updatetable(table('company_profile'),$setmeal_deadline," uid=".$uid."")) return false;
	return true;
}
function get_setmeal($apply=false)
{
	global $db;
	if ($apply)
	{
	$wheresql=" AND apply=1";
	}
	$sql = "select * from ".table('setmeal')." WHERE display=1 ".$wheresql." ORDER BY show_order desc";
	return $db->getall($sql);
}
function get_setmeal_one($id)
{
	global $db;
	$sql = "select * from ".table('setmeal')."  WHERE id=".intval($id)." AND  display=1 AND apply=1 LIMIT 1";
	return $db->getone($sql);
}
function get_user_setmeal($uid)
{
	global $db;
	$sql = "select * from ".table('members_setmeal')."  WHERE uid=".intval($uid)." AND  effective=1 LIMIT 1";
	return $db->getone($sql);
}
function action_user_setmeal($uid,$action)
{
	global $db;
	$sql="update ".table('members_setmeal')." set `".$action."`=".$action."-1  WHERE uid=".intval($uid)."  AND  effective=1 LIMIT 1";
    return $db->query($sql);
}
function get_resume_basic($id)
{
	global $db;
	$sql = "select * from ".table('resume')." where id='".intval($id)."' LIMIT 1 ";
	$val=$db->getone($sql);
	if ($val['display_name']=="2")
	{
	$val['fullname']="N".str_pad($val['id'],7,"0",STR_PAD_LEFT);
	}
	return $val;
}
//����
function get_notice($offset,$perpage,$get_sql='',$titlelen=12)
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage)) $limit=" LIMIT ".$offset.','.$perpage;
	$result = $db->query("SELECT * FROM ".table('notice')." ".$get_sql." ORDER BY sort DESC,id DESC".$limit);
	while($row = $db->fetch_array($result))
	{
		$style_color=$row['tit_color']?"color:".$row['tit_color'].";":'';
		$style_font=$row['tit_b']=="1"?"font-weight:bold;":'';
		$row['title']=cut_str($row['title'],$titlelen,0,"....");
		if ($style_color || $style_font)$row['title']="<span style=".$style_color.$style_font.">".$row['title']."</span>";
		$row['url'] =$row['is_url']<>"http://"?$row['is_url']:"?act=notice_show&id=".$row['id'];
		$List[] = $row;
	}
	return $List;
}
function get_notice_one($id)
{
	global $db;
	$sql = "select * from ".table('notice')." WHERE id = '".intval($id)."'  LIMIT 1";
	return $db->getone($sql);
}
//������ҳ-��ȡ�����ܸ���Ȥ�ļ���
function get_concern_id($uid)
{
	global $db;
	$sql = "select id,subclass from ".table('jobs')." where   uid='".intval($uid)."'";
	$info=$db->getall($sql);
	if (is_array($info))
	{
		foreach($info as $s)
		{
		$str[]=$s['subclass'];
		}
		return implode("-",array_unique($str));
	}
	return "";
}
?>