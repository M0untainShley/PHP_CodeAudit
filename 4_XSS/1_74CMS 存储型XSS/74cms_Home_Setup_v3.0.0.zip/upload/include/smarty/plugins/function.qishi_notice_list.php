<?php
function smarty_function_qishi_notice_list($params, &$smarty)
{
global $db;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	case "��ʾ��Ŀ":
		$aset['row'] = $a[1];
		break;
	case "���ⳤ��":
		$aset['titlelen'] = $a[1];
		break;
	case "ժҪ����":
		$aset['infolen'] = $a[1];
		break;		
	case "��ʼλ��":
		$aset['start'] = $a[1];
		break;
	case "��ַ�":
		$aset['dot'] = $a[1];
		break;
	case "����":
		$aset['type_id'] = $a[1];
		break;
	case "����":
		$aset['displayorder'] = $a[1];
		break;
	case "��ҳ��ʾ":
		$aset['paged'] = $a[1];
		break;
	}
}
if (is_array($aset)) $aset=array_map("get_smarty_request",$aset);
$aset['listname']=$aset['listname']?$aset['listname']:"list";
$aset['row']=$aset['row']?intval($aset['row']):10;
$aset['start']=$aset['start']?intval($aset['start']):0;
$aset['titlelen']=$aset['titlelen']?intval($aset['titlelen']):15;
$aset['infolen']=$aset['infolen']?intval($aset['infolen']):0;
if ($aset['displayorder'])
{
	if (strpos($aset['displayorder'],'>'))
	{
	$arr=explode('>',$aset['displayorder']);
	$arr[0]=ereg('sort|id',$arr[0])?$arr[0]:"";
	$arr[1]=ereg('asc|desc',$arr[1])?$arr[1]:"";
		if ($arr[0] && $arr[1])
		{
		$orderbysql=" ORDER BY ".$arr[0]." ".$arr[1];
		}
	}
}
$wheresql=" WHERE is_display=1 ";
$aset['type_id']?$wheresql.=" AND type_id=".intval($aset['type_id'])." ":'';
if ($aset['paged'])
{
	require_once(QISHI_ROOT_PATH.'include/page.class.php');
	$total_sql="SELECT COUNT(*) AS num FROM ".table('notice').$wheresql;
	$total_count=get_total($total_sql);
	$pagelist = new page(array('total'=>$total_count, 'perpage'=>$aset['row'],'alias'=>'QS_noticelist','id0'=>$aset['type_id']));
	$currenpage=$pagelist->nowindex;
	$aset['start']=($currenpage-1)*$aset['row'];
		if ($total_count>$aset['row'])
		{
		$smarty->assign('page',$pagelist->show(3));
		}
}
$limit=" LIMIT ".abs($aset['start']).','.$aset['row'];
$result = $db->query("SELECT * FROM ".table('notice')." ".$wheresql.$orderbysql.$limit);
while($row = $db->fetch_array($result))
{
$row['title_']=$row['title'];
$style_color=$row['tit_color']?"color:".$row['tit_color'].";":'';
$style_font=$row['tit_b']=="1"?"font-weight:bold;":'';
$row['title']=cut_str($row['title'],$aset['titlelen'],0,$aset['dot']);
if ($style_color || $style_font)$row['title']="<span style=".$style_color.$style_font.">".$row['title']."</span>";
$row['url'] =$row['is_url']<>"http://"?$row['is_url']:url_rewrite('QS_noticeshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
$row['briefly_']=strip_tags($row['content']);
	if ($aset['infolen']>0)
	{
	$row['briefly']=cut_str(strip_tags($row['content']),$aset['infolen'],0,$aset['dot']);
	}
$list[] = $row;
}
$smarty->assign($aset['listname'],$list);
}
?>