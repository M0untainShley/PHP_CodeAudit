<?php
function smarty_function_qishi_resume_list($params, &$smarty)
{
global $db,$_CFG;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	case "��ʾ��Ŀ":
		$aset['row'] = $a[1];
		break;
	case "��ʼλ��":
		$aset['start'] = $a[1];
		break;
	case "��������":
		$aset['namelen'] = $a[1];
		break;
	case "�س���������":
		$aset['specialtylen'] = $a[1];
		break;
	case "����ְλ����":
		$aset['jobslen'] = $a[1];
		break;
	case "��ַ�":
		$aset['dot'] = $a[1];
		break;
	case "ְλ����":
		$aset['category'] = trim($a[1]);
		break;
	case "ְλС��":
		$aset['subclass'] = trim($a[1]);
		break;
	case "��������":
		$aset['district'] = $a[1];
		break;
	case "����С��":
		$aset['sdistrict'] = $a[1];
		break;
	case "ѧ��":
		$aset['education'] = $a[1];
		break;
	case "��������":
		$aset['experience'] = $a[1];
		break;
	case "�߼��˲�":
		$aset['talent'] = $a[1];
		break;
	case "�Ա�":
		$aset['sex'] = $a[1];
		break;
	case "��Ƭ":
		$aset['photo'] = $a[1];
		break;
	case "�ؼ���":
		$aset['key'] = $a[1];
		break;
	case "���ڷ�Χ":
		$aset['settr'] = $a[1];
		break;
	case "����":
		$aset['displayorder'] = $a[1];
		break;
	case "��ҳ��ʾ":
		$aset['paged'] = $a[1];
		break;
	}
}
if (is_array($aset)) $aset=array_map("get_smarty_request",$aset);
$aset['listname']=$aset['listname']?$aset['listname']:"list";
$aset['row']=$aset['row']?intval($aset['row']):10;
$aset['start']=$aset['start']?intval($aset['start']):0;
$aset['namelen']=$aset['namelen']?intval($aset['namelen']):4;
$aset['specialtylen']=$aset['specialtylen']?intval($aset['specialtylen']):0;
$aset['jobslen']=$aset['jobslen']?intval($aset['jobslen']):0;
if ($aset['displayorder'])
{
	if (strpos($aset['displayorder'],'>'))
	{
	$arr=explode('>',$aset['displayorder']);
	$arr[0]=ereg('refreshtime|click|id',$arr[0])?$arr[0]:"";
	$arr[1]=ereg('asc|desc',$arr[1])?$arr[1]:"";
		if ($arr[0] && $arr[1])
		{
		$orderbysql=" ORDER BY r.".$arr[0]." ".$arr[1];
		}
	}
}
if ($aset['category'] || $aset['subclass'])//��Ѱ���࿪��join
{
	$joinsql="  INNER  JOIN  ".table('resume_jobs')." AS j ON  r.id=j.pid ";
}
if ($_CFG['outdated_resume']=="1")
{
	$wheresql=$joinsql." WHERE  r.deadline>".time()." ";
}
else
{
	$wheresql=$joinsql." WHERE r.audit=1 AND r.display=1 ";
}
$wheresql.=" AND r.complete=1 ";
if ($aset['settr'])
{
	$settr_val=strtotime("-".intval($aset['settr'])." day");
	$wheresql.=" AND r.refreshtime > ".$settr_val;
}
if ($aset['district'])
{
	if (strpos($aset['district'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['district']);
		foreach($arr as $sid)
		{
			$orsql.=$or." r.district=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND r.district=".intval($aset['district'])." ";
	}	
}
if ($aset['sdistrict'])
{
	if (strpos($aset['sdistrict'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['sdistrict']);
		foreach($arr as $sid)
		{
			$orsql.=$or." r.sdistrict=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND r.sdistrict=".intval($aset['sdistrict'])." ";
	}
}
if ($aset['experience'])
{
	$wheresql.=" AND r.experience=".intval($aset['experience'])." ";
}
if ($aset['education'])
{
	$wheresql.=" AND r.education>=".intval($aset['education'])." ";
}
if ($_CFG['outdated_resume']=="1")
{
	$wheresql.=" AND r.audit=1 AND r.display=1 ";
}
if ($aset['talent'])
{
	$wheresql.=" AND r.talent=".intval($aset['talent'])." ";
}
if ($aset['photo'])
{
	$wheresql.=" AND r.photo_audit=1 AND r.photo_display=1  AND r.photo<>'' ";
}
if ($aset['sex'])
{
	$wheresql.=" AND r.sex=".intval($aset['sex'])."";
}
if ($aset['category'])
{
	if (strpos($aset['category'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['category']);
		foreach($arr as $sid)
		{
			$categorysql.=$or." j.category=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$categorysql.") ";
	}
	else
	{
	$wheresql.=" AND j.category=".intval($aset['category'])." ";
	}
}
if ($aset['subclass'])
{
	if (strpos($aset['subclass'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['subclass']);
		foreach($arr as $sid)
		{
			$subclasssql.=$or." j.subclass=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$subclasssql.") ";
	}
	else
	{
	$wheresql.=" AND j.subclass=".intval($aset['subclass'])." ";
	}
}
if ($aset['key'])
{
	$orderbysql="";
	$wheresql.=" AND  MATCH (r.`key`) AGAINST ('".'"'.cutgbkstring($aset['key']).'"'."') ";
}
		if ($aset['paged'])
		{
			require_once(QISHI_ROOT_PATH.'include/page.class.php');
			$total_sql="SELECT  COUNT(DISTINCT r.id) AS num  FROM  ".table('resume')." AS r ".$wheresql;
			$total_count=get_total($total_sql);
			//echo "SELECT  COUNT(DISTINCT r.id) AS num  FROM  ".table('resume')." AS r ".$wheresql;
			$page = new page(array('total'=>$total_count, 'perpage'=>$aset['row']));
			$currenpage=$page->nowindex;
			$offset=($currenpage-1)*$aset['row'];
			if ($total_count>$aset['row']) $smarty->assign('page',$page->show(3));
		}
	$offset=$offset?$offset:$aset['start'];
	$limit=" LIMIT ".abs($offset).','.$aset['row'];
	$selectstr="";
	$result = $db->query("SELECT DISTINCT r.id,r.* FROM ".table('resume')." AS r ".$wheresql.$orderbysql.$limit);
	//echo "SELECT DISTINCT r.id,r.* FROM ".table('resume')." AS r ".$wheresql.$orderbysql.$limit;
		while($row = $db->fetch_array($result))
		{
				if ($row['display_name']=="2")
				{
					$row['fullname']="N".str_pad($row['id'],7,"0",STR_PAD_LEFT);
					$row['fullname_']=$row['fullname'];		
				}
				else
				{
					$row['fullname_']=$row['fullname'];
					$row['fullname']=cut_str($row['fullname'],$aset['namelen'],0,$aset['dot']);
				}
			$row['specialty_']=strip_tags($row['specialty']);
			if ($aset['specialtylen']>0)
			{
			$row['specialty']=cut_str(strip_tags($row['specialty']),$aset['specialtylen'],0,$aset['dot']);
			}
			if ($aset['jobslen']>0)
			{
			$row['intention_jobs']=cut_str(strip_tags($row['intention_jobs']),$aset['jobslen'],0,$aset['dot']);
			}
			$row['photosrc']=$row['photo']?$_CFG['resume_photo_dir_thumb'].$row['photo']:$_CFG['resume_photo_dir_thumb']."no_photo.gif";
			$row['resume_url']=url_rewrite('QS_resumeshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
			$List[] = $row;
		}
	$smarty->assign($aset['listname'], $List);
}
?>