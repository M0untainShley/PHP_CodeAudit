<?php
/*********************************************
*��ҵ���
* *******************************************/
function smarty_function_qishi_jobs_show($params, &$smarty)
{
	global $db,$timestamp,$_CFG;
	$arr=explode(',',$params['set']);
	foreach($arr as $str)
	{
	$a=explode(':',$str);
		switch ($a[0])
		{
		case "ְλID":
			$aset['id'] = $a[1];
			break;
		case "�б���":
			$aset['listname'] = $a[1];
			break;
		}
	}
	$aset=array_map("get_smarty_request",$aset);
	$aset['id']=$aset['id']?intval($aset['id']):0;
	$aset['listname']=$aset['listname']?$aset['listname']:"list";
	$wheresql=" WHERE id=".$aset['id']." AND  display=1 AND audit=1  AND (setmeal_deadline=0 OR setmeal_deadline>".time().") AND  user_status=1";
	if ($_CFG['outdated_jobs']=="1")
	{
	$wheresql.=" AND deadline>".time()." ";
	}
	$sql = "select * from ".table('jobs').$wheresql." LIMIT 1";
	$val=$db->getone($sql);
	if (empty($val))
	{
		header("HTTP/1.1 404 Not Found"); 
		$smarty->display("404.htm");
		exit();
	}
	else
	{
		$profile=get_company_profile($val['company_id']);
		$val['company']=$profile;
		$val['expire']=sub_day($val['deadline'],time());		
		$val['company_url']=url_rewrite('QS_companyshow',array('id0'=>$val['company_id'],'addtime'=>$val['company_addtime']));
			if ($val['company']['logo'])
			{
			$val['company']['logo']=$_CFG['site_dir']."data/logo/".$val['company']['logo'];
			}
			else
			{
			$val['company']['logo']=$_CFG['site_dir']."data/logo/no_logo.gif";
			}		
	}
$smarty->assign($aset['listname'],$val);
}
function get_company_profile($id)
{
	global $db;
	$sql = "select * from ".table('company_profile')." where id=".intval($id)." LIMIT 1 ";
	return $db->getone($sql);
}
?>