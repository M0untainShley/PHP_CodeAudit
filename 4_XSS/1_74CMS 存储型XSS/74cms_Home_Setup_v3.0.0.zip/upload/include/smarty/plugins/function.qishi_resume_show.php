<?php
function smarty_function_qishi_resume_show($params, &$smarty)
{
global $db,$_CFG;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "����ID":
		$aset['id'] = $a[1];
		break;
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	}
}
$aset=array_map("get_smarty_request",$aset);
$aset['id']=$aset['id']?intval($aset['id']):0;
$aset['listname']=$aset['listname']?$aset['listname']:"list";
$wheresql=" WHERE  id=".$aset['id']."  AND audit=1  AND complete=1 AND user_status=1";
if ($_CFG['outdated_resume']=="1") $wheresql.=" and  deadline>'".time()."' ";
$sql = "select * from ".table('resume').$wheresql." LIMIT  1";
$val=$db->getone($sql);
if ($val)
{
	if ($val['display_name']=="2")$val['fullname']="N".str_pad($val['id'],7,"0",STR_PAD_LEFT);
	$val['fullname_']=$val['fullname'];
	$val['education_list']=get_resume_education($val['uid'],$val['id']);
	$val['work_list']=get_resume_work($val['uid'],$val['id']);
	$val['training_list']=get_resume_training($val['uid'],$val['id']);
	if ($val['photo_display']=="1" && $val['photo_audit']=="1" && $val['photo'])
	{
	$val['photosrc']=$_CFG['resume_photo_dir_thumb'].$val['photo'];
	}
	else
	{
	$val['photosrc']=$_CFG['resume_photo_dir_thumb']."no_photo.gif";
	}
}
else
{
	header("HTTP/1.1 404 Not Found"); 
	$smarty->display("404.htm");
	exit();
}
$smarty->assign($aset['listname'],$val);
}
function get_resume_education($uid,$pid)
{
	global $db;
	$sql = "SELECT * FROM ".table('resume_education')." WHERE uid='".intval($uid)."' AND pid='".intval($pid)."' ";
	return $db->getall($sql);
}
function get_resume_work($uid,$pid)
{
	global $db;
	$sql = "select * from ".table('resume_work')." where uid=".intval($uid)." AND pid='".$pid."' " ;
	return $db->getall($sql);
}
function get_resume_training($uid,$pid)
{
	global $db;
	$sql = "select * from ".table('resume_training')." where uid='".intval($uid)."' AND pid='".intval($pid)."'";
	return $db->getall($sql);
}
?>