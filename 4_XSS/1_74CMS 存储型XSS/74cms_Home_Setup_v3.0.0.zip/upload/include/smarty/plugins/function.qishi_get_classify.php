<?php
function smarty_function_qishi_get_classify($params, &$smarty)
{
global $db,$_CAT;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	case "����":
		$aset['act'] = $a[1];
		break;
	case "��ʾ��Ŀ":
		$aset['row'] = $a[1];
		break;
	case "���Ƴ���":
		$aset['titlelen'] = $a[1];
		break;
	case "��ַ�":
		$aset['dot'] = $a[1];
		break;
	case "id":
		$aset['id'] = $a[1];
		break;
	}
}
if (is_array($aset)) $aset=array_map("get_smarty_request",$aset);
$aset['listname']=$aset['listname']?$aset['listname']:"list";
$aset['titlelen']=$aset['titlelen']?intval($aset['titlelen']):18;
$act=$aset['act'];
if (intval($aset['row'])>0) $limit=" LIMIT ".intval($aset['row']);
//��ȡְλ����
if ($act=="QS_jobs")
{
	$id=intval($aset['id']);
	$result = $db->query("SELECT * FROM ".table('category_jobs')." where parentid=".$id." ORDER BY category_order desc,id asc".$limit);
	while($row = $db->fetch_array($result))
	{
	$row['categoryname']=cut_str($row['categoryname'],$aset['titlelen'],0,$aset['dot']);
	$row['title']=cut_str($row['categoryname'],$aset['titlelen'],0,$aset['dot']);
	$val[] = $row;
	}
}
elseif ($act=="QS_jobs_parent")
{
	if (strpos($aset['id'],"-"))
	{
		$arr=explode("-",$aset['id']);
		$idstr=implode(",",$arr);
		if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$idstr)) exit("err");
	}
	else
	{
		$idstr=intval($aset['id']);
	}
	if ($idstr=="0")
	{
		$val="";
	}
	else
	{
		$result = $db->query("SELECT parentid FROM ".table('category_jobs')." where id IN (".$idstr.")".$limit);
		while($row = $db->fetch_array($result))
		{
		$val[] =$row['parentid'];
		}
		$val=array_unique($val);
		$val=implode(",",$val);
	}
}
elseif ($act=="QS_district")
{
	
	if (isset($aset['id']))
	{
	$wheresql=" WHERE parentid=".intval($aset['id'])." ";
	}
	$sql = "select categoryname,id,parentid from ".table('category_district')." ".$wheresql."  ORDER BY category_order desc,id asc".$limit;
	$result = $db->query($sql);
	while($row = $db->fetch_array($result))
	{
	$row['categoryname']=cut_str($row['categoryname'],$aset['titlelen'],0,$aset['dot']);
	$row['title']=cut_str($row['categoryname'],$aset['titlelen'],0,$aset['dot']);
	$val[] = $row;
	}
}
elseif ($act=="QS_district_parent")
{
	if (strpos($aset['id'],"-"))
	{
		$arr=explode("-",$aset['id']);
		$idstr=implode(",",$arr);
		if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$idstr)) exit("err");
	}
	else
	{
		$idstr=intval($aset['id']);
	}
	if ($idstr=="0")
	{
		$val="";
	}
	else
	{
		$result = $db->query("SELECT parentid FROM ".table('category_district')." where id IN (".$idstr.")".$limit);
		while($row = $db->fetch_array($result))
		{
		$val[] =$row['parentid'];
		}
		$val=array_unique($val);
		$val=implode(",",$val);
	}
}
else
{
	if (!empty($_CAT[$act]))
	{
		foreach ($_CAT[$act] as $cat)
		{
		$cat['categoryname']=cut_str($cat['categoryname'],$aset['titlelen'],0,$aset['dot']);
		$val[] = $cat;
		}
	}
}
$smarty->assign($aset['listname'],$val);
}
?>