<?php
function smarty_function_qishi_news_category($params, &$smarty)
{
global $db;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	case "���Ƴ���":
		$aset['titlelen'] = $a[1];
		break;
	case "��ַ�":
		$aset['dot'] = $a[1];
		break;
	case "��Ѷ����":
		$aset['classify'] = $a[1];
		break;
	case "��ѶС��":
		$aset['typeid'] = $a[1];
		break;
	}
}
if (is_array($aset)) $aset=array_map("get_smarty_request",$aset);
$aset['listname']=$aset['listname']?$aset['listname']:"list";
$aset['titlelen']=$aset['titlelen']?intval($aset['titlelen']):8;
$params['classify']?$aset['classify']=$params['classify']:"";
$params['typeid']?$aset['typeid']=$params['typeid']:"";
$aset['typeid']<>""? $wheresqlarr['id']=intval($aset['typeid']):'';
$aset['classify']<>""? $wheresqlarr['parentid']=intval($aset['classify']):'';
	if (is_array($wheresqlarr))
	{
	$where_set=' WHERE';
		foreach ($wheresqlarr as $key => $value)
		{
		$wheresql .=$where_set. $comma.'`'.$key.'`'.'=\''.$value.'\'';
		$comma = ' AND ';
		$where_set='';
		}
	}
$result = $db->query("SELECT * FROM ".table('article_category')." ".$wheresql." ");
while($row = $db->fetch_array($result))
{
$row['url']=url_rewrite('QS_newslist',array('id0'=>$row['id']));
$row['title_']=$row['categoryname'];
$row['title']=cut_str($row['categoryname'],$aset['titlelen'],0,$aset['dot']);
$List[] = $row;
}
if ($aset['typeid'])
{
$List=$List[0];
}
$smarty->assign($aset['listname'],$List);
}
?>