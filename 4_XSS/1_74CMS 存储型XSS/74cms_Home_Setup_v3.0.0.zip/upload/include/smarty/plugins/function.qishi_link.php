<?php
function smarty_function_qishi_link($params, &$smarty)
{
global $db,$_CFG;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	case "��ʾ��Ŀ":
		$aset['row'] = $a[1];
		break;
	case "��ʼλ��":
		$aset['start'] = $a[1];
		break;
	case "���ֳ���":
		$aset['len'] = $a[1];
		break;
	case "��ַ�":
		$aset['dot'] = $a[1];
		break;
	case "����":
		$aset['linktype'] = $a[1];
		break;
	case "��������":
		$aset['alias'] = $a[1];
		break;
	}
}
	$aset=array_map("get_smarty_request",$aset);
	$aset['listname']=$aset['listname']?$aset['listname']:"list";
	$aset['row']=$aset['row']?intval($aset['row']):60;
	$aset['start']=$aset['start']?intval($aset['start']):0;
	$aset['len']=$aset['len']?intval($aset['len']):8;
	$aset['linktype']=$aset['linktype']?intval($aset['linktype']):1;
	unset($arr,$str,$a,$params);
	if ($aset['linktype']=="1"){
	$wheresql=" WHERE link_logo='' ";
	}
	else
	{
	$wheresql=" WHERE link_logo<>'' ";
	}
	$wheresql.=" AND display=1 ";
	if ($aset['alias']) $wheresql.=" AND alias='".$aset['alias']."' ";
	$limit=" LIMIT ".intval($aset['start']).','.intval($aset['row']);
	$result = $db->query("SELECT link_url,link_name,link_logo FROM ".table('link')." ".$wheresql." ORDER BY show_order DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
		$row['title_']=$row['title'];
		$row['title']=cut_str($row['link_name'],$aset['len'],0,$aset['dot']);
		$List[] = $row;
	}
$smarty->assign($aset['listname'],$List);
}
?>