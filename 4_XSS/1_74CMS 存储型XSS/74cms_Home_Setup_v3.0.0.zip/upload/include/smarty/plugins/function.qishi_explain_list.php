<?php
function smarty_function_qishi_explain_list($params, &$smarty)
{
	global $db;
	$arr=explode(',',$params['set']);
	foreach($arr as $str)
	{
	$a=explode(':',$str);
		switch ($a[0])
		{
		case "�б���":
			$aset['listname'] = $a[1];
			break;
		case "��ʾ��Ŀ":
			$aset['row'] = $a[1];
			break;
		case "���ⳤ��":
			$aset['titlelen'] = $a[1];
			break;
		case "��ʼλ��":
			$aset['start'] = $a[1];
			break;
		case "��ַ�":
			$aset['dot'] = $a[1];
			break;
		case "����":
			$aset['displayorder'] = $a[1];
			break;
		case "����ID":
			$aset['type_id'] = $a[1];
			break;
		}
	}
	if (is_array($aset)) $aset=array_map("get_smarty_request",$aset);
	$aset['listname']=$aset['listname']?$aset['listname']:"list";
	$aset['row']=$aset['row']?intval($aset['row']):10;
	$aset['start']=$aset['start']?intval($aset['start']):0;
	$aset['titlelen']=$aset['titlelen']?intval($aset['titlelen']):15;
if ($aset['displayorder'])
{
	if (strpos($aset['displayorder'],'>'))
	{
	$arr=explode('>',$aset['displayorder']);
	$arr[0]=ereg('article_order|id',$arr[0])?$arr[0]:"";
	$arr[1]=ereg('asc|desc',$arr[1])?$arr[1]:"";
		if ($arr[0] && $arr[1])
		{
		$orderbysql=" ORDER BY ".$arr[0]." ".$arr[1];
		}
	}
}
	$wheresql=" WHERE is_display=1 ";
	if ($aset['type_id'])$wheresql.=" AND  type_id=".intval($aset['type_id']);
	$limit=" LIMIT ".abs($aset['start']).','.$aset['row'];
	$result = $db->query("SELECT tit_color,tit_b,title,id,addtime,is_url FROM ".table('explain')." ".$wheresql.$orderbysql.$limit);
	while($row = $db->fetch_array($result))
	{
		$row['title_']=$row['title'];
		$style_color=$row['tit_color']?"color:".$row['tit_color'].";":'';
		$style_font=$row['tit_b']=="1"?"font-weight:bold;":'';
		$row['title']=cut_str($row['title'],$aset['titlelen'],0,$aset['dot']);
		if ($style_color || $style_font)$row['title']="<span style=".$style_color.$style_font.">".$row['title']."</span>";
		$row['url'] =$row['is_url']<>"http://"?$row['is_url']:url_rewrite('QS_explainshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
		$List[] = $row;
	}
	$smarty->assign($aset['listname'],$List);
}
?>