<?php
function smarty_function_qishi_jobs_contrast($params, &$smarty)
{
	global $db,$timestamp,$_CFG;
	$arr=explode(',',$params['set']);
	foreach($arr as $str)
	{
	$a=explode(':',$str);
		switch ($a[0])
		{
		case "ְλID":
			$aset['id'] = $a[1];
			break;
		case "�б���":
			$aset['listname'] = $a[1];
			break;
		}
	}
	$aset=array_map("get_smarty_request",$aset);
	$aset['listname']=$aset['listname']?$aset['listname']:"list";
	if (strpos($aset['id'],"-"))
	{
		$aset['id']=str_replace("-",",",$aset['id']);
		if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$aset['id'])) exit("err");		
	}
	else
	{
	exit();
	}

	$wheresql=" WHERE id IN (".$aset['id'].")  AND  display=1 AND audit=1  AND (setmeal_deadline=0 OR setmeal_deadline>".time().") AND  user_status=1";
	if ($_CFG['outdated_jobs']=="1")
	{
	$wheresql.=" AND deadline>".time()." ";
	}
	$sql = "select * from ".table('jobs').$wheresql." LIMIT 5";
	$val=$db->getall($sql);
$smarty->assign($aset['listname'],$val);
}
?>