<?php
/*********************************************
*��ʿְλ�б�
* *******************************************/
function smarty_function_qishi_jobs_list($params, &$smarty)
{
global $db,$_CFG;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	case "��ʾ��Ŀ":
		$aset['row'] = $a[1];
		break;
	case "��ʼλ��":
		$aset['start'] = $a[1];
		break;
	case "ְλ������":
		$aset['jobslen'] = $a[1];
		break;
	case "��ҵ������":
		$aset['companynamelen'] = $a[1];
		break;
	case "��������":
		$aset['brieflylen'] = $a[1];
		break;
	case "��ַ�":
		$aset['dot'] = $a[1];
		break;
	case "ְλ����":
		$aset['category'] = $a[1];
		break;
	case "ְλС��":
		$aset['subclass'] = $a[1];
		break;
	case "��������":
		$aset['district'] = $a[1];
		break;
	case "����С��":
		$aset['sdistrict'] = $a[1];
		break;
	case "��ҵ":
		$aset['trade'] = $a[1];
		break;
	case "ѧ��":
		$aset['education'] = $a[1];
		break;
	case "��������":
		$aset['experience'] = $a[1];
		break;
	case "����":
		$aset['wage'] = $a[1];
		break;
	case "ְλ����":
		$aset['nature'] = $a[1];
		break;
	case "������Ƹ":
		$aset['emergency'] = $a[1];
		break;
	case "�Ƽ�":
		$aset['recommend'] = $a[1];
		break;
	case "�ȼ�":
		$aset['level'] = $a[1];
		break;
	case "�ؼ���":
		$aset['key'] = $a[1];
		break;
	case "���ڷ�Χ":
		$aset['settr'] = $a[1];
		break;
	case "����":
		$aset['displayorder'] = $a[1];
		break;
	case "��ҳ��ʾ":
		$aset['paged'] = $a[1];
		break;
	case "��ԱUID":
		$aset['uid'] = $a[1];
		break;	
	}
}
$aset=array_map("get_smarty_request",$aset);
$aset['listname']=$aset['listname']?$aset['listname']:"list";
$aset['row']=$aset['row']?intval($aset['row']):10;
$aset['start']=$aset['start']?intval($aset['start']):0;
$aset['jobslen']=$aset['jobslen']?intval($aset['jobslen']):8;
$aset['companynamelen']=$aset['companynamelen']?intval($aset['companynamelen']):15;
$aset['brieflylen']=$aset['brieflylen']?intval($aset['brieflylen']):0;
if ($aset['displayorder'])
{
	if (strpos($aset['displayorder'],'>'))
	{
	$arr=explode('>',$aset['displayorder']);
	$arr[0]=ereg('refreshtime|id|click',$arr[0])?$arr[0]:"";
	$arr[1]=ereg('asc|desc',$arr[1])?$arr[1]:"";
		if ($arr[0] && $arr[1])
		{
		$orderbysql=" ORDER BY ".$arr[0]." ".$arr[1];
		}
	}
}
if ($aset['orderby'] && $aset['displayorder'])
{
$orderbysql=" ORDER BY ".$aset['orderby']." ".$aset['displayorder'];
}
if ($_CFG['outdated_jobs']=="1")
{
	$wheresql=" WHERE deadline>".time()." ";
}
else
{
	$wheresql=" WHERE audit=1 AND display=1  AND user_status=1 ";
}
if ($aset['category'])
{
	if (strpos($aset['category'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['category']);
		foreach($arr as $sid)
		{
			$orsql.=$or." category=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND category=".intval($aset['category'])." ";
	}
}
if ($aset['district'])
{
	if (strpos($aset['district'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['district']);
		foreach($arr as $sid)
		{
			$orsql.=$or." district=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND district=".intval($aset['district'])." ";
	}
}
if ($aset['sdistrict'])
{
	if (strpos($aset['sdistrict'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['sdistrict']);
		foreach($arr as $sid)
		{
			$orsql.=$or." sdistrict=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND sdistrict=".intval($aset['sdistrict'])." ";
	}
}
if ($aset['subclass'])
{
	if (strpos($aset['subclass'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['subclass']);
		foreach($arr as $sid)
		{
			$orsql.=$or." subclass=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND subclass=".intval($aset['subclass'])." ";
	}
}
if ($aset['trade'])
{
	if (strpos($aset['trade'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['trade']);
		foreach($arr as $sid)
		{
			$orsql.=$or." trade=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND trade=".intval($aset['trade'])." ";
	}
}
if ($aset['settr'])
{
	$settr=intval($aset['settr']);
	if ($settr>0)
	{
	$settr_val=strtotime("-".$aset['settr']." day");
	$wheresql.=" AND refreshtime>".$settr_val;
	}
}
if ($aset['education'])
{
	$wheresql.=" AND education=".intval($aset['education']);
}
if ($aset['wage'])
{
	$wheresql.=" AND wage=".intval($aset['wage']);
}
$wheresql.=" AND (setmeal_deadline=0 OR setmeal_deadline>".time().")";
if ($_CFG['outdated_jobs']=="1")
{
	$wheresql.=" AND audit=1 AND display=1 AND user_status=1 ";
}
if ($aset['experience'])
{
	$wheresql.=" AND experience=".intval($aset['experience']);
}
if ($aset['uid'])
{
	$wheresql.=" AND uid=".intval($aset['uid']);
}
if ($aset['emergency'])
{
	$wheresql.=" AND emergency=".intval($aset['emergency']);
}
if ($aset['recommend'])
{
	$wheresql.=" AND recommend=".intval($aset['recommend']);
}
if ($aset['level'])
{
	$wheresql.=" AND level=".intval($aset['level']);
}
if ($aset['nature'])
{
	if (strpos($aset['nature'],"-"))
	{
		$or=$orsql="";
		$arr=explode("-",$aset['nature']);
		foreach($arr as $sid)
		{
			$orsql.=$or." nature=".intval($sid);
			$or=" OR ";
		}
		$wheresql.=" AND  (".$orsql.") ";
	}
	else
	{
	$wheresql.=" AND nature=".intval($aset['nature'])." ";
	}
}
if ($aset['key'])
{
	$wheresql.=" AND  MATCH (`key`) AGAINST ('".'"'.cutgbkstring($aset['key']).'"'."') ";
	$orderbysql="";
}
if ($aset['paged'])
{
	require_once(QISHI_ROOT_PATH.'include/page.class.php');
	$total_sql="SELECT COUNT(*) AS num FROM ".table('jobs').$wheresql;
	//echo $total_sql;
	$total_count=get_total($total_sql);
	$page = new page(array('total'=>$total_count, 'perpage'=>$aset['row']));
	$currenpage=$page->nowindex;
	$aset['start']=($currenpage-1)*$aset['row'];
	$aset['start']>1000 && $aset['start']=1000;
	if ($total_count>$aset['row']) $smarty->assign('page',$page->show(3));
}
	$limit=" LIMIT ".abs($aset['start']).','.$aset['row'];
	$result = $db->query("SELECT * FROM ".table('jobs')." ".$wheresql.$orderbysql.$limit);
	//echo "SELECT * FROM ".table('jobs')." ".$wheresql.$orderbysql.$limit;
		while($row = $db->fetch_array($result))
		{
		$row['jobs_name_']=$row['jobs_name'];
		$row['jobs_name']=cut_str($row['jobs_name'],$aset['jobslen'],0,$aset['dot']);
			if ($aset['brieflylen']>0)
			{
				$row['briefly']=cut_str(strip_tags($row['contents']),$aset['brieflylen'],0,$aset['dot']);
			}
			else
			{
				$row['briefly']=strip_tags($row['contents']);
			}
		$row['briefly_']=strip_tags($row['contents']);
		$row['companyname_']=$row['companyname'];
		$row['companyname']=cut_str($row['companyname'],$aset['companynamelen'],0,$aset['dot']);
		$row['jobs_url']=url_rewrite('QS_jobsshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
		$row['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['company_id'],'addtime'=>$row['company_addtime']));
		$list[] = $row;
		}
		$smarty->assign($aset['listname'],$list);
}
?>