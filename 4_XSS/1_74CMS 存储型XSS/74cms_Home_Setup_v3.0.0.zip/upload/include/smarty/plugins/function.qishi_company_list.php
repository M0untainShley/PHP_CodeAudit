<?php
function smarty_function_qishi_company_list($params, &$smarty)
{
global $db,$_CFG;
$arr=explode(',',$params['set']);
foreach($arr as $str)
{
$a=explode(':',$str);
	switch ($a[0])
	{
	case "�б���":
		$aset['listname'] = $a[1];
		break;
	case "��ʾ��Ŀ":
		$aset['row'] = $a[1];
		break;
	case "�Ƽ�":
		$aset['recommend'] = $a[1];
		break;
	case "��ʼλ��":
		$aset['start'] = $a[1];
		break;
	case "ְλ������":
		$aset['jobslen'] = $a[1];
		break;
	case "��ʾְλ":
		$aset['jobsrow'] = $a[1];
		break;
	case "��ҵ������":
		$aset['companynamelen'] = $a[1];
		break;
	case "��ַ�":
		$aset['dot'] = $a[1];
		break;
	case "��ҵ":
		$aset['trade'] = $a[1];
		break;
	case "���ڷ�Χ":
		$aset['settr'] = $a[1];
		break;		
	case "������Ƹ":
		$aset['emergency'] = $a[1];
		break;
	case "����":
		$aset['displayorder'] = $a[1];
		break;
	case "��ҳ��ʾ":
		$aset['paged'] = $a[1];
		break;
	}
}
if (is_array($aset)) $aset=array_map("get_smarty_request",$aset);
$aset['listname']=$aset['listname']?$aset['listname']:"list";
$aset['row']=$aset['row']?intval($aset['row']):10;
$aset['start']=$aset['start']?intval($aset['start']):0;
$aset['jobslen']=$aset['jobslen']?intval($aset['jobslen']):8;
$aset['jobsrow']=$aset['jobsrow']?intval($aset['jobsrow']):0;
$aset['companynamelen']=$aset['companynamelen']?intval($aset['companynamelen']):16;
if ($aset['displayorder'])
{
	if (strpos($aset['displayorder'],'>'))
	{
	$arr=explode('>',$aset['displayorder']);
	$arr[0]=ereg('refreshtime|id|click',$arr[0])?$arr[0]:"";
	$arr[1]=ereg('asc|desc',$arr[1])?$arr[1]:"";
		if ($arr[0] && $arr[1])
		{
		$orderbysql=" ORDER BY ".$arr[0]." ".$arr[1];
		}
	}
}
if ($_CFG['outdated_jobs']=="1")//����ʾ������Ϣʱ������������
{
	$wheresql=" WHERE deadline>".time()."  AND audit=1 AND display=1 AND user_status=1 ";
}
else
{
	$wheresql=" WHERE audit=1 AND display=1  AND user_status=1 ";
}
$wheresql.=" AND (setmeal_deadline=0 OR setmeal_deadline>".time().")";
if ($aset['trade'])
{
	$wheresql.=" AND trade=".intval($aset['trade']);
}
if ($aset['recommend'])
{
	$wheresql.=" AND recommend=".intval($aset['recommend']);
}

if ($aset['emergency'])
{
	$wheresql.=" AND emergency=".intval($aset['emergency']);
}
$limit=" LIMIT ".abs($aset['start']).','.$aset['row'];
$sql1="SELECT DISTINCT uid FROM ".table('jobs').$wheresql.$orderbysql.$limit;
//echo $sql1;
$result1 = $db->query($sql1);
while($row = $db->fetch_array($result1))
{
	$uidarr[]=$row['uid'];
}
if ($uidarr)
{
	$uid= implode(",",$uidarr);
	$wheresql.=" AND uid IN (".$uid.") ";
	$sql2="SELECT company_id,companyname,company_addtime,refreshtime,id,jobs_name,addtime,uid FROM ".table('jobs').$wheresql.$orderbysql;
	//echo $sql2;
	$result2 = $db->query($sql2);
	while($row = $db->fetch_array($result2))
	{
		$companyarray[$row['uid']]['companyname_']=$row['companyname'];
		$companyarray[$row['uid']]['companyname']=cut_str($row['companyname'],$aset['companynamelen'],0,$aset['dot']);
		$companyarray[$row['uid']]['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['company_id'],'addtime'=>$row['company_addtime']));
		$companyarray[$row['uid']]['company_addtime']=$row['company_addtime'];
		$companyarray[$row['uid']]['refreshtime']=$row['refreshtime'];
		$companyarray[$row['uid']]['jobs'][$row['id']]['jobs_addtime']=$row['addtime'];
		$companyarray[$row['uid']]['jobs'][$row['id']]['jobs_refreshtime']=$row['refreshtime'];
		$companyarray[$row['uid']]['jobs'][$row['id']]['jobs_click']=$row['click'];
		$companyarray[$row['uid']]['jobs'][$row['id']]['jobs_name']=cut_str($row['jobs_name'],$aset['jobslen'],0,$aset['dot']);
		$companyarray[$row['uid']]['jobs'][$row['id']]['jobs_url']=url_rewrite('QS_jobsshow',array('id0'=>$row['id'],'addtime'=>$row['addtime']));
		if ($aset['jobsrow']>0)$companyarray[$row['uid']]['jobs']=array_slice($companyarray[$row['uid']]['jobs'],0,$aset['jobsrow']);
	}
}
$smarty->assign($aset['listname'],$companyarray);
}
?>