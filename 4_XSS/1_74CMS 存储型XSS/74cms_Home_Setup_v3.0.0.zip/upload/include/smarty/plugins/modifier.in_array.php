<?php
function smarty_modifier_in_array($str,$arr)
{
        return in_array($str,$arr);
}
?>