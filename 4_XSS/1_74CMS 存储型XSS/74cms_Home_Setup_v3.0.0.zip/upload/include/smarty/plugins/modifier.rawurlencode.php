<?php
function smarty_modifier_rawurlencode($text)
{
    return rawurlencode($text);
}
?>
