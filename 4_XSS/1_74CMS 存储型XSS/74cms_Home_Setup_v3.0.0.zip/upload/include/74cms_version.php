<?php
if(!defined('IN_QISHI'))die('Access Denied!');
define('QISHI_VERSION','3.0');
define('QISHI_RELEASE', '20111027');
?>