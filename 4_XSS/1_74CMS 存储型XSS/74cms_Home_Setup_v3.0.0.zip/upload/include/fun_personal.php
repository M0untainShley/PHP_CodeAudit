<?php
 /*
 * 74cms ���˻�Ա����
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
 if(!defined('IN_QISHI'))
 {
 	die('Access Denied!');
 }
//��ȡ����������Ϣ
function get_resume_basic($uid,$id)
{
	global $db;
	$sql = "select * from ".table('resume')." where id='".intval($id)."'  AND uid='".intval($uid)."' LIMIT 1 ";
	$info=$db->getone($sql);
	if ($info) $info['number']="N".str_pad($info['id'],7,"0",STR_PAD_LEFT);
	return $info;
}
//��ȡ���������б�
function get_resume_education($uid,$pid)
{
	global $db;
	if (intval($uid)!=$uid) return false;
	$sql = "SELECT * FROM ".table('resume_education')." WHERE  pid='".intval($pid)."' AND uid='".intval($uid)."' ";
	return $db->getall($sql);
}
//��ȡ ���� ��������
function get_resume_education_one($uid,$id)
{
	global $db;
	$sql = "select * from ".table('resume_education')." where id='".intval($id)."' AND uid='".intval($uid)."' LIMIT 1";
	return $db->getone($sql);
}
//��ȡ����������
function get_resume_work($uid,$pid)
{
	global $db;
	$sql = "select * from ".table('resume_work')." where pid='".$pid."' AND uid=".intval($uid)."" ;
	return $db->getall($sql);
}
//��ȡ ���� ��������
function get_resume_work_one($uid,$pid,$id)
{
	global $db;
	$sql = "select * from ".table('resume_work')." where id='".intval($id)."' AND pid='".intval($pid)."' AND uid='".intval($uid)."' LIMIT 1 ";
	return $db->getone($sql);
}
//��ȡ����ѵ�����б�
function get_resume_training($uid,$pid)
{
	global $db;
	$sql = "select * from ".table('resume_training')." where pid='".intval($pid)."' AND  uid='".intval($uid)."' ";
	return $db->getall($sql);
}
//��ȡ ���� ��ѵ����
function get_resume_training_one($uid,$pid,$id)
{
	global $db;
	$sql = "select * from ".table('resume_training')." where id='".intval($id)."' AND pid='".intval($pid)."'  AND uid='".intval($uid)."'  LIMIT 1 ";
	return $db->getone($sql);
}
//��ȡ����ְλ
function get_resume_jobs($pid)
{
	global $db;
	$sql = "select * from ".table('resume_jobs')." where pid='".$pid."' " ;
	return $db->getall($sql);
}
//��������ְλ
function add_resume_jobs($pid,$uid,$arr)
{
	global $db;
	$db->query("Delete from ".table('resume_jobs')." WHERE pid='".intval($pid)."'");
	foreach($arr as $a)
	{
	$setsqlarr['uid']=intval($uid);
	$setsqlarr['pid']=intval($pid);
	$setsqlarr['category']=intval($a[0]);
	$setsqlarr['subclass']=intval($a[1]);
		if (!inserttable(table('resume_jobs'),$setsqlarr))return false;
	}
	return true;
}
 //��ȡ��Ա��Ϣ
function get_user_info($uid)
{
	global $db;
	$sql = "select uid,username,email,reg_time,reg_ip,last_login_time,last_login_ip,status,robot from ".table('members')." where uid = ".intval($uid)." LIMIT 1";
	return $db->getone($sql);
}
 //��ȡ��Ա��Ϣ-��������-ͷ��
function get_userprofile($uid)
{
	global $db;
	$sql = "select * from ".table('members_info')." where uid = ".intval($uid)." LIMIT 1";
	return $db->getone($sql);
}
//�����û�����
function get_resume_list($wheresql,$titlele=8,$complete=false)
{
	global $db;
		if ($complete==true) $wheresql=$wheresql." AND complete=1 ";
		$result = $db->query("select * from ".table('resume')." ".$wheresql);
		while($row = $db->fetch_array($result))
		{
			$row['title']=cut_str($row['title'],$titlele,0,"...");
			$row['deadline']=($row['deadline']-time())>0?$row['deadline']:0;
			$row_arr[] = $row;
		}
		return $row_arr;
}
//ˢ�¼���
function refresh_resume($uid)
{
	global $db;
	if (!$db->query("update  ".table('resume')."  SET refreshtime='".time()."'  WHERE uid='".intval($uid)."'")) return false;
	return true;
}
//ɾ������
function del_resume($uid,$aid)
{
	global $db;
	if (!is_array($aid))$aid=array($aid);
	$sqlin=implode(",",$aid);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	if (!$db->query("Delete from ".table('resume')." WHERE id IN (".$sqlin.") AND uid=".intval($uid)." ")) return false;
	if (!$db->query("Delete from ".table('resume_jobs')." WHERE pid IN (".$sqlin.") AND uid=".intval($uid)." ")) return false;
	if (!$db->query("Delete from ".table('resume_education')." WHERE pid IN (".$sqlin.") AND uid=".intval($uid)." ")) return false;
	if (!$db->query("Delete from ".table('resume_training')." WHERE pid IN (".$sqlin.") AND uid=".intval($uid)." ")) return false;
	if (!$db->query("Delete from ".table('resume_work')." WHERE pid IN (".$sqlin.") AND uid=".intval($uid)." ")) return false;
	return true;
}
//�޸ļ�����Ƭ��ʾ����
function edit_photo_display($uid,$pid,$display)
{
	global $db;
	$sql="update  ".table('resume')."  SET photo_display='".intval($display)."' WHERE uid='".intval($uid)."' AND id='".intval($pid)."' LIMIT 1";
	return $db->query($sql);
}
//����������ɳ̶�
function check_resume($uid,$pid)
{
	global $db,$timestamp,$_CFG;
	$percent=0;
	$resume_basic=get_resume_basic($uid,$pid);//������������
	$resume_intention=$resume_basic['intention_jobs'];//��ְ����
	$resume_specialty=$resume_basic['specialty'];//�����س�
	$resume_education=get_resume_education($uid,$pid);//��������
	if (!empty($resume_basic))$percent=$percent+15;
	if (!empty($resume_intention))$percent=$percent+15;
	if (!empty($resume_specialty))$percent=$percent+15;
	if (!empty($resume_education))$percent=$percent+15;
	if ($percent<60)
	{
		$setsqlarr['complete_percent']=$percent;
		$setsqlarr['complete']=2;
	}
	else
	{
		$resume_work=get_resume_work($uid,$pid);//��������
		$resume_training=get_resume_training($uid,$pid);//��ѵ����
		$resume_photo=$resume_basic['photo'];
		if (!empty($resume_work))$percent=$percent+13;
		if (!empty($resume_training))$percent=$percent+13;
		if (!empty($resume_photo))$percent=$percent+14;
		$setsqlarr['complete']=1;
		$setsqlarr['complete_percent']=$percent;
		$setsqlarr['key']=$resume_basic['intention_jobs'];
		$setsqlarr['key'].=$resume_basic['education_cn'].$resume_basic['recentjobs'].$resume_basic['specialty'].$resume_education[0]['school'].$resume_basic['fullname'];
		$setsqlarr['key']=cutgbkstring($setsqlarr['key']);
		$setsqlarr['refreshtime']=$timestamp;		
	}
	//�������״̬
	if ($_CFG['audit_resume']==1)//���緢����Ҫ���
	{
	$setsqlarr['audit']=2;
	}
	else
	{
	$setsqlarr['audit']=1;
	}
	updatetable(table('resume'),$setsqlarr,"uid='".intval($uid)."' AND id='".intval($pid)."'");
	require_once(QISHI_ROOT_PATH.'include/fun_make_html.php');
	make_html_resume_show($resume_basic['id']);
}
//��������
function get_invitation($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage))
	{
	$limit=" LIMIT ".intval($offset).','.intval($perpage);
	}
	$select="i.*,j.jobs_name,j.addtime,j.companyname,j.company_addtime,j.district_cn,j.wage_cn,r.fullname";
	$sql="SELECT ".$select." from ".table('company_interview')." i ,".table('jobs')."  j , ".table('resume')." r   ".$get_sql." ORDER BY did DESC ".$limit;
	$result = $db->query($sql);
	while($row = $db->fetch_array($result))
	{
	$row['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['company_id'],'addtime'=>$row['company_addtime']));
	$row['jobs_url']=url_rewrite('QS_jobsshow',array('id0'=>$row['jobs_id'],'addtime'=>$row['addtime']));
	$row_arr[] = $row;
	}
	return $row_arr;
}
//�鿴 -�����¼
function set_invitation($id,$uid,$setlook)
{
	global $db;
	if (!is_array($id)) $id=array($id);
	$sqlin=implode(",",$id);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	$setsqlarr['personal_look']=intval($setlook);
	$wheresql=" did IN (".$sqlin.") AND resume_uid=".intval($uid)."";
	return updatetable(table('company_interview'),$setsqlarr,$wheresql);
}
//���ӵ�ְλ�ղ�
function add_favorites($id,$uid)
{
	global $db,$timestamp;
		if (strpos($id,"-"))
		{
			$id=str_replace("-",",",$id);
			if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$id)) return false;
		}
		else
		{
		$id=intval($id);
		}
	$sql = "select * from ".table('jobs')." WHERE id IN (".$id.") ";
	$jobs=$db->getall($sql);
	$i=0;
	foreach($jobs as $list)
	{
		$sql1 = "select jobs_id from ".table('personal_favorites')." where jobs_id=".$list['id']." AND personal_uid=".$uid."  LIMIT 1";
		if ($db->getone($sql1)) continue ;
		$setsqlarr['personal_uid']=$uid;
		$setsqlarr['jobs_id']=$list['id'];
		$setsqlarr['jobs_name']=$list['jobs_name'];
		$setsqlarr['jobs_addtime']=$list['addtime'];
		$setsqlarr['company_id']=$list['company_id'];
		$setsqlarr['company_name']=$list['companyname'];
		$setsqlarr['company_addtime']=$list['company_addtime'];
		$setsqlarr['addtime']=$timestamp;
		inserttable(table('personal_favorites'),$setsqlarr);
		$i=$i+1;
	}
	return $i;
}
//��ȡ�ղؼ�
function get_favorites($offset,$perpage,$get_sql= '')
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage))
	{
	$limit=" LIMIT ".$offset.','.$perpage;
	}
	$result = $db->query("SELECT * FROM ".table('personal_favorites')." ".$get_sql." ORDER BY did DESC ".$limit);
	while($row = $db->fetch_array($result))
	{
	$row['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['company_id'],'addtime'=>$row['company_addtime']));
	$row['jobs_url']=url_rewrite('QS_jobsshow',array('id0'=>$row['jobs_id'],'addtime'=>$row['jobs_addtime']));
	$row_arr[] = $row;
	}
	return $row_arr;
}
//ɾ�� -�ղؼ�
function del_favorites($id,$uid)
{
	global $db;
	$uidsql=" AND personal_uid=".intval($uid)."";
	if (!is_array($id)) $id=array($id);
	$sqlin=implode(",",$id);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	$sql="Delete from ".table('personal_favorites')." WHERE did IN (".$sqlin.") ".$uidsql."";
	return $db->query($sql);
}
//���ְλ�Ƿ������
function check_jobs_apply($jobs_id,$resume_id,$p_uid)
{
	global $db;
	$sql = "select * from ".table('personal_jobs_apply')." WHERE personal_uid = '".intval($p_uid)."' AND jobs_id='".intval($jobs_id)."'  AND resume_id='".intval($resume_id)."' LIMIT 1";
	return $db->getone($sql);
}
//��ȡ���컹��������ְλ����
function get_now_applyjobs_num($uid)
{
	global $db;
	$now = mktime(0,0,0,date("m"),date("d"),date("Y"));
	$wheresql=" WHERE personal_uid = ".intval($uid)." AND apply_addtime>".$now." ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('personal_jobs_apply').$wheresql;
	return get_total($total_sql);
}
//��ȡ����ְλ�б�
function get_apply_jobs($offset,$perpage,$get_sql= '')
{
	global $db;
	if(isset($offset)&&!empty($perpage)) $limit=" LIMIT ".intval($offset).','.intval($perpage);
	$select=" a.*,j.jobs_name,j.addtime,j.companyname,j.company_addtime,j.wage_cn,r.fullname";
	$sql="SELECT ".$select." FROM ".table('personal_jobs_apply')." a ,".table('jobs')." j ,".table('resume')." r ".$get_sql." ORDER BY a.did DESC ".$limit;
	$result = $db->query($sql);
	while($row = $db->fetch_array($result))
	{
		$row['company_url']=url_rewrite('QS_companyshow',array('id0'=>$row['company_id'],'addtime'=>$row['company_addtime']));
		$row['jobs_url']=url_rewrite('QS_jobsshow',array('id0'=>$row['jobs_id'],'addtime'=>$row['addtime']));
		$row_arr[] = $row;
	}
return $row_arr;
}
function get_jobs($id)
{
	global $db;
	if (strpos($id,"-"))
	{
		$id=str_replace("-",",",$id);
		if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$id)) return false;
	}
	else
	{
	$id=intval($id);
	}
	$sql = "select * from ".table('jobs')." WHERE id IN (".$id.") ";
	return $db->getall($sql);
}
function get_jobs_contact($id)
{
	global $db;
	$sql = "select * from ".table('jobs_contact')." WHERE pid =".intval($id)."  LIMIT 1 ";
	return $db->getone($sql);
}
//ɾ�� -����ְλ��¼
function del_jobs_apply($del_id,$uid)
{
	global $db;
	$uidsql=" AND personal_uid=".intval($uid)." ";
	if (!is_array($del_id)) $del_id=array($del_id);
	$sqlin=implode(",",$del_id);
	if (!preg_match("/^(\d{1,10},)*(\d{1,10})$/",$sqlin)) return false;
	if (!$db->query("Delete from ".table('personal_jobs_apply')." WHERE did IN (".$sqlin.") ".$uidsql."")) return false;
	return true;
}
//��������
function count_resume($uid)
{
	$wheresql=" WHERE uid='".intval($uid)."' ";
	$total_sql="SELECT COUNT(*) AS num FROM ".table('resume').$wheresql;
	return get_total($total_sql);
}
//������������
function count_interview($uid,$look=NULL)
{
	$wheresql=" WHERE  i.resume_uid='".intval($_SESSION['uid'])."' AND i.jobs_id=j.id  AND i.resume_id=r.id";
	if (intval($look)>0) $wheresql.=" AND  i.personal_look=".intval($look);
	$total_sql="SELECT COUNT(*) AS num FROM ".table('company_interview')." i ,".table('jobs')."  j , ".table('resume')." r".$wheresql;
	return get_total($total_sql);
}
//����ְλ����
function count_personal_jobs_apply($uid,$look=NULL)
{
	$wheresql=" WHERE a.personal_uid='".intval($_SESSION['uid'])."' AND a.jobs_id=j.id AND a.resume_id=r.id";
	if(intval($look)>0)	$wheresql.=" AND a.personal_look=".intval($look);
	$total_sql="SELECT COUNT(*) AS num FROM ".table('personal_jobs_apply')." a ,".table('jobs')." j ,".table('resume')." r ".$wheresql;
	return get_total($total_sql);
}
//ְλ�ղؼ�����
function count_jobs_library($uid,$days=NULL)
{
	$wheresql=" WHERE personal_uid=".intval($uid)." ";
	if (intval($days)>0)
	{
	$settr_val=strtotime("-".$days." day");
	$wheresql.=" AND addtime>".$settr_val;
	}
	$total_sql="SELECT COUNT(*) AS num FROM ".table('personal_favorites').$wheresql;
	return get_total($total_sql);
}
//�û������б�
function get_feedback($uid)
{
	global $db;
	$sql = "select * from ".table('feedback')." where uid='".intval($uid)."' ORDER BY id desc";
	return $db->getall($sql);
}
//ɾ���û�����
function del_feedback($del_id,$uid)
{
	global $db;
	if (!$db->query("Delete from ".table('feedback')." WHERE id='".intval($del_id)."' AND uid='".intval($uid)."'  ")) return false;
	return true;
}
//�޸Ļ�Ա״̬
function set_user_status($status,$uid)
{
	global $db;
	if (!$db->query("UPDATE ".table('members')." SET status= ".intval($status)." WHERE uid=".intval($uid)." LIMIT 1")) return false;
	if (!$db->query("UPDATE ".table('resume')." SET user_status= ".intval($status)." WHERE uid=".intval($uid)." ")) return false;
	return true;
}
//����ְλ����id��ȡ�˷�����Ϣ(����)------���ڴ�������-��������ְλ����----------
function get_jobs_category_one($id)
{
	global $db;
	$sql = "select * from ".table('category_jobs')." where id=".intval($id)." LIMIT 1";
	$info=$db->getone($sql);
	return $info;
}
//������ҳ-��ȡ�����ܸ���Ȥ��ְλID
function get_interest_jobs_id($uid)
{
	global $db;
	$sql = "select id from ".table('resume')." where   uid='".intval($uid)."'  AND complete=1  LIMIT 3 ";
	$info=$db->getall($sql);
	if (is_array($info))
	{
		foreach($info as $s)
		{
		$jobsid=get_resume_jobs($s['id']);
			if(is_array($jobsid))
			{
			foreach($jobsid as $cid)
			 {
			 $interest_id[]=$cid['subclass'];
			 }
			}
		}
		if (is_array($interest_id)) return implode("-",array_unique($interest_id));
	}
	return "";	
}
//���ְλ�Ƿ�ٱ���
function check_jobs_report($uid,$jobs_id)
{
	global $db;
	$sql = "select id from ".table('report')." WHERE uid = '".intval($uid)."' AND jobs_id='".intval($jobs_id)."' LIMIT 1";
	return $db->getone($sql);
}
//����
function get_notice($offset,$perpage,$get_sql='',$titlelen=12)
{
	global $db;
	$row_arr = array();
	if(isset($offset)&&!empty($perpage)) $limit=" LIMIT ".$offset.','.$perpage;
	$result = $db->query("SELECT * FROM ".table('notice')." ".$get_sql." ORDER BY sort DESC,id DESC".$limit);
	while($row = $db->fetch_array($result))
	{
		$style_color=$row['tit_color']?"color:".$row['tit_color'].";":'';
		$style_font=$row['tit_b']=="1"?"font-weight:bold;":'';
		$row['title']=cut_str($row['title'],$titlelen,0,"....");
		if ($style_color || $style_font)$row['title']="<span style=".$style_color.$style_font.">".$row['title']."</span>";
		$row['url'] =$row['is_url']<>"http://"?$row['is_url']:"?act=notice_show&id=".$row['id'];
		$List[] = $row;
	}
	return $List;
}
function get_notice_one($id)
{
	global $db;
	$sql = "select * from ".table('notice')." WHERE id = '".intval($id)."'  LIMIT 1";
	return $db->getone($sql);
}
?>