<?php
 /*
 * 74cms ��Ա���ĺ���
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
 if(!defined('IN_QISHI'))
 {
 	die('Access Denied!');
 }
//ע���Ա
function user_register($username,$password,$member_type=0,$email,$uc_reg=true)
{
	global $db,$timestamp,$_CFG,$online_ip;
	$member_type=intval($member_type);
	if ($member_type==0 || get_user($username) || get_user($email) ) return false;
	$pwd_hash=randstr();
	$password_hash=md5(md5($password).$pwd_hash);
	$setsqlarr['username']=$username;
	$setsqlarr['password']=$password_hash;
	$setsqlarr['pwd_hash']=$pwd_hash;
	$setsqlarr['email']=$email;
	$setsqlarr['reg_time']=$timestamp;
	$setsqlarr['reg_ip']=$online_ip;
	$insert_id=inserttable(table('members'),$setsqlarr,true);
	$setsqlarrtype['uid']=$insert_id;
	$setsqlarrtype['utype']=intval($member_type);
	if (!inserttable(table('members_type'),$setsqlarrtype)) return false;
			if($member_type=="1")
			{
				if(!$db->query("INSERT INTO ".table('members_points')." (uid) VALUES ('".$insert_id."')"))  return false;
				if(!$db->query("INSERT INTO ".table('members_setmeal')." (uid) VALUES (".$insert_id.")")) return false;
					$points=get_cache('members_points_rule');
							if ($points['reg_points']>0)
							{
								include_once(QISHI_ROOT_PATH.'include/fun_company.php');
								report_deal($insert_id,1,$points['reg_points'],'<span style=color:#FF6600>ע���Աϵͳ�Զ�����!</span>');
							}
							if ($_CFG['reg_service']>0)
							{
								include_once(QISHI_ROOT_PATH.'include/fun_company.php');
								set_members_setmeal($insert_id,$_CFG['reg_service']);
							}
			}
			if(defined('UC_API') && $uc_reg)
			{
				include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
				$uc_reg_uid=uc_user_register($username,$password,$email);
			}
return $username;
}
//��Ա��¼
function user_login($user,$password,$uc_login=true,$expire=NULL)
{
global $timestamp,$online_ip;
$get_name=check_user($user,$password);
if ($get_name)
{
update_user_info($get_name['username'],true,true,$expire);
$login['qs_login']=get_member_url($_SESSION['utype']);
	if(defined('UC_API') && $uc_login)
	{
	include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
	list($uc_uid, $uc_username, $uc_password, $uc_email) = uc_user_login($user, $password);
		if ($uc_uid>0)
		{
		$login['uc_login']=uc_user_synlogin($uc_uid);
		return $login;
		}
		elseif($uc_uid === -1)
		{
		$uc_reg_uid = uc_user_register($get_name['username'], $password, $get_name['email']);
				if ($uc_reg_uid>0)
				{
				$login['uc_login']=uc_user_synlogin($uc_reg_uid);
				return $login;
				}
				else
				{
				$login['uc_login']="";
				return $login;
				}
		}
		else
		{
		$login['uc_login']="";
		return $login;
		}
	}
	else
	{
	$login['uc_login']="";
	return $login;
	}
return $login;	
}
if (!$get_name)
{
	if(defined('UC_API') && $uc_login)
	{
	include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
	list($uc_uid, $uc_username, $uc_password, $uc_email) = uc_user_login($user, $password);
		if ($uc_uid>0)
		{
		global $_CFG;
		$_SESSION['activate_username']=$uc_username;
		$login['qs_login']=$_CFG['site_dir']."user/reg.php?act=activate&username=".$uc_username;
		$login['uc_login']=uc_user_synlogin($uc_uid);
		return $login;	
		}
		else
		{
		$login['qs_login']="";
		$login['uc_login']="";
		return $login;
		}
	}
	else
	{
	$login['qs_login']="";
	$login['uc_login']="";
	return $login;
	}
}
}
function check_user($name,$pwd){
 	global $db;
	$user_info=get_user($name);
	$pwd_hash=$user_info['pwd_hash'];
	$usname=$user_info['username'];
	$password=md5(md5($pwd).$pwd_hash);
 	$row = $db->getone("SELECT COUNT(*) AS num FROM ".table('members')." WHERE username='$usname' and password = '$password'");
 	if($row['num'] > 0)
	{
 		return $user_info;
 	}else{
 		return false;
 	}
 }
//���COOKIE
function check_cookie($name,$pwd){
 	global $db;
 	$row = $db->getone("SELECT COUNT(*) AS num FROM ".table('members')." WHERE username='$name' and password = '$pwd'");
 	if($row['num'] > 0)
	{
 	return true;
 	}else{
 	return false;
 	}
 }
 /**
  *
  * �����û���Ϣ
  *
  *
  */
 function update_user_info($username,$flush=true,$setcookie=true,$cookie_expire=NULL)
 {
 	global $timestamp, $online_ip,$db,$QS_cookiepath,$QS_cookiedomain;
	$user = get_user_inusername($username);
 	$_SESSION['uid'] = intval($user['uid']);
 	$_SESSION['username'] = $user['username'];
	$_SESSION['utype']=intval(get_user_type($user['uid']));
	if ($setcookie)
	{
		$expire=intval($cookie_expire)>0?time()+3600*24*$cookie_expire:0;
		setcookie('QS[uid]',$user['uid'],$expire,$QS_cookiepath,$QS_cookiedomain);
		setcookie('QS[username]',$user['username'],$expire,$QS_cookiepath,$QS_cookiedomain);
		setcookie('QS[password]',$user['password'],$expire,$QS_cookiepath,$QS_cookiedomain);
		setcookie('QS[utype]',$_SESSION['utype'], $expire,$QS_cookiepath,$QS_cookiedomain);
	}
	if ($flush)
	{
	$last_login_time = $timestamp;
	$last_login_ip = $online_ip;
	$sql = "UPDATE ".table('members')." SET last_login_time = '$last_login_time', last_login_ip = '$last_login_ip' WHERE uid='$_SESSION[uid]'";
	$db->query($sql);
	}
 }
//�����˻���ȡ�û���Ϣ
function get_user($val)
{
	if ($inusername=get_user_inusername($val))
	{
	return $inusername;
	}
	elseif ($inemail=get_user_inemail($val))
	{
	return $inemail;
	}
	else
	{
	return false;
	}
}
 //�ӵ����ʼ���ȡ��Ա��Ϣ
function get_user_inemail($email){
	global $db;
	$sql = "select * from ".table('members')." where email = '$email' LIMIT 1";
	$user_info=$db->getone($sql);
	return $user_info;
}
//�ӻ�Ա����ȡ��Ա��Ϣ
function get_user_inusername($username){
	global $db;
	$sql = "select * from ".table('members')." where username = '$username' LIMIT 1";
	$user_info=$db->getone($sql);
	return $user_info;
}
//�ӻ�ԱID��ȡ��Ա��Ϣ
function get_user_inid($uid){
	global $db;
	$sql = "select * from ".table('members')." where uid = '".intval($uid)."' LIMIT 1";
	$user_info=$db->getone($sql);
	return $user_info;
}
//��ȡ��Ա����
function get_user_type($uid)
{
	global $db;
	$sql = "select * from ".table('members_type')." where uid =".intval($uid)." LIMIT 1";
	$user_info=$db->getone($sql);
	return $user_info['utype'];
}
//�����û���
function activate_user($usname,$pwd,$email,$member_type)
{
global $timestamp,$online_ip;
	if(defined('UC_API'))
	{
	include_once(QISHI_ROOT_PATH.'api/uc_client/client.php');
	list($activateuid, $username, $password, $email) = uc_user_login($usname,$pwd);
		if($activateuid > 0)
		{
		return user_register($usname,$pwd,$member_type,$email,false);
		}
	}
return false;
}
//��ȡ����ַ���
 function randstr($length=6)
{
$hash='';
$chars= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz@#!~?:-=';   
$max=strlen($chars)-1;   
mt_srand((double)microtime()*1000000);   
for($i=0;$i<$length;$i++)   {   
$hash.=$chars[mt_rand(0,$max)];   
}   
return $hash;   
}
//�޸�����
function edit_password($arr,$check=true)
{
	global $db;
	if (!is_array($arr))return false;
	if (!check_user($arr['username'],$arr['oldpassword']) && $check==true)
	{
	return -1;
	}
	else
	{
	$user_info=get_user($arr['username']);
	$pwd_hash=$user_info['pwd_hash'];
	$md5password=md5(md5($arr['password']).$pwd_hash);	
	if ($db->query( "UPDATE ".table('members')." SET password = '$md5password'  WHERE username='".$arr['username']."'")) return $arr['username'];
	}
	return false;
}
?>