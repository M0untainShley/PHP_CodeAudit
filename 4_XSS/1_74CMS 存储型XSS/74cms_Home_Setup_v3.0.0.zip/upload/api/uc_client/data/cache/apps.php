<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZ',
    'name' => 'Discuz!',
    'url' => 'http://localhost/discuz',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  6 => 
  array (
    'appid' => '6',
    'type' => 'OTHER',
    'name' => '��ʾ��վ',
    'url' => 'http://localhost/bluecms',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  9 => 
  array (
    'appid' => '9',
    'type' => 'OTHER',
    'name' => '��ʿ�˲�ϵͳ',
    'url' => 'http://localhost/upload/',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  'UC_API' => 'http://localhost/uc',
);
