<?php
 /*
 * 74cms ����ְλ
 * ============================================================================
 * ��Ȩ����: ��ʿ���磬����������Ȩ����
 * ��վ��ַ: http://www.74cms.com��
 * ----------------------------------------------------------------------------
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�
 * ʹ�ã��������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
*/
define('IN_QISHI', true);
require_once(dirname(__FILE__).'/../include/plus.common.inc.php');
require_once(QISHI_ROOT_PATH.'include/mysql.class.php');
$db = new mysql($dbhost,$dbuser,$dbpass,$dbname);
$act = isset($_REQUEST['act']) ? trim($_REQUEST['act']) : 'app';
?>
<?php
//δ��¼
if ($_SESSION['uid']=='' || $_SESSION['username']=='')
{
?>
<script type="text/javascript">
$(".but80").hover(function(){$(this).addClass("but80_hover")},function(){$(this).removeClass("but80_hover")});
//��֤
$("#ajax_login").click(function() {
	if ($("#username").val()=="")
	{
	$(".ajax_login_err").show();
	$(".ajax_login_err").html("����д�û�����");
	return false;
	}
	else if($("#password").val()=="")
	{
	$(".ajax_login_err").show();
	$(".ajax_login_err").html("����д���룡");
	return false;
	}
	else
	{
		$("#ajax_login").hide();
		$("#ajax_waiting").show();
		var tsTimeStamp= new Date().getTime();
		 if($("#expire").attr("checked")==true)
		 {
		 var expire=$("#expire").val();
		 }
		 else
		 {
		 var expire="";
		 }
		 //alert(expire);
		$.post("<?php echo $_CFG['site_dir'] ?>plus/ajax.php", { "username": $("#username").val(),"password": $("#password").val(),"expire":expire,"url":window.location.href,"time":tsTimeStamp,"act":"do_login"},
	 	function (data,textStatus)
	 	 {
			if (data=="err")
			{
			$("#ajax_waiting").hide();
			$("#ajax_login").show();
			$("#password").attr("value","");
			$(".ajax_login_err").show();
			$(".ajax_login_err").html("�û��������������");
			}
			else
			{
				$("body").append(data);
				//alert(data);
			}
	 	 })
	}
});
</script>
<div class="ajax_login_tit">���ٵ�¼</div>
<div class="ajax_login_err"></div>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" >
    <tr><td width="50" align="right">�û�����</td>
    <td>
      <input name="username" type="text"  class="ajax_login_input" id="username"   maxlength="30" />    </td>
  </tr>
  <tr>
    <td align="right">��&nbsp;&nbsp;&nbsp;&nbsp;�룺</td>
    <td>
      <input name="password" type="password"  class="ajax_login_input" id="password"  maxlength="20"/>    </td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td><label><input type="checkbox" name="expire" id="expire" value="7" />
      һ�����Զ���¼</label></td>
  </tr>
  </table>
    <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" >  
  <tr>
    <td align="right" width="50">&nbsp;</td>
    <td height="50" valign="top">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100"><input type="button" name="Submit"  id="ajax_login" class="but80" value="��¼" />
		<input type="button" name="Submit"  id="ajax_waiting" class="but80" value="��¼��"  style="display:none"/>
		</td>
        <td class="link_bk"><a href="<?php echo $_CFG['site_dir'] ?>user/getpass.php">�������룿</a></td>
      </tr>
    </table></td>
    </tr>
  <tr>
    <td align="right" style="border-top:1px  #E8E8E8 solid">&nbsp;</td>
    <td height="30" valign="bottom" class="link_lan" style="border-top:1px  #E8E8E8 solid">��û���˺ţ�<a href="<?php echo $_CFG['site_dir'] ?>user/reg.php">���ע��</a></td>
  </tr>
</table>
<?php
exit();
}
elseif ($_SESSION['utype']!='2')
{
	exit("�����Ǹ��˻�Ա��������ְλ��");
}
require_once(QISHI_ROOT_PATH.'include/fun_personal.php');
$user=get_user_info($_SESSION['uid']);
if ($user['status']=="2") 
{
	$str="<a href=\"".get_member_url(2)."?act=user_status\">[�����ʺ�״̬]</a>";
	exit("�����˺Ŵ�����ͣ״̬��������Ϊ��������в�����".$str);
}
if ($act=="app")
{
		$id=isset($_GET['id'])?trim($_GET['id']):exit("������");
		$wheresql="WHERE uid=".intval($_SESSION['uid'])." and audit=1 and complete=1 ";
		if ($_CFG['outdated_resume']=="1") $wheresql.=" and  deadline>'".time()."' ";
		$resume_list=get_resume_list($wheresql);
		if (empty($resume_list))
		{
		$str="<a href=\"".get_member_url(2)."?act=user_status\">[�����ʺ�״̬]</a>";		
		exit("����ְλʧ�ܣ���ļ��������������Ѿ����ڣ�");
		}
		$jobs_list=get_jobs($id);
		if (empty($jobs_list)) exit("����ְλʧ�ܣ�");
?>
<script type="text/javascript">
$(".but80").hover(function(){$(this).addClass("but80_hover")},function(){$(this).removeClass("but80_hover")});
//���������������
var app_max="<?php echo $_CFG['apply_jobs_max'] ?>";
var app_today="<?php echo get_now_applyjobs_num($_SESSION['uid']) ?>";
$(".ajax_app_tip > span:eq(0)").html(app_max);
$(".ajax_app_tip > span:eq(1)").html(app_today);
$(".ajax_app_tip > span:eq(2)").html(app_max-app_today);
//��֤
$("#ajax_app").click(function() {
	if (app_max-app_today==0 || app_max-app_today<0 )
	{
	alert("�����������ְλ�����Ѿ�����������ƣ�");
	}
	else if ($("#app :checkbox[checked]").length>(app_max-app_today))
	{
	alert("�����컹��������"+(app_max-app_today)+"��ְλ����ѡְλ������������ƣ�");
	}
	else if ($("#app :checkbox[checked]").length==0)
	{
	alert("��ѡ�������ְλ��");
	}
	else if ($("#app :radio[checked]").length==0)
	{
	alert("��ѡ����ļ�����");
	}
	else
	{
		$("#app").hide();
		$("#waiting").show();
		var tsTimeStamp= new Date().getTime();
		 //alert(expire);
			 var jidArr=new Array();
			 $("#app :checkbox[checked]").each(function(index){jidArr[index]=$(this).val();});
		$.post("<?php echo $_CFG['site_dir'] ?>user/apply_jobs.php", { "resumeid": $("#app :radio[checked]").val(),"jobsid": jidArr.join("-"),"notes": $("#notes").val(),"time":tsTimeStamp,"act":"app_save"},
	 	function (data,textStatus)
	 	 {
			if (data=="ok")
			{
				$(".ajax_app_tip").hide();
				$("#app").hide();
				$("#waiting").hide();
				$("#app_ok").show();
					$("#app_ok .closed").click(function(){
						$("#floatBoxBg").hide();
						$("#floatBox").hide(); 
					});
			}
			else if(data=="repeat")
			{
				$("#app").show();
				$("#waiting").hide();
				$("#app_ok").hide();
				alert("���Ѿ��������ְλ�������ظ�����");
			}
			else
			{
				$("#app").show();
				$("#waiting").hide();
				$("#app_ok").hide();
				alert("����ʧ�ܣ�");
				//$("body").append(data);
				//alert(data);
			}
	 	 })
	}
});
</script>
<div class="ajax_app_tip">��ÿ���������<span></span>��ְλ�������Ѿ�������<span></span>��������������<span></span>��</div>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" id="app">
    <tr><td width="100" align="right" valign="top"  style="padding-top:10px;">Ҫ�����ְλ��</td>
    <td valign="top" class="ajax_app"> 
	 <ul>
	 <?php
	 foreach($jobs_list as $jobs)
	 {
	 ?>
	 <li><label><input name="jobsid" type="checkbox" value="<?php echo $jobs['id']?>" checked="checked" /><?php echo $jobs['jobs_name']?></label>
	 <?php }?>
	 </li>
	 </ul>
	 <div class="clear"></div>	
	  </td>
  </tr>
  <tr>
    <td align="right" valign="top"  style="padding-top:10px;">ѡ�������</td>
    <td valign="top" >
      <ul>
	 <?php
	 foreach($resume_list as $resume)
	 {
	 ?>
	 <li><label><input name="resumeid" type="radio" value="<?php echo $resume['id']?>"  /><?php echo $resume['title']?></label>&nbsp;&nbsp;
	  <a href="<?php echo get_member_url(2)?>?act=resume_show&pid=<?php echo $resume['id']?>" target="_blank">[Ԥ��]</a>
	 <?php }?>
	 </li>
	 </ul>
	 <div class="clear"></div>
    </td>
  </tr>
  <tr>
    <td align="right" valign="top">����˵����</td>
    <td>
	<textarea name="notes" id="notes"  style="width:300px; height:60px; line-height:180%; font-size:12px;"></textarea>
	</td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td>
	<input type="button" name="Submit"  id="ajax_app" class="but80" value="����" />
	</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="5" cellpadding="0" id="waiting"  style="display:none">
  <tr>
    <td align="center" height="60"><img src="<?php echo  $_CFG['site_template']?>images/30.gif"  border="0"/></td>
  </tr>
  <tr>
    <td align="center" >���Ժ�...</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="8" cellpadding="0" id="app_ok"  style="display:none">
  <tr>
    <td width="80" height="120" align="right" valign="top"><img src="<?php echo  $_CFG['site_template']?>images/13.png" /></td>
    <td>
	<strong style=" font-size:14px ; color:#0066CC;">ְλ����ɹ�!</strong>
	<div style="border-top:1px #CCCCCC solid; line-height:180%; margin-top:10px; padding-top:10px; height:100px;"  class="dialog_closed">
	<a href="<?php echo get_member_url(2)?>?act=apply_jobs" >�鿴�������ְλ</a><br />

	<a href="javascript:void(0)"  class="closed">�������</a>
	
	</div>
	</td>
  </tr>
</table>
<?php
}
elseif ($act=="app_save")
{
	$jobsid=isset($_POST['jobsid'])?trim($_POST['jobsid']):exit("������");
	$resumeid=isset($_POST['resumeid'])?trim($_POST['resumeid']):exit("������");
	$notes=isset($_POST['notes'])?trim($_POST['notes']):"";
	$resume_basic=get_resume_basic($_SESSION['uid'],$resumeid);
	$jobs_list=get_jobs($jobsid);
	if (empty($jobs_list)) exit("����ְλʧ�ܣ�");
	$i=0;
	foreach($jobs_list as $jobs)
	 {
	 		if (check_jobs_apply($jobs['id'],$resumeid,$_SESSION['uid'])) continue ;
	 		$addarr['resume_id']=$resumeid;
			$addarr['personal_uid']=intval($_SESSION['uid']);
			$addarr['jobs_id']=$jobs['id'];
			$addarr['company_id']=$jobs['company_id'];
			$addarr['company_uid']=$jobs['uid'];
			$addarr['notes']= $notes;
			if (strcasecmp(QISHI_DBCHARSET,"utf8")!=0)
			{
			$addarr['notes']=iconv("utf-8",QISHI_DBCHARSET,$addarr['notes']);
			}
			$addarr['apply_addtime']=time();
			$addarr['personal_look']=1;
			if (inserttable(table('personal_jobs_apply'),$addarr))
			{
					$mailconfig=get_cache('mailconfig');
					$jobs['contact']=get_jobs_contact($jobs['id']);
					if ($mailconfig['set_applyjobs']=="1" && $jobs['contact']['notify']=="1")
					{	
						$personal_fullname=$resume_basic['display_name']=="1"?$resume_basic['fullname']:$resume_basic['number'];
						asyn_sendmail($_CFG['site_domain'].$_CFG['site_dir']."plus/asyn_mail.php?uid=".$_SESSION['uid']."&key=".asyn_userkey($_SESSION['uid'])."&act=jobs_apply&jobs_id=".$jobs['id']."&jobs_name=".$jobs['jobs_name']."&personal_fullname=".$personal_fullname."&email=".$jobs['contact']['email']);
					}
			}
			$i=$i+1;
	 }
	 if ($i==0)
	 {
	 exit("repeat");
	 }
	 else
	 {
	 exit("ok");
	 }
}
unset($smarty);
?>
