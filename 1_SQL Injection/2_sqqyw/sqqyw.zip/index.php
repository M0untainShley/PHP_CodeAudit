﻿<?PHP 

 if(file_exists("php/conn.php")==false){
    
    
exit("<meta http-equiv=\"refresh\" content=\"0.1;url=php/ino.php\">") ;
  EXIT();  
    
    
 }
 
 
 if(file_exists("php/ino.php"))
{

$del=unlink("php/ino.php");

}




include("php/function.php");
$zl=zl();
$GG=advertising();






?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title><?PHP ECHO $zl['t']; ?></title>
<meta name="keywords" content="<?PHP ECHO $zl['g']; ?>" />
<meta name="description" content="<?PHP ECHO $zl['m']; ?>" />

<link href="css/zui.css" rel="stylesheet" type="text/css" />
<link href="css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="css/css.css" rel="stylesheet" type="text/css" />



<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
</style></head>

<body>



<img class="bg-image" src="img/bj.jpg">
<div class="bg-image-pattern"></div>


<nav class="navbar navbar-inverse" role="navigation">

  <!-- 导航头部 -->
  <div class="navbar-header">
    <!-- 移动设备上的导航切换按钮 -->
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse-example">
      <span class="sr-only">切换导航</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <!-- 品牌名称或logo -->
    <a class="navbar-brand" href="your/nice/url"><i class="icon icon-cubes"></i><?PHP ECHO $zl['tt']; ?></a>
  </div>

  <!-- 导航项目 -->
  <div class="collapse navbar-collapse navbar-collapse-example">
    <!-- 一般导航项目 -->
    <ul class="nav navbar-nav">
      <!-- 导航中的下拉菜单 -->
      <li class="dropdown">
        <a href="your/nice/url" class="dropdown-toggle" data-toggle="dropdown"><i class="icon icon-rss">关于</i> <b class="caret"></b></a>
        <ul class="dropdown-menu" role="menu">
          <li><a href="http://wpa.qq.com/msgrd?v=3&uin=2243752917&site=qq&menu=yes">淡然：2243752917</a></li>
		  <li><a href="http://5imzw.top/">淡然秒赞网</a></li>
    
        </ul>
      </li>
    </ul>
	
<form class="navbar-form navbar-left" role="search">
      <div class="form-group">
        <input id="dd" type="text" class="form-control" placeholder="查询订单">
      </div>
      <button id="cx" class="btn btn-warning " type="button">查询订单</button>
    </form>
	
	
  </div><!-- END .navbar-collapse -->
</nav>











<div class="wrapper">




<img class="qqlogo" src="//q2.qlogo.cn/headimg_dl?bs=qq&amp;dst_uin=<?PHP ECHO $zl['q']; ?>&amp;src_uin=<?PHP ECHO $zl['q']; ?>&amp;fid=<?PHP ECHO $zl['q'] ?>&amp;spec=100&amp;url_enc=0&amp;referer=bu_interface&amp;term_type=PC" width="80px" height="80px" alt="<?PHP ECHO $zl['q']; ?>" title="<?PHP ECHO $zl['tt']; ?>"><label>&nbsp;&nbsp;&nbsp;<H2><?PHP ECHO $zl['tt']; ?></H2></label>




<hr/>



<div class="alert alert-warning-inverse">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
  <p><?PHP ECHO announcement(); ?></p>
  
</div>






<div class="panel panel-success">
  <div class="panel-heading">
    在线点亮图标客服：<?PHP ECHO $zl['q'] ?>

	<div class="visible-lg">
	
	
	
	
	
	<div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_mshare" data-cmd="mshare" title="分享到一键分享"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a><a href="#" class="bds_tqf" data-cmd="tqf" title="分享到腾讯朋友"></a><a href="#" class="bds_hx" data-cmd="hx" title="分享到和讯"></a><a href="#" class="bds_diandian" data-cmd="diandian" title="分享到点点网"></a><a href="#" class="bds_duitang" data-cmd="duitang" title="分享到堆糖"></a><a href="#" class="bds_ty" data-cmd="ty" title="分享到天涯社区"></a><a href="#" class="bds_bdhome" data-cmd="bdhome" title="分享到百度新首页"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_thx" data-cmd="thx" title="分享到和讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_douban" data-cmd="douban" title="分享到豆瓣网"></a><a href="#" class="bds_kaixin001" data-cmd="kaixin001" title="分享到开心网"></a><a href="#" class="bds_tieba" data-cmd="tieba" title="分享到百度贴吧"></a><a href="#" class="bds_bdysc" data-cmd="bdysc" title="分享到百度云收藏"></a><a href="#" class="bds_copy" data-cmd="copy" title="分享到复制网址"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
	
	
	
	
	</div>

	
  </div>
  <div class="panel-body">

<span class="label label-badge label-info">请选择需要点亮图标</span>


            <select name="yw" id="yw" class="form-control">
            
            
            
              <?PHP   ywlb() ?>

      </select>
<br/>

<span class="label label-badge label-success">请认真填写扣扣账号</span>
<input name="u" type="text" class="form-control" id="u" value="" maxlength="10" placeholder="QQ账号">

<br/>

<span class="label label-badge label-success">请认真填写扣扣密码</span>
<input type="password" name="p" id="p" value="" class="form-control" placeholder="QQ密码" />
<br/>

<a onclick="yzmAAAA()" > <span  class="label label-badge label-primary">请认真填写点亮验证 <i class="icon icon-history"></i>点我换一个</span></a>



<input name="y" type="text" class="form-control" style="background-image: url(http://173941.vhost264.cloudvhost.cn/yzm/captcha.php);background-repeat: repeat-y;line-height: 21px;padding-left: 94px;
" id="y" value="" maxlength="4" placeholder="验证码" />
  </div>
  <br/>

<button id="XD" class="btn btn-block btn-info  " type="button">提交订单</button>

  </div>
  
  
  
  
<table id="myModalAlert" class="table table-condensed">
        <thead>
          <tr>
            <th>QQ</th>
            <th class="hidden-xs">业务</th>
            <th>单号</th>
  
          </tr>
        </thead>
        <tbody>
         <?PHP  ywdd(getIP()); ?>
        
        
        </tbody>
      </table>
  
  
  
  
  
  
  
  
  <?PHP ECHO bottom(); ?>




</div>



















</div>





 <script src="js/jquery.js"></script>
  <script src="js/zui.min.js"></script>
  <script src="js/zui.js"></script>
  <script src="js/zui.lite.js"></script>
  <script src="js/zui.lite.min.js"></script>
  <script src="js/zui.min.js"></script>
   <script src="js/yzm.js"></script>
   <script src="js/xd.js"></script>
  <script>yzmAAAA()</script>


</body>
</html>
