var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
  
   function tj(){


var url= document.getElementById("kameng_shangpin").value
xmlhttp.open("POST","../php/qq_function.php?t=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("url="+url);
var FH=xmlhttp.responseText
if(FH=="1"){
	
	alert("卡盟对接出错");
	 exit();
	}
var S = FH.indexOf("售价"); 
if(S=="-1"){
	
	alert("未知错误-请重试");
	alert(FH);
    exit();
    }
   
    
    
  if(S!="-1"){
    
    
    
	
	
	 var biaoti = FH.split("<title>");
    var biaotiA = biaoti[1].split("</title>");
	var shangpin=biaotiA[0];
	
	
	
	var ID1 = FH.split("<input type=\"hidden\" value=\"");
    var ID1A = ID1[1].split("\" name=\"areaId\"/>");
	var areaId=ID1A[0];

	
    var ID2A = ID1[2].split("\" name=\"goodstId\"/>");
	var goodstId=ID2A[0];
   
   var myarray = FH.split("<font color=\"red\" id=\"showthisprice\">");
    var myarrayA = myarray[1].split("</font>");
	var JIAGE=myarrayA[0];
    
    
    document.getElementById("JJ").innerHTML="<span class='label'>商品名称：</span><input type='text'name='m'id='m'value='"+shangpin+"'class='form-control'placeholder='请输入商品名称'><BR/> <input type='radio' id='x'  name='radiobutton' value='1' checked>不限制   <input type='radio'  id='x' name='radiobutton' value='2'>限制QQ  <input type='radio' id='x' name='radiobutton' value='3'>限制IP  <input type='radio' id='x' name='radiobutton' value='4'>全限制  <BR/><input name='areaId' id='areaId'type='hidden'value='"+areaId+"'/><input name='goodstId'id='goodstId'type='hidden'value='"+goodstId+"'/><br/><P class='label label-badge label-success'>商品价格:"+JIAGE+"元</p ><P class='label label-badge label-success'>areaId:"+areaId+"</p ><P class='label label-badge label-success'>goodstId:"+goodstId+"</P><input class='btn btn-block btn-info  'onclick='jia()'name='添加商品'type='submit'id='添加商品'value='添加商品'>";
 
	
	
	
	}	  
	  
	  }
  

function www(num)
{
return Math.floor(num * 100) / 100 ;
}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
function jia(){
	
var shangpin= document.getElementById("m").value
var a= document.getElementById("areaId").value	
var b= document.getElementById("goodstId").value
var sex=document.getElementsByName("radiobutton");//不能getElementById，ById又只会读数组第一个值
var sexid;
 for(var i = 0; i < sex.length; i++)
{
     if(sex[i].checked)
     sexid=i;
 }








if(shangpin==""){
	
	alert("请填写商品名称");
	exit();
	
	
	}
	

	
xmlhttp.open("POST","../php/qq_function.php",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("shangpin="+shangpin+"&areaId="+a+"&goodstId="+b+"&x="+sexid);
var FH=xmlhttp.responseText	
	if(FH=="1"){
		
		
		alert("添加成功");
		location.href='yw.php';
		exit();
		
		}if(FH=="2"){
		
		
		alert("添加失败");
		exit();
		
		}
		
	
	}  
  
  
  

  
  
  