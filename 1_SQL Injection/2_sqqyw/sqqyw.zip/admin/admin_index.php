﻿<?php session_start();header("Content-type: text/html; charset=utf-8"); 
IF( $_SESSION['admin']!="OK"){
exit("<meta http-equiv=\"refresh\" content=\"0.1;url=index.php\">") ;      
}


 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title>后台管理</title>

<link href="../css/zui.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="../css/css.css" rel="stylesheet" type="text/css" />
</head>

<body>


<img class="bg-image" src="../img/bj.jpg">
<div class="bg-image-pattern"></div>


<div class="wrapper">
  <div align="center"><h2>萌耗子后台管理系统</h2> </div>
  
  <div class="panel">
  <div class="panel-heading">
   后台功能列表
  </div>
  <div class="panel-body">


<a href="title.php" class="btn btn-block btn-info  " type="button">网站信息修改</a>
<br/>
<a href="announcement.php" class="btn btn-block btn-info  " type="button">网站公告修改</a>
<br/>
<a href="advertising.php" class="btn btn-block btn-info  " type="button">网站广告修改</a>
<br/>
<a href="ka.php" class="btn btn-block btn-info  " type="button">卡盟配置修改</a>
<br/>
<a href="yw.php" class="btn btn-block btn-info  " type="button">卡盟图标管理</a>
<br/>
<a href="admin.php" class="btn btn-block btn-info  " type="button">修改管理密码</a>
<br/>
<a href="http://wpa.qq.com/msgrd?v=3&uin=2243752917&site=qq&menu=yes" class="btn btn-block btn-info  " type="button">网站续费充值</a>
</div>
  

  </div>
 版权归安小浩所有@2016 
</div>









 <script src="../js/jquery.js"></script>
  <script src="../js/zui.min.js"></script>
  <script src="../js/zui.js"></script>
  <script src="../js/zui.lite.js"></script>
  <script src="../js/zui.lite.min.js"></script>
  <script src="../js/zui.min.js"></script>
   <script src="../js/yzm.js"></script>
   
   
   
  
   
   
</body>
</html>
