<?php session_start();header("Content-type: text/html; charset=utf-8"); 
IF( $_SESSION['admin']!="OK"){
exit("<meta http-equiv=\"refresh\" content=\"0.1;url=index.php\">") ;      
}

include("../php/admin_function.php");

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title>后台管理</title>

<link href="../css/zui.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="../css/css.css" rel="stylesheet" type="text/css" />
</head>

<body>
<img class="bg-image" src="../img/bj.jpg">
<div class="bg-image-pattern"></div>


<div class="wrapper">
  <div align="center"><h2>萌耗子后台管理系统</h2> </div>
  


<div class="panel">
  <div class="panel-heading">
   <i class="icon icon-arrow-left"></i> <a  href="admin_index.php" class="label label-badge label-info"> 返回首页</a>-【网站底部修改】
  </div>
  <div class="panel-body">
    <span class="label">底部内容：</span>
	<form action="" method="post">
	<input name="admin_gg" type="hidden" id="admin_gg" value="ok">
	<textarea name="g" rows="6" class="form-control" id="g" placeholder="底部"><?PHP ECHO bottom(); ?></textarea>
<br>
	
	<input class="btn btn-block btn-info  " name="立即修改" type="submit" id="立即修改" value="立即修改">
	
	</form>

  
  




</div>
  

  </div>
 版权归安小浩所有@2016 
</div>


<?PHP

if($_POST['admin_gg']=="ok"){
    
IF(bottom_g($_POST['g'])){
    
 echo "<script>alert('修改成功！')</script>";
   exit("<meta http-equiv=\"refresh\" content=\"0.1;url=bottom.php\">") ;       
    
}echo "<script>alert('修改失败！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  
    
    
}


?>






 <script src="../js/jquery.js"></script>
  <script src="../js/zui.min.js"></script>
  <script src="../js/zui.js"></script>
  <script src="../js/zui.lite.js"></script>
  <script src="../js/zui.lite.min.js"></script>
  <script src="../js/zui.min.js"></script>
   <script src="../js/yzm.js"></script>
   
   
   

   
   
</body>
</html>
