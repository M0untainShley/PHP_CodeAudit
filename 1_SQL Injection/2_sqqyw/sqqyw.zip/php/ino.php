﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title>安装程序</title>

<link href="../css/zui.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="../css/css.css" rel="stylesheet" type="text/css" />
</head>

<body>


<img class="bg-image" src="/img/bj.jpg">
<div class="bg-image-pattern"></div>


<div class="wrapper">
  <div align="center"><h2>萌耗子1.44安装程序</h2> </div>
  
  <div class="panel">
  <div class="panel-heading">
   请填写完整以下内容
  </div>
  <div class="panel-body">
    <span class="label">管理账号：</span>
	<form action="" method="post">
	<input name="anzhuang" type="hidden" id="anzhuang" value="ok" />
	<input type="text" name="u" id="u" value="" class="form-control" placeholder="账号">
<br/>
	<span class="label">管理密码：</span>
	<input type="password" name="p" id="p" value="" class="form-control" placeholder="密码">
	<br/>
	<span class="label">数据库地址：</span>
	<input type="text" name="l" id="l" value="" class="form-control" placeholder="数据库地址">
	<br/>
	<span class="label">数据库账号：</span>
	<input type="text" name="qu" id="qu" value="" class="form-control" placeholder="数据库账号">
	<br/>
	<span class="label">数据库密码：</span>
	<input type="text" name="qp" id="qp" value="" class="form-control" placeholder="数据库密码">
	<br/>
	<span class="label">数据库名称：</span>
	<input type="text" name="qc" id="qc" value="" class="form-control" placeholder="数据库名称">
	
	<br/>
	
	
	
	
	
	<input class="btn btn-block btn-info  " name="安装程序" type="submit" id="安装程序" value="安装程序" />
	</form>
 <hr/>
 本程序来自萌耗子独立开发@2016
</div>
  
  
  </div>
</div>









 <script src="../js/jquery.js"></script>
  <script src="../js/zui.min.js"></script>
  <script src="../js/zui.js"></script>
  <script src="../js/zui.lite.js"></script>
  <script src="../js/zui.lite.min.js"></script>
  <script src="../js/zui.min.js"></script>
   <script src="../js/yzm.js"></script>
   
   
   
   
   
   
</body>
</html>


<?PHP

if(@@$_POST['anzhuang']=="ok"){
    
       if(@$_POST['u']=="" || @$_POST['p']=="" ||  @$_POST['l']=="" || @$_POST['qu']==""|| @$_POST['qp']==""|| @$_POST['qc']=="") {
        
        
         echo "<script>alert('请填写完整！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  
        
        
    }
    
    
    if($link=@mysql_connect(@$_POST['l'],@$_POST['qu'],@$_POST['qp'])){
        
        @mysql_query("set names utf8");
        if(@mysql_select_db(@$_POST['qc'])){

            
            
            
          $myfile = fopen("conn.php", "w");
    $myfile = fopen("conn.php", "w") or die("Unable to open file!");
    
    $txt = '<?PHP  $A="'.@$_POST['l'].'";$B="'.@$_POST['qu'].'";$C="'.@$_POST['qp'].'";$D="'.@$_POST['qc'].'";$AA=mysql_connect($A,$B,$C) or EXIT("MYSQL-NO");$BB=mysql_select_db($D);$sql = "set names utf8"; mysql_query($sql); ?>';

    
    if(fwrite($myfile, $txt)!=false){    
      fclose($myfile);
    
    
    
    $sql="CREATE TABLE `admin` (
  `id` int(99) NOT NULL auto_increment,
  `u` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `p` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;";

IF(mysql_query($sql)){
  
  
$sql="INSERT INTO `admin` (`id`, `u`, `p`) VALUES
(1, '".$_POST['u']."', '".$_POST['p']."');";  


IF(mysql_query($sql)){
  

$sql="CREATE TABLE `advertising` (
  `id` int(99) NOT NULL auto_increment,
  `s` varchar(9999) character set utf8 collate utf8_bin NOT NULL,
  `x` varchar(9999) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;";


IF(mysql_query($sql)){



$sql="INSERT INTO `advertising` (`id`, `s`, `x`) VALUES
(1, '', '');";
IF(mysql_query($sql)){


$sql="CREATE TABLE `announcement` (
  `id` int(99) NOT NULL auto_increment,
  `announcement` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;";
IF(mysql_query($sql)){



$sql="INSERT INTO `announcement` (`id`, `announcement`) VALUES
(1, '');";

IF(mysql_query($sql)){


$sql="CREATE TABLE `bottom` (
  `id` int(99) NOT NULL auto_increment,
  `bottom` varchar(9999) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;";

IF(mysql_query($sql)){


$sql="INSERT INTO `bottom` (`id`, `bottom`) VALUES
(1, '');";
IF(mysql_query($sql)){


$sql="CREATE TABLE `dd` (
  `id` int(99) NOT NULL auto_increment,
  `u` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  `m` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  `d` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  `ip` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;";

IF(mysql_query($sql)){




$sql="INSERT INTO `dd` (`id`, `u`, `m`, `d`, `ip`) VALUES
(4, '554425155', '（QQ咨询达人图标）永久性点亮ˇ软件7*24小时自动开单', '20160718362148234844421', '127.0.0.1');";
IF(mysql_query($sql)){




$sql="CREATE TABLE `ka` (
  `id` int(99) NOT NULL auto_increment,
  `url` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `u` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `p` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `j` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;";
IF(mysql_query($sql)){




$sql="INSERT INTO `ka` (`id`, `url`, `u`, `p`, `j`) VALUES
(1, 'http://danran.999km.cn/', '卡盟账号', '卡盟密码', '交易密码');";
IF(mysql_query($sql)){





$sql="CREATE TABLE `title` (
  `id` int(99) NOT NULL auto_increment,
  `t` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  `g` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  `m` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  `q` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  `tt` varchar(999) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;";
IF(mysql_query($sql)){



$sql="INSERT INTO `title` (`id`, `t`, `g`, `m`, `q`, `tt`) VALUES
(1, '淡然点图标系统', '淡然点图标系统', '淡然点图标系统是一个在线点亮QQ图标的网站', '2243752917', '淡然点图标系统');";

IF(mysql_query($sql)){




$sql="CREATE TABLE `yw` (
  `id` int(99) NOT NULL auto_increment,
  `m` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `areaId` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `goodstId` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `x` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;
";

IF(mysql_query($sql)){



$sql="INSERT INTO `yw` (`id`, `m`, `areaId`, `goodstId`) VALUES
(1, '（永久纪念超Q）需曾经开过超Q或现在是会员', '11324127', '13796230'),
(2, '（永久情侣黄钻图标）需本身自带黄钻黄钻多久就卡多久', '11324128', '13796282'),
(3, '（永久旋风图标）需QQ会员或者超级会员', '11324129', '13796383'),
(4, '（临时图书vip）官方一天图书一个月一次', '11324130', '13796445'),
(5, '（手机拉圈圈，圈圈赞，7个个性标签赞，拉满99 、秒拉爆满）', '11324131', '13796495'),
(6, '（3399游戏小图标）日开万单下单就秒', '11324132', '13796518'),
(7, '（永久星钻图标）需本身自带官方黄钻绿钻多久就卡多久', '11324133', '13796642'),
(8, '（永久透明头像）需QQ会员或者超级会员-日开万单', '11324135', '13796855'),
(9, '（QQ咨询达人图标）永久性点亮ˇ软件7*24小时自动开单', '17679275', '20334540');
";

IF(mysql_query($sql)){


$sql="CREATE TABLE `xz` (
  `id` int(99) NOT NULL auto_increment,
  `ip` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `q` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  `y` varchar(99) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;";


IF(mysql_query($sql)){


echo "<script>alert('安装成功！')</script>";
   exit("<meta http-equiv=\"refresh\" content=\"0.1;url=../index.php\">") ;    



}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十七条失败<br/><br/>"); 





}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十六条失败<br/><br/>"); 

}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十五条失败<br/><br/>");   



}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十四条失败<br/><br/>");   




}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十三条失败<br/><br/>");   






}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十二条失败<br/><br/>");   





}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十一条失败<br/><br/>");   





}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第十条失败<br/><br/>");   




}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第九条失败<br/><br/>");   




}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第八条失败<br/><br/>");   

}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第七条失败<br/><br/>");   



}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第六条失败<br/><br/>");   

}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第五条失败<br/><br/>");   



}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第四条失败<br/><br/>");   



}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第三条失败<br/><br/>");   



}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第二条失败<br/><br/>");   

  
  
}$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
mysql_close($link);
exit("执行sql命令第一条失败<br/><br/>");      
    
    
 } $result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   unlink("conn.php"); 
       mysql_close($link);
    echo "<script>alert('请检查目录权限！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");     
            
            
            
          
        }$result=mysql_query("SHOW tables",$link);   
while ($currow=mysql_fetch_array($result)) {   
mysql_query("drop TABLE IF EXISTS $currow[0]");    
}    unlink("conn.php");   
          mysql_close($link);
        echo "<script>alert('数据库名错误！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  

        
      
    } $result=@mysql_query("SHOW tables",$link);   
while ($currow=@mysql_fetch_array($result)) {   
@mysql_query("drop TABLE IF EXISTS $currow[0]");    
}   @unlink("conn.php");   
      @mysql_close($link);
    echo "<script>alert('数据库连接失败！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  

    
    
    
    
    
    
    
    
    
    
}

?>






