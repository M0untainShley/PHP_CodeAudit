<?php

/**
 * @author �Ⱥ���
 * @copyright 2016
 */
 session_start();header("Content-type: text/html; charset=utf-8");
  IF( $_SESSION['admin']!="OK"){
exit("no") ;      
}
 
include("admin_function.php");
$ka=ka();
if($_POST['url']!=""){
    
$cookie_file = dirname(__FILE__).'/cookie.txt';
//$cookie_file = tempnam("tmp","cookie");

//�Ȼ�ȡcookies������
$url = $ka['url']."frontLogin.htm";

$curlPost['loginTimes']='1';
$curlPost['userName']=$ka["u"];
$curlPost['password']=$ka["p"];
$ch = curl_init($url); //��ʼ��
curl_setopt($ch, CURLOPT_HEADER, 0); //������header����
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //�����ַ���������ֱ�����
curl_setopt($ch, CURLOPT_POST, 1);//post�ύ��ʽ
curl_setopt($ch, CURLOPT_COOKIEJAR,  $cookie_file); //�洢cookies
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$FH= curl_exec($ch);
curl_close($ch);
if(strpos($FH,"\"loginTimes\":\"1\",\"mess\":\"")!=FALSE){ 
    
 exit("1");//���˶Խ�ʧ�ܣ�   
    
    
}

$url = $_POST['url'];
$ch = curl_init($url); 
curl_setopt($ch, CURLOPT_HEADER, 0); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); 
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$FH= curl_exec($ch);
curl_close($ch);
echo $FH;    



}

if($_POST['shangpin']!=""){
    
 
 
 $SQL="INSERT INTO  `".$D."`.`yw` (
`id` ,
`m` ,
`areaId` ,
`goodstId` ,
`x`
)
VALUES (
NULL ,  '".$_POST['shangpin']."',  '".$_POST['areaId']."',  '".$_POST['goodstId']."',  '".$_POST['x']."'
);
";
 
 
    
 
IF(mysql_query($SQL)){
    
    exit("1");
    
}exit("2");

    
}


    

?>