<?php
$LANG['the_site_not_release'] = 'There is no Publishing Point on site';
$LANG['release_point_connect_failure'] = 'Node『 {name} 』connecting failed';
$LANG['peed_your_server'] = 'The speed of synchronization is dependent upon the speed of publishing point on your server.';
$LANG['are_release_ing'] = 'Synchronizing';
$LANG['done'] = 'Finished';
$LANG['sync_agin'] = 'Synchronizing again';
$LANG['site'] = 'Site';
$LANG['path'] = 'Path';
$LANG['time'] = 'Time';
$LANG['upload'] = 'Upload';
$LANG['success'] = 'Success';
$LANG['failure'] = 'Fail';
$LANG['not_upload'] = 'have not streamed it yet';
$LANG['remind'] = 'Warning';
$LANG['remind_message'] = 'The operation failed because your server probably do not have this file. Please cancel this command';