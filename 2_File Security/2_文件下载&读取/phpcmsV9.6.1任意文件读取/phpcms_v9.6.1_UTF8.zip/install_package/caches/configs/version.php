<?php
return array(
'pc_version' => 'V9.6.1',	//phpcms 版本号
'pc_release' => '20170412',	//phpcms 更新日期
);
?>