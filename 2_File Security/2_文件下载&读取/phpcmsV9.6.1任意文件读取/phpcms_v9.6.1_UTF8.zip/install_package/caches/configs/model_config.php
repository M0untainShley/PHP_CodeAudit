<?php

return array('project1'=>'经典模式');

?>