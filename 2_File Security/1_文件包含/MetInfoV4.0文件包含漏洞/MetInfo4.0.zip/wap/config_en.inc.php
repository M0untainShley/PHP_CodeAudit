<?php
/*
met_wap     	  = "1";
met_waplink       = "0";
met_wap_ok     	  = "0";
met_wap_tpa       = "0";
met_wap_tpb       = "0";
met_wap_url       = "";
met_wap_logo      = "../upload/201105/1303929200.png";
met_wap_img       = "../upload/201105/1303929227.jpg";
wap_skin_1        = "1";
wap_skin_2        = "1";
wap_skin_3        = "0";
wap_news_list     = "5";
wap_product_list  = "5";
wap_download_list = "5";
wap_img_list      = "5";
wap_job_list      = "5";
wap_product_imgx  = "200";
wap_product_imgy  = "200";
wap_img_imgx      = "240";
wap_img_imgy      = "200";
wap_title         = "";
wap_description   = "MetInfo enterprise website management system ";
wap_footertext    = "";
*/
?>