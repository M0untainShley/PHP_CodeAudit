<?php
/*
met_wap     	  = "1";
met_waplink       = "0";
met_wap_ok     	  = "0";
met_wap_tpa       = "1";
met_wap_tpb       = "0";
met_wap_url       = "";
met_wap_logo      = "../upload/201105/1303929200.png";
met_wap_img       = "../upload/201105/1303929227.jpg";
wap_skin_1        = "1";
wap_skin_2        = "1";
wap_skin_3        = "1";
wap_news_list     = "10";
wap_product_list  = "10";
wap_download_list = "10";
wap_img_list      = "10";
wap_job_list      = "10";
wap_product_imgx  = "240";
wap_product_imgy  = "200";
wap_img_imgx      = "240";
wap_img_imgy      = "200";
wap_title         = "我的网站";
wap_description   = "长沙米拓信息技术有限公司";
wap_footertext    = "0731-88920794";
*/
?>