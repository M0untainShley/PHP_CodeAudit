<?php
                   /*
                   con_db_host = ""
                   con_db_id   = ""
                   con_db_pass	= ""
                   con_db_name = ""
                   tablepre    =  "met_"
                   db_charset  =  "utf8";
                  */
                  ?>