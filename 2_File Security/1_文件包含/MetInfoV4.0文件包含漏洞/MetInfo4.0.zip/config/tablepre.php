<?php

                   $met_admin_table = $tablepre."admin_table";
				   $met_skin_table = $tablepre."skin_table";
				   $met_column = $tablepre."column";
				   $met_news = $tablepre."news";
				   $met_parameter = $tablepre."parameter";
				   $met_product = $tablepre."product";
				   $met_download = $tablepre."download";
				   $met_img = $tablepre."img";
				   $met_job = $tablepre."job";
				   $met_online = $tablepre."online";
				   $met_label = $tablepre."label";
				   $met_feedback = $tablepre."feedback";
				   $met_list = $tablepre."list";
				   $met_message = $tablepre."message";
				   $met_index = $tablepre."index";
				   $met_link = $tablepre."link";
				   $met_otherinfo = $tablepre."otherinfo";
				   $met_flash = $tablepre."flash";
				   $met_cv = $tablepre."cv";
				   $met_plist = $tablepre."plist";
				   $met_flist = $tablepre."flist";
 ?>