<?php
# MetInfo Enterprise Content Management System 
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved. 
$met_ch_lang='1';
$met_ch_mark='cn';
$met_index_type='cn';
$met_admin_type='cn';
$met_admin_type_ok='1';
$met_url_type='0';
$met_lang_mark='1';
$met_lang_editor='1';
$met_langok=array();
$met_langok[cn]=array(name=>'简体中文',useok=>'1',order=>'1',mark=>'cn',flag=>'',link=>'',newwindows=>'');
$met_langok[en]=array(name=>'English',useok=>'1',order=>'2',mark=>'en',flag=>'',link=>'',newwindows=>'');
$met_langadmin=array();
$met_langadmin[cn]=array(name=>'简体中文',useok=>'1',order=>'1',mark=>'cn');
$met_langadmin[en]=array(name=>'English',useok=>'1',order=>'1',mark=>'en');
$met_langok[cn][met_webhtm]=0;
$met_langok[cn][met_htmtype]='html';
$met_langok[cn][met_weburl]='http://localhost/met520/m3/';
$met_langok[en][met_webhtm]=0;
$met_langok[en][met_htmtype]='html';
$met_langok[en][met_weburl]='http://localhost/met520/m3/';
# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>