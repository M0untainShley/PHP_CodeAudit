<?php
$str[0]=array('米拓信息','<a title=米拓信息 target=_blank href=http://www.metinfo.cn>米拓信息</a>');
$str[1]=array('网站建设','<a title=网站建设 target=_blank href=http://www.metinfo.cn/>网站建设</a>');
$str[2]=array('Metinfo','<a title=Metinfo target=_blank href=http://www.metinfo.cn/>Metinfo</a>');
$str[3]=array('Web site','<a title=Web site target=_blank href=http://www.metinfo.cn/>Web site</a>');
$str[4]=array('test','<a title=test target=_blank href=http://>test</a>');

?>