<?php
$str[0]=array('米拓信息',"<a title='MetInfo企业网站管理系统' target='_blank' href='http://www.metinfo.cn/' class='seolabel'>米拓信息</a>");

?>